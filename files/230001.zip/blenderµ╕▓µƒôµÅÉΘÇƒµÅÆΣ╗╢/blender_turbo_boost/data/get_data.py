import os
import pathlib
import bpy
from..operators.dont_register import report_custom_error

root = str(pathlib.Path(__file__).parent.absolute())

# node_groups_blend = os.path.join(root,'node_groups.blend')


def get_blank_image(render_engine):
    file_name = f'{render_engine}_blank.exr'
    blank_image_path = os.path.join(root,file_name)
    return blank_image_path


def remove_turbo_tools_asset(asset_name,inner_blend_directory):
    """
    When fake user functionality is removed use this to delete all turbo tools asset before reloading
    """
    # to_remove = []
    # #remove node groups
    # for item in eval(f'bpy.data.{inner_blend_directory}'):
    #     if item.startswith('turbo_tools'):
    #         to_remove.append(item.name)
    # for item in to_remove:        
    #     #exec("eval(f'bpy.data.{inner_blend_directory}').remove(item)")
    item = eval(f'bpy.data.{inner_blend_directory}["{asset_name}"]')
    exec("eval(f'bpy.data.{inner_blend_directory}').remove(item)")
    #bpy.data.node_groups.remove(bpy.data.node_groups['turbo_tools_median'])

def remove_all_turbo_tools_assets(inner_blend_directory):
    to_remove = []
    #remove node groups
    for item in eval(f'bpy.data.{inner_blend_directory}'):
        if item.name.startswith('turbo_tools'):
            to_remove.append(item.name)
    for item in to_remove:        
        asset = eval(f'bpy.data.{inner_blend_directory}["{item}"]')
        exec("eval(f'bpy.data.{inner_blend_directory}').remove(asset)")
        #exec("eval(f'bpy.data.{inner_blend_directory}').remove(item)")



def append_items(blend_file_name,inner_directory,asset_name,inner_blend_directory,scene_name = None):
    blend_path = os.path.join(root,blend_file_name)
    try:        
        
        bpy.ops.wm.append(filepath= os.path.join(blend_path, inner_directory, asset_name),
                            directory= os.path.join(blend_path,inner_directory),
                            filename= asset_name,
                            set_fake=True,
                            do_reuse_local_id = True,
                            link=False,
                            use_recursive=True                                
                            )

        bpy.data.libraries.remove(bpy.data.libraries[blend_file_name])
            
    except Exception as e:
        if scene_name is not None:
            report_custom_error.store_error(scene_name,f'Failed to Append {asset_name}.  Contact support for assistance as support@3d-illusions.co.uk')
        else:
            print(f'failed to append turbo tools {inner_directory}')
            print(e)
        return False
    return True

def link_all():
    remove_all_turbo_tools_assets('node_groups')
    append_items('node_groups.blend','NodeTree','turbo_tools_median','node_groups')


# def link_all():
#     for file in os.listdir(root):
#         if file.endswith('.blend'):
#             if file in bpy.data.libraries:
#                 bpy.data.libraries[file].reload()
#             else:
#                 blend_path = os.path.join(root,file)
#                 with bpy.data.libraries.load(blend_path,link=False) as (data_from, data_to):
#                     #data_to.node_groups = [name for name in data_from.node_groups]
#                     for attr in dir(data_to):
#                         #if  eval(f'bpy.data.{attr}'):
#                         setattr(data_to, attr, getattr(data_from, attr))
