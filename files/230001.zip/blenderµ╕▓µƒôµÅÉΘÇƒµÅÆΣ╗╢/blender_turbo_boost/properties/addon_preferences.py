
import bpy
from ..variables import global_vars
import os

def update_all_scenes_cache_folder(self,context):
        for s in bpy.data.scenes:
            if s.Turbo_Cache_Folder == 'Please specify':# removed this next bit because the user might have a drive accidentally disconnected where there cache resides.  give a message in the pre check instead or not os.path.isdir(s.Turbo_Cache_Folder):
                s.Turbo_Cache_Folder  = bpy.context.preferences.addons[__name__.split('.')[0]].preferences.cache_folder
        current_scene_cache_folder = context.scene.Turbo_Cache_Folder
        bpy.types.Scene.Turbo_Cache_Folder = bpy.props.StringProperty(name='turbo_cache_folder',description='Where to store Turbo Tools cache for the current scene',
                                                                    subtype='DIR_PATH',
                                                                    default= bpy.context.preferences.addons[__name__.split('.')[0]].preferences.cache_folder,
                                                                        )
        context.scene.Turbo_Cache_Folder = current_scene_cache_folder
       


class Turbo_Render_Preferences(bpy.types.AddonPreferences):
    bl_idname = __name__.split('.')[0]

    if global_vars.testing:
        default_cache = 'e:/temp/cache/'
    else:
        default_cache = 'Please specify'

    keep_cache : bpy.props.BoolProperty(name='animation',
                                        description="Enabled\n\nFor every frame of the rendered animation, cache files will be kept on disk for every unique render layer node and each user cache node (useful for comping full animations)\n\n" \
                                            "Disabled (default)\n\nWhen disabled only the most recent cache file will be kept for each unique render layer node and user cache nodes.\n\n" \
                                            "-- WARNING -- Large animations may need a lot of hard drive space. Check the size of the cache folder (located in the blend file directory) before rendering too many frames.",
                                        default=True,)
    
    cache_folder : bpy.props.StringProperty(name='project cache folder'
                                            ,description='Sets the default location to store the cache files.  This is used when creating a new scene.  Set it here for each new project to save you having to do it repeatedly.  If you have \'animation\' enabled, ensure you have sufficient space. \n\n'\
                                                'If you need to move your files to a different computer, to avoid losing access to the renders, zip up the cache folder and then unzip it on the new computer,'\
                                                    ' then change the cache folder option on the new computer so that it points to the new location on that machine.\n\n'\
                                                        'IMPORTANT - Make sure you specify a different cache folder per project to avoid overwriting other project\'s files, or when trying out different compositor setups for the same project '
                                            ,subtype='DIR_PATH', default= default_cache,update=update_all_scenes_cache_folder)#bpy.utils.resource_path('USER'))
                                            
                                            #file_system_helpers.get_absolute_path(f'{Path(sys.executable).anchor}Blender_Turbo_Boost/Compositor_Cache/'))
    
    bit_depth_options = [
                        ('16','16 bit','',1),
                        ('32','32 bit','',2),
    ]


    render_layer_bit_depth : bpy.props.EnumProperty(items=bit_depth_options,name='render layer cache bit depth',
                                              description='sets the bit depth of the cache files that are created for the render layer nodes.  16 bit (half float), or 32 bit (full float)'\
                                                  '.\n\n16 bit is generally sufficient for compositing needs will offer higher performance during playback, and lower disk space usage, but will lose some dynamic range\n\n',default='16')
    
    non_render_layer_bit_depth : bpy.props.EnumProperty(items=bit_depth_options,name='non render layer cache bit depth',
                                              description='sets the bit depth of the cache files that are created for non render layer nodes.  16 bit (half float), or 32 bit (full float)'\
                                                  '.\n\n16 bit will offer higher performance during playback, and lower disk space usage, but will lose some dynamic range\n\n',default='16')

    # cache_resolution_percent : bpy.props.IntProperty(name=f'standard cache resolution %',
    #                                                  description=f'sets the resolution % of non render layer cache files in relation to the scene output resolution.\n\n'\
    #                                                      f"On an i7-7700k, 30 % resulted in fast playback when the render output resolution was set to 1920 x 1080",min=1,max=100,default = 30,subtype='PERCENTAGE',)

    


    def draw(self, context):
        layout = self.layout
        layout.emboss ='NORMAL'
            
        box = layout.box()
        
        
        #layout.label(text='Compositor Cache Options')
        #split = box.split()
        
        box.label(text ='Compositor Cache Options')        
        #split = box.split(factor= 0.8)
        #box = split.column()
        #box.scale_x = 2
        box.prop(self,'cache_folder',expand =True)
        #box.prop(self, 'keep_cache', expand=True)
        
        layout.row().separator()
        #layout.label(text='Compositor Performance Options)')
        box = layout.box()
        box.label(text = 'Compositor Performance Options')
        
        
        row = box.row()
        row.label(text='render layer cache bit depth')        
        row.prop(self, 'render_layer_bit_depth',expand = True)

        row = box.row()
        row.label(text='standard cache bit depth')        
        row.prop(self, 'non_render_layer_bit_depth',expand = True)

        
        
        
    