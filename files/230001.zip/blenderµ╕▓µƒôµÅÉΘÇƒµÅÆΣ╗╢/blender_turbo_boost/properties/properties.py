import bpy
from ..operators.dont_register import optimisations
from ..variables import global_vars




def enum_members_from_type(rna_type, prop_str):
    prop = rna_type.bl_rna.properties[prop_str]
    return [tuple((e.identifier,e.identifier,'',i)) for i,e in enumerate(prop.enum_items)]

image_fs = enum_members_from_type(bpy.types.ImageFormatSettings,'file_format')
turbo_modes = [('Draft','draft/rapid (outputs cleaned image pass only)','',1),('Medium','medium (outputs cleaned image pass only)','',2),('High','high (outputs cleaned image pass only)','',3),('Ultra','Ultra (outputs cleaned passes)','',4)]
render_setting_presets = [('Crap','Crap','',1),('Medium Rare','Medium Rare','',2),('Medium','Medium','',3),('High','High','',4),('Very High','Very High','',5),('Ultra','Ultra','',6),('Insane','Insane','',7),('User','User','',8)]


def register():
    
        
    image_formats = [l for l in image_fs if 'AVI' not in l and  'FFMPEG' not in l and 'AVI_JPEG' not in l and 'AVI_RAW' not in l]
   

    bpy.types.Scene.Turbo_Cache_Folder = bpy.props.StringProperty(name='turbo_cache_folder',description='Where to store Turbo Tools cache for the current scene',
                                                                        subtype='DIR_PATH',
                                                                        default= bpy.context.preferences.addons[__name__.split('.')[0]].preferences.cache_folder,
                                                                        )

    bpy.types.Scene.Keep_Cache = bpy.props.BoolProperty(name='keep_cache',
                                                        description="Enabled\n\nFor every frame of the rendered animation, cache files will be kept on disk for every unique render layer node and each user cache node (useful for comping full animations)\n\n" \
                                            "Disabled (default)\n\nWhen disabled only the most recent cache file will be kept for each unique render layer node and user cache nodes.\n\n" \
                                            "-- WARNING -- Large animations may need a lot of hard drive space. Check the size of the cache folder (located in the blend file directory) before rendering too many frames.",
                                        default=True,)

    bpy.types.Scene.file_out_format = bpy.props.EnumProperty(items=image_formats,name='file format',
                                              description='choose the file format for the file output node to save to',default='JPEG')

    bpy.types.Scene.Render_Setting_Presets = bpy.props.EnumProperty(items=render_setting_presets,name='render setting presets',
                                              description='Crap - Low quality render settings (Very fast. Suitable for draft previews)' \
                                                    '\n\nMedium Rare - Ideal for vampires (This is the same as \'Medium\' in Turbo Tools versions below 3.0.0. Only recommended for still images as it may introduce artefacts during an animation.)'\
                                                    '\n\nMedium - Medium quailty (A middle ground between Medium Rare and High)'\
                                                    '\n\nHigh - High quality (this is the minimum recommended setting for animation)'\
                                                    '\n\nVery High - Very high quality (When the Animation option below is enabled, and you plan to use Temporal flicker removal, this will generally provide production quality results unless there are extremely difficult to render scene elements.)'\
                                                    '\n\nUltra - Ultra quality (you should be able to get away with turning off \'very dirty\')'\
                                                    '\n\nInsane - You\'re in for a long wait, but this will be pristine (turn off \'very dirty\') ' \
                                                    '\n\nUser - It\'s time for the big boy pants! User\'s sample settings will be used (Use if presets aren\'t ideal, or if you\'re a legend)',default='Crap')

    
    bpy.types.Scene.Turbo_Mode = bpy.props.EnumProperty(items=turbo_modes,name='turbo mode',
                                              description='\ndraft/rapid - extremely fast.  Suitable for final renders in scenes that render to a denoisable state in under 30 seconds, and draft renders for scenes that take 1 minute upwards.\n'\
                                                    '\nmedium - slower than draft, but will do a better job at retaining details.  At low render settings shadows may be a little wobbly or missing.\n'\
                                                    '\nhigh - very crisp lighting, shadow, and reflection details even at lower render settings.\n'\
                                                    '\nultra - very slow, but will provide the best quality and will also clean the necessary passes for use in post.' \
                                                    ' The passes cleaned are dependant on the \' visible to camera\' options below.  Can also be used to correct blurry/wobbly geometry at low samples',default='Draft')
                        
    bpy.types.Scene.only_linked = bpy.props.BoolProperty(name='only_linked',description='only wire up output sockets from the selected node/s to the file output node if they already have a wire to elsewhere on the node tree'
                                                            ,default=False)

    bpy.types.Scene.Firefly_Removal = bpy.props.BoolProperty(name='firefly_removal',description='\n(Recommended) Prevents fireflies (bright white dots) by optimising clamping.  Also helps the image clean up faster meaning you can use less samples.'\
                                                            ' May reduce brightness slightly, but this can easily be increased in the compositor after rendering.  \n\nAffects viewport rendering and final rendering\n'
                                                            ,default=True,update= optimisations.prevent_fireflies)

    bpy.types.Scene.Interior_Mode = bpy.props.BoolProperty(name='interior_mode',description='\nOptimises sample presets for interior scenes to improve scenes which have a lot of indirect lighting.  May not be needed at higher samples', default = False)

    bpy.types.Scene.Optimise_HDRI = bpy.props.BoolProperty(name='optimise_hdri',description='\nOptimises the importance map for up to 10x faster rendering and less memory consumption during rendering (scene dependant).  Disable if you notice increased noise in volumes.\n\nOnly enable if your HDRI is 4k or above.  Performance improvements will be more noticable with higher resolution HDRI\'s (8k or above).\n\nAffects viewport rendering and final rendering', default = True,update= optimisations.optimise_hdri)

    bpy.types.Scene.Validate_Cache_During_Playback = bpy.props.BoolProperty(name='validate_cache_during_playback',description='This will automatically check the entire tree and recalculate individual cache nodes during playback if something downstream has changed. Extremely slow, so it\'s best to only enable this when you know something has changed downstream of a cache node.'
                                                            ,default=False)


    bpy.types.Scene.execute_file_output_nodes_during_publish = bpy.props.BoolProperty(name='execute_file_outputs_during_publish',description='Enable if you want the unmuted file output nodes to generate new images during publish'\
                                                                            '.\n\nUseful if you want to generate several takes.  Note, only the composite node will use the output settings set in the scene output panel'\
                                                                                ', the file output nodes will generate still images in the format specified in each.'
                                                                        ,default=False)
                                
    bpy.types.Scene.QuickPublish = bpy.props.BoolProperty(name='quick_publish',description="use cache resolution and upscale to render resolution.\n\n"\
                                                        "(lower quality, but very fast if your cache is up to date as no need to re-calculate what's cached)"\
                                                            "\n\nWARNING - Frames with no cache will render black."
                                                        ,default=False)

    bpy.types.Scene.Turbo_Render = bpy.props.BoolProperty(name='turbo_render',description='Enable turbo rendering.  This will provide dramatically better results'\
                                                        'than enabling denoising in the sampling settings.  \n\nIMPORTANT - when rendering multiple scenes from one compositor, each scene\'s own Turbo Render options will be used.'
                                                        ,default=False,update=optimisations.initialise_optimisations)
    
    bpy.types.Scene.Turbo_Clean_Col = bpy.props.BoolProperty(name='clean_color_passes',description='If your render looks grainy even with turbo render enabled (most likely if you have SSS materials), then try enabling this'\
                                                        ', it will slow the render down by approx 10 seconds but should remove the grain.  Its a good idea to render a small render region using (ctrl b and draw the region in the 3d viewport) to test quickly if extreme is needed'
                                                        ,default=False)
    
    bpy.types.Scene.Optimise_For_Anim = bpy.props.BoolProperty(name='optimise_for_anim',description='Enable this to optimise the sample presets for animations.  May take longer, but should help to ensure better results.' \
                                                        '  Very high will generally provide production quality renders unless the scene has extremely difficult to render elements.  Consider rendering those in a separate scene and combining in the compositor.',default=False)

    bpy.types.Scene.Turbo_Geo = bpy.props.BoolProperty(name='turbo_geo',description='Enable if non-volumetric geometry will be visible to the camera.  Turn off if not needed for an even faster render!',default=True)
    bpy.types.Scene.Turbo_Diff = bpy.props.BoolProperty(name='turbo_diff',description='Enable if diffuse materials will be visible to the camera.  Turn off if not needed for an even faster render!',default=True)
    bpy.types.Scene.Turbo_Gloss = bpy.props.BoolProperty(name='turbo_diff',description='Enable if glossy materials will be visible to the camera.  Turn off if not needed for an even faster render!',default=True)
    bpy.types.Scene.Turbo_Trans = bpy.props.BoolProperty(name='turbo_trans',description='Enable if transmission in view (glass,water,etc).  Turn off if not needed for an even faster render!',default=False)

    bpy.types.Scene.Turbo_Volume = bpy.props.BoolProperty(name='turbo_volume',description='Enable if volume shaders in view (principled volume, volume absorption, volume scatter). Turn off if not needed for an even faster render!',default=False, update = optimisations.optimise_hdri)

    bpy.types.Scene.Turbo_Emission = bpy.props.BoolProperty(name='turbo_emission',description='Enable if materials with emission in view. Turn off if not needed for an even faster render!',default=False)

    bpy.types.Scene.Turbo_Env = bpy.props.BoolProperty(name='turbo_env',description='Scene has visible world environment (hdri etc). Turn off if not needed for an even faster render!',default=False)
    bpy.types.Scene.Turbo_Emit = bpy.props.BoolProperty(name='turbo_emit',description='Scene has visible emission materials (hdri etc). Turn off if not needed for an even faster render!',default=False)

    bpy.types.Scene.Env_Only_Behind_Glass = bpy.props.BoolProperty(name='env_only_behind_glass',description='If the world environment is ONLY visible through a transmissive material such as glass or water, enable to ensure render time is as fast as possible \n\n'\
                                                           
                                                        'Turn off if not needed for an even faster render!',default=False)

    bpy.types.Scene.Emit_Behind_Glass = bpy.props.BoolProperty(name='emit_behind_glass',description='Enable if an emission is ONLY visible through a transmissive material such as glass or water\n\n'\
                                                            
                                                        'Turn off if not needed for an even faster render!',default=False)

    bpy.types.Scene.Env_Behind_Vol = bpy.props.BoolProperty(name='env_behind_volume',description='Enable if the world environment shader (hdri etc) is visible through the volume. Turn off if not needed for an even faster render!',default=False)
    bpy.types.Scene.Emission_Behind_Vol = bpy.props.BoolProperty(name='emission_behind_volume',description='Enable if there is emission visible through the volume. Turn off if not needed for an even faster render!',default=False)
    bpy.types.Scene.Geometry_Behind_Vol = bpy.props.BoolProperty(name='geometry_behind_volume',description='Enable if there is geometry visible through the volume. Turn off if not needed for an even faster render!',default=False)
    bpy.types.Scene.Trans_Behind_Vol = bpy.props.BoolProperty(name='trans_behind_volume',description='Geometry behind volume has a transmissive material (glass,water,etc). Leaving disabled will result in a faster render but may cause noise on transmissive surfaces visible through volumes',default=False)
    bpy.types.Scene.Diff_Behind_Vol = bpy.props.BoolProperty(name='diff_behind_volume',description='Geometry behind volume has a material with a diffuse element(principled bsdf, diffuse bsdf, etc).Leaving disabled will result in a faster render but may cause noisy lighting/shadows visible through volumes',default=False)
    bpy.types.Scene.Gloss_Behind_Vol = bpy.props.BoolProperty(name='gloss_behind_volume',description='Geometry behind volume has a transmissive material (principled with transmission enabled, glass bsdf, refraction bsdf). Leaving disabled will result in a faster render but may cause noisy reflections visible through volumes',default=False)

    bpy.types.Scene.Heavy_DOF = bpy.props.BoolProperty(name='heavy_dof',description='Enable if your camera has heavy DOF and the test renders have grain even with Turbo Render enabled.'\
                                                        '\nIn fast mode with enhance textures enabled, this setting can also be used to get rid of any artefacts at the edge of objects. Turn off if not needed for an even faster render!',default=False)

    bpy.types.Scene.Turbo_SSS = bpy.props.BoolProperty(name='turbo_sss',description='Enable if SSS (sub surface scattering material) is visible to the camera.  Turn off if not needed for an even faster render!',default=False)

    bpy.types.Scene.Turbo_Render_HQ = bpy.props.BoolProperty(name='turbo_render_HQ',description='Use if you\'re trying to render at extremely low sample counts or notice noise in the rendered image. WARNING - May result in loss of detail on intentionally noisy textures such as distant grass, particularly behind glass.\n\nGenerally not needed at higher samples',default=True)
    bpy.types.Scene.Turbo_Render_Enhance_Textures = bpy.props.BoolProperty(name='turbo_render_enhance_textures',description='\nPrevents texture detail being lost during denoising.  If noise around the edge of objects appears when this is enabled, turn on the \'heavy DOF/Motion Blur\' option. \n\nOnly necessary/available in Fast Mode as extreme mode automatically preserves texture details.',default=True)
    bpy.types.Scene.Turbo_Render_Enhance_Glossy = bpy.props.BoolProperty(name='turbo_render_enhance_glossy',description='\nEnhances glossy details.  If noise around the edge of objects appears when this is enabled, turn on the \'heavy DOF/Motion Blur\' option. \n\nOnly necessary/available in Fast Mode as extreme mode automatically preserves details.',default=False)
    bpy.types.Scene.Turbo_Render_Enhance_Trans = bpy.props.BoolProperty(name='turbo_render_enhance_trans',description='\nEnhances transmission details.  If noise around the edge of objects appears when this is enabled, turn on the \'heavy DOF/Motion Blur\' option. \n\nOnly necessary/available in Fast Mode as extreme mode automatically preserves details.',default=False)

    bpy.types.Scene.Standard_Cache_Resolution = bpy.props.IntProperty(name='standard_cache_resolution',description='\nWhen clicking the above \'cache/uncache\' button,' \
                                                                    'a cache node will be created at this percent of the render resolution.  Lower values give better performance when compositing and faster FPS during playback.',default=30,subtype='PERCENTAGE',min=1,max=100)

    bpy.types.Scene.Temporal_Publish = bpy.props.BoolProperty(name='temporal_publish',description='Attempts to removes flicker between frames.  Should only be used on denoised data.  If using with non cycles renders, ensure it\'s a multilayer exr with a vector pass',default=False)
    
    bpy.types.Scene.Motion_Blur_Warning = bpy.props.BoolProperty(name='motion_blur_warning',description = 'Some scenes that will be rendered from this scene\'s compositor have motion blur enabled in the render settings.' \
                                                                                                                ' This means they can\'t be temporally stabilised during publishing.  Disable motion ' \
                                                                                                                    'blur if you want the option to temporally stabilised their render results when publishing. \n\n' \
                                                                                                                        'Scenes with motion blur disabled can be temporally stabilised as usual',default= 1)

    bpy.types.Scene.Temporal_RGBA_Seperately = bpy.props.BoolProperty(name='temporal_rgba_seperately',description='Temporalises RGBA channels seperately (recommended).  Slower, but helps reduce the chance of artefacts or strange results.  May not be necessary if you\'re building the image from the individual passes',default=True)

def unregister():
    
    del bpy.types.Scene.Turbo_Cache_Folder
    del bpy.types.Scene.Keep_Cache 
    del bpy.types.Scene.file_out_format
    del bpy.types.Scene.Render_Setting_Presets    
    del bpy.types.Scene.Turbo_Mode
    del bpy.types.Scene.only_linked
    del bpy.types.Scene.Firefly_Removal
    del bpy.types.Scene.Validate_Cache_During_Playback
    del bpy.types.Scene.execute_file_output_nodes_during_publish
    del bpy.types.Scene.QuickPublish
    del bpy.types.Scene.Turbo_Render
    del bpy.types.Scene.Turbo_Clean_Col
    del bpy.types.Scene.Turbo_Geo
    del bpy.types.Scene.Turbo_Diff
    del bpy.types.Scene.Turbo_Gloss
    del bpy.types.Scene.Turbo_Trans
    del bpy.types.Scene.Turbo_Volume
    del bpy.types.Scene.Turbo_Emission
    del bpy.types.Scene.Turbo_Env
    del bpy.types.Scene.Turbo_Emit
    del bpy.types.Scene.Env_Only_Behind_Glass
    del bpy.types.Scene.Emit_Behind_Glass
    del bpy.types.Scene.Env_Behind_Vol
    del bpy.types.Scene.Emission_Behind_Vol
    del bpy.types.Scene.Geometry_Behind_Vol
    del bpy.types.Scene.Trans_Behind_Vol
    del bpy.types.Scene.Diff_Behind_Vol
    del bpy.types.Scene.Gloss_Behind_Vol
    del bpy.types.Scene.Heavy_DOF
    del bpy.types.Scene.Turbo_SSS
    del bpy.types.Scene.Turbo_Render_HQ
    del bpy.types.Scene.Turbo_Render_Enhance_Textures
    del bpy.types.Scene.Turbo_Render_Enhance_Glossy
    del bpy.types.Scene.Turbo_Render_Enhance_Trans
    del bpy.types.Scene.Standard_Cache_Resolution 
    del bpy.types.Scene.Temporal_Publish


