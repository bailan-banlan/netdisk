import bpy

def optimise_hdri(self,context):
    scene_name = context.scene.name
    
    if bpy.data.scenes[scene_name].world is not None:
        #context.scene.update_tag()
        if bpy.data.scenes[scene_name].Optimise_HDRI and bpy.data.scenes[scene_name].Turbo_Render:
            if 'user_sample_map_resolution' not in bpy.data.scenes[scene_name] and 'user_sampling_method' not in bpy.data.scenes[scene_name]:
                bpy.data.scenes[scene_name]['user_sample_map_resolution'] = bpy.data.scenes[scene_name].world.cycles.sample_map_resolution
                bpy.data.scenes[scene_name]['user_sampling_method'] = bpy.data.scenes[scene_name].world.cycles.sampling_method
            bpy.data.scenes[scene_name].world.cycles.sampling_method = 'MANUAL'
            
            if bpy.data.scenes[scene_name].Turbo_Volume:            
                bpy.data.scenes[scene_name].world.cycles.sample_map_resolution = 4096
            else:
                bpy.data.scenes[scene_name].world.cycles.sample_map_resolution = 4096

            
        else:
            if 'user_sample_map_resolution' in bpy.data.scenes[scene_name]:
                bpy.data.scenes[scene_name].world.cycles.sample_map_resolution = bpy.data.scenes[scene_name]['user_sample_map_resolution']
                del bpy.data.scenes[scene_name]['user_sample_map_resolution']
            if 'user_sampling_method' in bpy.data.scenes[scene_name]:
                bpy.data.scenes[scene_name].world.cycles.sampling_method = bpy.data.scenes[scene_name]['user_sampling_method']
                del bpy.data.scenes[scene_name]['user_sampling_method']
        #bpy.data.scenes[scene_name].frame_set(bpy.data.scenes[scene_name].frame_current)
        #context.scene.update()
        #bpy.context.scene.update_tag()
        #bpy.context.view_layer.update()

def prevent_fireflies(self,context):
    scene_name = context.scene.name
    if bpy.data.scenes[scene_name].render.engine == 'CYCLES':
        if bpy.data.scenes[scene_name].Firefly_Removal and bpy.data.scenes[scene_name].Turbo_Render:
            #if 'user_clamp_direct' not in bpy.data.scenes[scene_name] and 'user_indirect_clamp' not in bpy.data.scenes[scene_name]:
            bpy.data.scenes[scene_name]['user_clamp_direct'] = bpy.data.scenes[scene_name].cycles.sample_clamp_direct
            bpy.data.scenes[scene_name]['user_indirect_clamp'] = bpy.data.scenes[scene_name].cycles.sample_clamp_indirect

            if bpy.data.scenes[scene_name].cycles.sample_clamp_direct > 4 or bpy.data.scenes[scene_name].cycles.sample_clamp_direct == 0:
                bpy.data.scenes[scene_name].cycles.sample_clamp_direct = 4
            if bpy.data.scenes[scene_name].cycles.sample_clamp_indirect > 10 or bpy.data.scenes[scene_name].cycles.sample_clamp_indirect ==0:
                bpy.data.scenes[scene_name].cycles.sample_clamp_indirect = 10
        else:
            if 'user_clamp_direct' in bpy.data.scenes[scene_name]:
                bpy.data.scenes[scene_name].cycles.sample_clamp_direct = bpy.data.scenes[scene_name]['user_clamp_direct']
                del bpy.data.scenes[scene_name]['user_clamp_direct']
            if 'user_clamp_indirect' in bpy.data.scenes[scene_name]:
                bpy.data.scenes[scene_name].cycles.sample_clamp_indirect = bpy.data.scenes[scene_name]['user_clamp_indirect']
                del bpy.data.scenes[scene_name]['user_clamp_indirect']


def initialise_optimisations(self,context):
    
    optimise_hdri(self,context)
    prevent_fireflies(self,context)