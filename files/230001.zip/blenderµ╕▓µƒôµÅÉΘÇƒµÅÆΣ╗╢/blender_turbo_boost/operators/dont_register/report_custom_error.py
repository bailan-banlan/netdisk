import bpy
import traceback


def notify_user(scene_name,messages = None, title = "Turbo Tools Message", icon = 'INFO'):
    """
    pass in a list of messages and it creates a single popup with a label for each error
    """
    if not messages:
        messages = []
    scene = bpy.data.scenes[scene_name]
    stored_errors = get_stored_errors(scene_name)
    if stored_errors:
        messages.extend(stored_errors)
        del scene['custom_error']
    
    def draw(self, context):
        
        for the_message in messages:
            n = 180
            chunks = [the_message[i:i+n] for i in range(0, len(the_message), n)]
            for chunk in chunks:
                self.layout.label(text = chunk)
            #print(the_message)
        
    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)
    error = traceback.format_exc()
    stack_trace = error.split('\n')
    if stack_trace:
        for s in stack_trace[-10:]:
            pass
            #print(stack_trace[len(stack_trace)-10:len(stack_trace)+1])
            #print('\n',s)


def store_error(scene_name,message):
    scene = bpy.data.scenes[scene_name]
    if 'custom_error' in scene:
        custom_error = list(scene['custom_error'])
    else:
        custom_error = []
    custom_error.append(message)
    scene['custom_error'] = custom_error

    return

def get_stored_errors(scene_name):
    scene = bpy.data.scenes[scene_name]
    if 'custom_error' in scene:
        custom_error = list(scene['custom_error'])
        return custom_error
    else:
        return None



# def print_stack_after_exception(lines):
#     """pass in the number of line to print from the end of the stack"""
#     error = traceback.format_exc()
#     stack_trace = error.split('\n')
#     for s in stack_trace[-lines:]:
#                                     #print(stack_trace[len(stack_trace)-10:len(stack_trace)+1])
#         print('\n',s)
   


def print_stack_after_exception(lines):
    """pass in the number of line to print from the end of the stack"""
    return
    error = traceback.format_exc()
    stack_trace = error.split('\n')
    for s in stack_trace[-lines:]:
        print(stack_trace[len(stack_trace)-10:len(stack_trace)+1])
        print('\n',s)

