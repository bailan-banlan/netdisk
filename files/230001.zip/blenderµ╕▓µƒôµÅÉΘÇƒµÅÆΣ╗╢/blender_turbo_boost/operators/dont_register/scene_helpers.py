
from ..dont_register import node_helpers,file_system_helpers,checks,cache_operations,cache_operation_helpers,temporal

import bpy
from ...variables import global_vars



def compositor_is_visible(scene_name):
    
    if bpy.data.scenes[scene_name].use_nodes:
        wm = bpy.context.window_manager        
        
        for window in wm.windows:
            
            for area in window.screen.areas:
                space = area.spaces[0]
                if space.type == 'NODE_EDITOR' and space.tree_type == 'CompositorNodeTree':
                        #there's a compositor, do the refresh
                    return True

    return False

def disable_comp_backdrop():
    wm = bpy.context.window_manager        
     
    for window in wm.windows:
        #print('windows are',window.screen)
        for area in window.screen.areas:
            #print('areas are', area.type)
            for space in area.spaces[0]:
                #print('space is', space.type)
                if space.type == 'NODE_EDITOR' and space.node_tree.type == 'COMPOSITING':
                    
                    #there's a compositor, do the refresh
                    space.show_backdrop = False
                    #print('comp backdrop disabled')
    
    return


def enable_comp_backdrop():
    wm = bpy.context.window_manager        
     
    for window in wm.windows:
        #print('windows are',window.screen)
        for area in window.screen.areas:
            #print('areas are', area.type)
            for space in area.spaces:
                #print('space is', space.type)
                if space.type == 'NODE_EDITOR' and space.node_tree.type == 'COMPOSITING':
                    #there's a compositor, do the refresh
                    space.show_backdrop = True
                    #print('comp backdrop enabled!')

    return

def change_compositor_zoom_level(scene_name,new_zoom_level):
    scene = bpy.data.scenes[scene_name]
    if scene.use_nodes:
        wm = bpy.context.window_manager
        for window in wm.windows:            
            for area in window.screen.areas:
                space = area.spaces[0]
                if space.type == 'NODE_EDITOR' and space.tree_type == 'CompositorNodeTree':
                        space.backdrop_zoom = new_zoom_level
                  

def store_start_zoom_per_visible_compositor(scene_name):
    #print('hiding comps')
    comp_area_zoom_list = []
    for i, area in enumerate(bpy.data.window_managers[0].windows[0].screen.areas):
        space = area.spaces[0]
        #print(space.type)
        if space.type == 'NODE_EDITOR' and space.tree_type == 'CompositorNodeTree':
            
            comp_area_zoom_list.append((int(i),space.backdrop_zoom))
    global_vars.comp_area_zoom_list = comp_area_zoom_list
    

def update_comp_zoom_areas(scene_name):
    if checks.scene_contains_unmuted_quality_node(scene_name):    
        scene = bpy.data.scenes[scene_name]
        if global_vars.comp_area_zoom_list is not None:
            for lst in global_vars.comp_area_zoom_list:
                try:
                    space = bpy.data.window_managers[0].windows[0].screen.areas[int(lst[0])].spaces[0]
                    space.backdrop_zoom = (scene['original render resolution'] / scene.playback_quality) * lst[1]
                except:# IndexError:
                    pass #user has changed ui during playback


# def unhide_comps():
#     for i in comp_areas:
#         bpy.data.window_managers[0].windows[0].screen.areas[i].ui_type = 'CompositorNodeTree'
def reset_zooms(scene_name):
    scene = bpy.data.scenes[scene_name]
    if global_vars.comp_area_zoom_list is not None:
        for lst in global_vars.comp_area_zoom_list:
            try:
                space = bpy.data.window_managers[0].windows[0].screen.areas[int(lst[0])].spaces[0]
                space.backdrop_zoom = lst[1]
            except IndexError:
               pass #user has changed ui during playback, no B.I.G



def update_node_tree_without_caching(scene_name):
    nodes = bpy.data.scenes[scene_name].node_tree.nodes
    rlnodes = [n for n in nodes if n.type == 'R_LAYERS' and n.mute == False]
    for n in rlnodes:
        n.mute = True
    cache_operation_helpers.do_cache_render(scene_name,False)
    for n in rlnodes:
        n.mute = False

def check_if_its_just_been_proper_rendered(scene_name):
    pass



def update_exr_during_publish(scene_name):

    cache_nodes = node_helpers.get_all_cache_nodes(scene_name)
    temporal_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if 'temporal_parent' in n]
    
    images_processed = set()
    if cache_nodes:        
        for c in cache_nodes:
                        
            if bpy.data.scenes[scene_name].node_tree.nodes[c].image.name not in images_processed:                
                #breakpoint()
                new_exr_path = file_system_helpers.get_exr(scene_name,c,wildcard_hash=True)                
                if file_system_helpers.file_exists(new_exr_path): 
                    bpy.data.scenes[scene_name].node_tree.nodes[c].image.filepath = new_exr_path
                    # this_nodes_temporal_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.name in temporal_nodes and n['temporal_parent'] == c]
                    # for n in this_nodes_temporal_nodes:
                    #     temporal.update_temporal_nodes_path(scene_name,n)
                else:pass
                    # if not checks.is_a_render_layer_cache_node(c,scene_name):
                    #     users_of_image = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'IMAGE' and n.image.name == bpy.data.scenes[scene_name].node_tree.nodes[c].image.name]
                    #     for u in users_of_image:
                    #         cache_operation_helpers.store_link_list_in_cache_node(u,scene_name)
                    #         cache_operation_helpers.move_links_from_cache_node_to_original_node(u,scene_name)
                    
                images_processed.add(bpy.data.scenes[scene_name].node_tree.nodes[c].image.name)

    #update all temporal image blocks
    
    #temporal.update_temporal_node_images(scene_name)
    temporal.update_standard_temporal_images(scene_name)

    nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if 'cache_being_temporalised' in n or 'user_being_temporalised' in n]
    #print('nodes being temporalised : ',nodes)
    for n in nodes:
        temporal.turn_off_displace_if_temporal_nodes_have_same_exr_as_current_node(scene_name,n)
        



def update_node_tree_and_get_latest_cache_exr(scene_name,do_render = True):
    """updates all cache nodes, and performs additional checks on standard cache nodes to make sure the downstream nodes havent changed, and if they have it recaches them and deletes the old cache file"""
    images_processed = set()
    cache_nodes_with_missing_or_out_of_date_cache_files = set()
    rl_cache_nodes = set()
    standard_cache_nodes = ()

    if bpy.data.scenes[scene_name].Validate_Cache_During_Playback:
        standard_cache_nodes = set(node_helpers.get_all_standard_cache_nodes(scene_name,get_muted=True))
        rl_cache_nodes = set(node_helpers.get_all_render_layer_cache_nodes(scene_name,get_muted=True))
    else:
        standard_cache_nodes = set(node_helpers.get_all_standard_cache_nodes(scene_name,get_muted=False))
        rl_cache_nodes = set(node_helpers.get_all_render_layer_cache_nodes(scene_name,get_muted=False))

    cache_nodes = set.union(standard_cache_nodes,rl_cache_nodes)
    rendered = False
    if cache_nodes:

        # get the new exr for this frame and update the cache nodes.  May be faster to only update the single image block....although i'm only upating one cache node per image datablock so perhaps not important.  Will test.
        for c in cache_nodes:
                      
            if bpy.data.scenes[scene_name].node_tree.nodes[c].image.name not in images_processed:                
                new_exr_path = file_system_helpers.get_exr(scene_name,c,wildcard_hash=True)                
                if file_system_helpers.file_exists(new_exr_path):                    
                    if bpy.data.scenes[scene_name].node_tree.nodes[c].mute == True:
                        bpy.data.scenes[scene_name].node_tree.nodes[c].image['temp_path'] = new_exr_path #do this so that it doesnt unnecessarily  
                    else: 
                        bpy.data.scenes[scene_name].node_tree.nodes[c].image.filepath = new_exr_path
                        images_processed.add(bpy.data.scenes[scene_name].node_tree.nodes[c].image.name)
                else:
                    #print('couldnt load file for',c,' ',new_exr_path)
                    if not c in rl_cache_nodes:# and bpy.data.scenes[scene_name].node_tree.nodes[c].mute == False:
                        cache_nodes_with_missing_or_out_of_date_cache_files.add(c)#its a standard cache node, so add it to the list of nodes that will be unmuted and re-rendered                        
                
        
        
        
                
        

        #check the newly loaded exr for this frame has a hash that matches the scene. 
        
        if bpy.data.scenes[scene_name].Validate_Cache_During_Playback:

                #check if the new file name (either in the image or the images temp_path (if it's muted)) needs a hash adding to it, ie its just been created.  the hash cant be generated at creation time, as the tree is different during the cache render (downstream scale nodes etc) 
            #the hash will always be updated if necessary even on muted nodes
            for c in standard_cache_nodes:
                
                
                    
                if bpy.data.scenes[scene_name].node_tree.nodes[c].image and c not in cache_nodes_with_missing_or_out_of_date_cache_files:
                    
                    if bpy.data.scenes[scene_name].node_tree.nodes[c].mute == True and 'temp_path' in bpy.data.scenes[scene_name].node_tree.nodes[c].image:
                        full_path = bpy.data.scenes[scene_name].node_tree.nodes[c].image['temp_path']
                    else: 
                        full_path = bpy.data.scenes[scene_name].node_tree.nodes[c].image.filepath
                    file_name = file_system_helpers.get_file_name_from_path(full_path)
                    if checks.needs_hashing(file_name):
                        if file_system_helpers.file_exists(full_path):
                            cache_operation_helpers.append_hash_to_exr_and_update_image_datablock(scene_name, [c])
                            bpy.data.scenes[scene_name].node_tree.nodes[c]['hash_up_to_date'] = True
                            #print('deleted node')
                            cache_operation_helpers.delete_redundant_exr(scene_name,[c])
                        else:
                            pass
                            #print('file for node',c,'has missing file',file_name)
                        #     cache_nodes_with_missing_or_out_of_date_cache_files.add(c)





            processed = []
            for c in standard_cache_nodes:
                if 'hash_up_to_date' not in bpy.data.scenes[scene_name].node_tree.nodes[c]:
                    if c not in cache_nodes_with_missing_or_out_of_date_cache_files:                
                        
                                            
                        if bpy.data.scenes[scene_name].node_tree.nodes[c].image.name not in processed: 
                            processed.append(bpy.data.scenes[scene_name].node_tree.nodes[c].image.name)
                            original = cache_operation_helpers.get_original_node_name_from_cache_node(scene_name,c)
                            #print('just about to get the hash when checking if the wildcard loaded hash is correct')
                            path_with_updated_hash = file_system_helpers.get_exr(scene_name,original)
                            if bpy.data.scenes[scene_name].node_tree.nodes[c].mute == False:
                                if bpy.data.scenes[scene_name].node_tree.nodes[c].image.filepath != path_with_updated_hash:
                                    cache_nodes_with_missing_or_out_of_date_cache_files.add(c)
                            
            
                else:
                    del bpy.data.scenes[scene_name].node_tree.nodes[c]['hash_up_to_date']
            
            #recache what needs re-caching        
            if cache_nodes_with_missing_or_out_of_date_cache_files:
                #unmute all render layer cache nodes we muted at the beginning and update their exr file
                muted = False
                if global_vars.nodes_muted_at_beginning_of_playback is not None:
                    muted = un_mute_playback_muted_cache_nodes(scene_name,unmute_render_layer=False,unmute_file_output_nodes=False)                

                    for node_name in global_vars.nodes_muted_at_beginning_of_playback: 
                        if checks.is_a_cache_node(node_name,scene_name):
                            if 'temp_path' in bpy.data.scenes[scene_name].node_tree.nodes[node_name].image:                            
                                bpy.data.scenes[scene_name].node_tree.nodes[node_name].image.filepath = bpy.data.scenes[scene_name].node_tree.nodes[node_name].image['temp_path']
            
                                
                cache_operations.refresh_selected_and_upstream(cache_nodes_with_missing_or_out_of_date_cache_files,scene_name,perform_mute_unmute=False)
                rendered = True            
                
                for n in global_vars.remove_after_cache:
                    bpy.data.scenes[scene_name].node_tree.nodes.remove(bpy.data.scenes[scene_name].node_tree.nodes[n])
                if muted:
                    re_mute_playback_muted_cache_nodes(scene_name)
        
        
        #del temp paths
        for c in cache_nodes:
            
            if 'temp_path' in bpy.data.scenes[scene_name].node_tree.nodes[c].image:
                del bpy.data.scenes[scene_name].node_tree.nodes[c].image['temp_path']  
        cache_nodes_with_missing_or_out_of_date_cache_files = None
     
    #un comment to check exr has all necessary layers to maintain links.  Slow and potentially prone to access violation.
        # for c in cache_nodes:
        #     bpy.data.scenes[scene_name].node_tree.nodes[c].image.reload()
        # if not checks.all_links_have_valid_from_sockets(scene_name):
        #     #bpy.ops.screen.animation_cancel(restore_frame=True)
        #     global_vars.not_frame_change_first_visit = None
        #     #report_custom_error.store_error(scene_name,'there is a cache node that doesnt have sufficient outputs to maintain all links, please re-render that cache node for any frames that you rendered or cached with different passes')
        #     #global_vars.first_playback_frame = None
        #     return False
    
    
    #this is for the wait for frame option, when enabled in preferences this will update viewport if it's not the first frame and it's playing (forces the ui to wait for the nodes to complete)
    if not rendered:
        if global_vars.playing is not None and global_vars.first_playback_frame is None:        
            cache_operation_helpers.do_cache_render(scene_name,False)
            #bpy.data.scenes[scene_name].update()
    global_vars.first_playback_frame = None #this is only used in the above if not rendered block.  It stops the first frame from rendering as this caused unfathomable access violations.
    return True

def mute_what_can_be_muted_before_playback(scene_name,keep_file_output_nodes_unmuted = False,keep_composite_nodes_unmuted = False):
    
    
    sel = [n for n in bpy.data.scenes[scene_name].node_tree.nodes if n.select == True and n.type == 'VIEWER']
    if not sel:
        sel = [n for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'VIEWER']
        
    downstream = set()
    end_nodes = set()
    
    cache_nodes_to_keep = set()
    for a in sel:
        downstream,end_nodes =  node_helpers.get_downsttream_nodes(a.name,scene_name,downstream,end_nodes)
        downstream.add(a.name)

    cache_nodes_not_to_mute = [n for n in end_nodes if bpy.data.scenes[scene_name].node_tree.nodes[n].mute == False and checks.is_a_cache_node(n,scene_name)]
    
    #downstream from the viewer to the first cache nodes
    nodes_not_to_mute = downstream

    
    nodes_to_mute = set([n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.name not in nodes_not_to_mute and n.mute == False])# and n.type != 'VIEWER']
    

    #mute all render layer nodes
    rl_nodes = set([rl.name for rl in bpy.data.scenes[scene_name].node_tree.nodes if rl.type == 'R_LAYERS' and rl.mute == False])

    nodes_to_mute.update(rl_nodes)

    for n in nodes_to_mute:
        bpy.data.scenes[scene_name].node_tree.nodes[n].mute = True
        #nodes[n]['cache_mute'] = True

    global_vars.nodes_muted_at_beginning_of_playback = nodes_to_mute

    return True





def un_mute_playback_muted_cache_nodes(scene_name,clear_variable = False,unmute_render_layer = True,unmute_file_output_nodes = True):
    
    to_unmute = global_vars.nodes_muted_at_beginning_of_playback
    #global_vars.nodes_muted_at_beginning_of_playback = None
    if to_unmute is not None:
        for n in to_unmute:
            if n in bpy.data.scenes[scene_name].node_tree.nodes:
                if not unmute_render_layer and bpy.data.scenes[scene_name].node_tree.nodes[n].type == 'R_LAYERS' :
                    pass
                elif not unmute_file_output_nodes and bpy.data.scenes[scene_name].node_tree.nodes[n].type == 'OUTPUT_FILE':
                    pass
                else:
                    bpy.data.scenes[scene_name].node_tree.nodes[n].mute = False
                
                #del nodes[n]['cache_mute']
            else:
                print('blender error node has already been deleted, please report to blender foundation')
        if clear_variable:
            global_vars.nodes_muted_at_beginning_of_playback = None
        
        return True
    return False
    
def re_mute_playback_muted_cache_nodes(scene_name):
    
    to_re_mute = global_vars.nodes_muted_at_beginning_of_playback
    #global_vars.nodes_muted_at_beginning_of_playback = None
    if to_re_mute is not None:
        for n in to_re_mute:
            if n in bpy.data.scenes[scene_name].node_tree.nodes:
                bpy.data.scenes[scene_name].node_tree.nodes[n].mute = True
                #nodes[n]['cache_mute'] = True
            else:
                print('blender error node has already been deleted, please report to blender foundation')