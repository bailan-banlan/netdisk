from ..dont_register.file_system_helpers import get_cache_file_path_from_original_node_name
import bpy
from ...variables import global_vars,consts
from ..dont_register import render_layer_operations,checks,cache_operation_helpers,node_helpers,turbo_render_helpers,cache_operations,temporal
from ...handlers import handlers
from . import turbo_render_helpers


#import queue

def store_user_render_settings(scene_name):
    '''stores the user's render settings before rendering'''
    if bpy.data.scenes[scene_name].render.engine == 'CYCLES':
        User_Render_Settings = {  
                        'Max_Samples':bpy.data.scenes[scene_name].cycles.samples,
                        'Min_Samples' : bpy.data.scenes[scene_name].cycles.adaptive_min_samples, 
                        'Noise_Threshold' : bpy.data.scenes[scene_name].cycles.adaptive_threshold,
                        'Time_Limit' : bpy.data.scenes[scene_name].cycles.time_limit, 
                        'Use_Adaptive' :bpy.data.scenes[scene_name].cycles.use_adaptive_sampling,                        
                        'Scene_Name' : scene_name
                       }
    if User_Render_Settings:
        return User_Render_Settings
                        
def assign_preset_render_settings(scene_name):
    '''overwrites the user settings with the chosen preset for that scene'''
    if bpy.data.scenes[scene_name].Interior_Mode:
        if bpy.data.scenes[scene_name].Optimise_For_Anim:
            settings = 'consts.Cycles_render_presets_interior_animation'
        else:
            settings = 'consts.Cycles_render_presets_interior'
    else:
        if bpy.data.scenes[scene_name].Optimise_For_Anim:
            settings = 'consts.Cycles_render_presets_animation'
        else:
            settings = 'consts.Cycles_render_presets'

    if bpy.data.scenes[scene_name].render.engine == 'CYCLES':
        bpy.data.scenes[scene_name].cycles.samples = eval(settings)[bpy.data.scenes[scene_name].Render_Setting_Presets]['Max_Samples']
        bpy.data.scenes[scene_name].cycles.adaptive_min_samples = eval(settings)[bpy.data.scenes[scene_name].Render_Setting_Presets]['Min_Samples']
        bpy.data.scenes[scene_name].cycles.adaptive_threshold = eval(settings)[bpy.data.scenes[scene_name].Render_Setting_Presets]['Noise_Threshold']
        bpy.data.scenes[scene_name].cycles.time_limit = eval(settings)[bpy.data.scenes[scene_name].Render_Setting_Presets]['Time_Limit']
        bpy.data.scenes[scene_name].cycles.use_adaptive_sampling = eval(settings)[bpy.data.scenes[scene_name].Render_Setting_Presets]['Use_Adaptive']




def set_render_settings_for_all_scenes(scene_name):
    
    render_layer_scene_names = set([n.scene.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'R_LAYERS' and n.mute == False])
    for render_layer_scene_name in render_layer_scene_names:        
        

        if bpy.data.scenes[render_layer_scene_name].Turbo_Render and bpy.data.scenes[render_layer_scene_name].render.engine in consts.valid_turbo_render_engines:
            if global_vars.all_user_render_settings is None:
                global_vars.all_user_render_settings = []
                
            global_vars.all_user_render_settings.append(store_user_render_settings(render_layer_scene_name))
            #update with the preset
            if bpy.data.scenes[render_layer_scene_name].Render_Setting_Presets != 'User':
                assign_preset_render_settings(render_layer_scene_name)
            
            


def revert_all_scenes_back_to_the_users_original_render_settings():
    if global_vars.all_user_render_settings is not None:
        for settings in global_vars.all_user_render_settings:
            bpy.data.scenes[settings['Scene_Name']].cycles.samples = settings['Max_Samples']
            bpy.data.scenes[settings['Scene_Name']].cycles.adaptive_min_samples = settings['Min_Samples']
            bpy.data.scenes[settings['Scene_Name']].cycles.adaptive_threshold = settings['Noise_Threshold']
            bpy.data.scenes[settings['Scene_Name']].cycles.time_limit = settings['Time_Limit']
            bpy.data.scenes[settings['Scene_Name']].cycles.use_adaptive_sampling = settings['Use_Adaptive']
            
    
    global_vars.all_user_render_settings = None

def render_setup_pre(scene_name):
    #print('Thread in pre_render handler = ',threading.currentThread().ident)
    #run_on_thread.run([run_on_thread.test])
    
    #queue_system.add_function_to_queue([run_on_thread.test])
    
    set_render_settings_for_all_scenes(scene_name)
    if 'cache_render' not in bpy.data.scenes[scene_name]: #it's an actual render rather than just updating the cache

        
        
        #unmute all reroute nodes to make sure if they're cached they get recached.  bit of a bug in blender it doesn't show if the reroute is muted..and it should never be muted really as it makes no difference.
        reroute_node_names = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'REROUTE' and n.mute == True]
        for r in reroute_node_names:
            bpy.data.scenes[scene_name].node_tree.nodes[r].mute = False
        global_vars.file_out_keep = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'OUTPUT_FILE']   
        nodes = bpy.data.scenes[scene_name].node_tree.nodes
        standard_cache_nodes = node_helpers.get_all_standard_cache_nodes(scene_name)    
        rl_cache_nodes = node_helpers.get_all_render_layer_cache_nodes(scene_name)

        cache_nodes = standard_cache_nodes + rl_cache_nodes

        #store all exr files currently in use by the cache nodes to avoid deleting them when animation cache mode  is disabled
        global_vars.cache_exrs_in_use_before_animation_render = [n.image.filepath for n in bpy.data.scenes[scene_name].node_tree.nodes if n.name in cache_nodes and n.image]
        original_nodes = set()
        for n in cache_nodes:        
            original = cache_operation_helpers.get_original_node_name_from_cache_node(scene_name,n)
            if original and bpy.data.scenes[scene_name].node_tree.nodes[original].mute == False:
                original_nodes.add(original)                
                cache_operation_helpers.store_link_list_in_cache_node(n,scene_name)
                cache_operation_helpers.move_links_from_cache_node_to_original_node(n,scene_name)
    
        original_nodes.update([n.name for n in nodes if n.type == 'R_LAYERS' and n.mute == False])#all unmuted render layer nodes
        
        global_vars.denoise_nodes_to_delete = []
        cached_rl_nodes =[]
        global_vars.turbo_passes_enabled = set()
        
        
        for n in original_nodes:
            original_node = nodes[n]
            if original_node.type == 'R_LAYERS':
                #ensure we only create file output nodes for unique render layer nodes to avoid huge processing times when using turbo render
                rl_node_settings = (original_node.scene.name,original_node.layer)
                original_node.hide = True
                if rl_node_settings not in cached_rl_nodes:

                    

                    if original_node.scene.render.engine in consts.valid_turbo_render_engines and original_node.scene.Turbo_Render == True:
                        #its a turbo render
                        original_node['has_turbo_render_tree_connected'] = True
                        #make sure normal denoise is disabled if turbo render is enabled
                        if 'Turbo_Render' in original_node.scene and original_node.scene.Turbo_Render == True and original_node.scene.cycles.use_denoising:
                            original_node.scene.cycles.use_denoising = False
                            if global_vars.scenes_to_reenable_denoise is None:
                                global_vars.scenes_to_reenable_denoise = set()
                            global_vars.scenes_to_reenable_denoise.add(original_node.scene.name)

                        
                        #create the file output node to save the exr used for the rl cache node
                        partial_path = get_cache_file_path_from_original_node_name(scene_name,n,turbo=False)
                        file_output_node_name = cache_operation_helpers.create_and_wire_file_output(scene_name, n,node_position= original_node.location, partial_path = partial_path,do_hash=False,minimise=True    )

                        move_links_to_one_render_layer_node(scene_name, original_node, rl_node_settings)
                        
                        #enable necessary render layers and store originally set
                        turbo_render_helpers.enable_turbo_render_passes(original_node.layer,original_node.scene.name)

                        
                        #set up the denoising tree
                        denoising_candidates = turbo_render_helpers.build_recombine_passes_tree(scene_name,n,True,original_node.scene.name,file_output_node_name,denoise_mode = bpy.data.scenes[original_node.scene.name].Turbo_Mode)
                        if len(denoising_candidates) > 0:
                            #add denoise nodes
                            turbo_render_helpers.create_and_wire_denoise_nodes(scene_name,denoising_candidates,original_node.scene.name,original_node.name,denoise_mode =bpy.data.scenes[original_node.scene.name].Turbo_Mode)

                        

                    else:
                        #it's not a turbo render and/or its a different render engine
                        move_links_to_one_render_layer_node(scene_name, original_node, rl_node_settings)
                        file_output_node_name = cache_operation_helpers.create_and_wire_file_output(scene_name,n,minimise=True,node_position=original_node.location)
                    cached_rl_nodes.append(rl_node_settings)

                    #regardless of whether or not its a turbo render, if it's a cycles render layer node then need to store the vector pass in case user want to use temporal stabilization
                    #but only if motion blur is disabled, otherwise it'll be a blank useless exr due to cycles being unable to generate a vector pass if motion blur is enabled.
                    
                    if original_node.scene.render.engine in consts.valid_turbo_render_engines and bpy.data.scenes[scene_name].Keep_Cache:
                        if not original_node.scene.render.use_motion_blur:
                            if not cache_operation_helpers.vector_pass_is_user_enabled(scene_name,original_node.name):
                                temporal.enable_vector_pass(original_node.name,scene_name)
                            cache_operation_helpers.create_vector_pass_file_output(scene_name,original_node.name)

                    
                
                # elif original_node.scene.render.engine in consts.valid_turbo_render_engines and original_node.scene.Turbo_Render == True: #another render layer node with the same scene/view layer has already been done.  Move the links from this one to that one, and for each new link created store the original node and output id for fast relinking.
                #     #get the node that was done.
                #     rl_node_being_denoised = (trln.name for trln in bpy.data.scenes[scene_name].node_tree.nodes if 'has_turbo_render_tree_connected' in trln and trln.scene.name == rl_node_settings[0] and trln.layer == rl_node_settings[1])
                    
                #     if global_vars.original_rl_node_link_list_before_turbo_render_node_socket_id_node_socket_id == None:
                #         global_vars.original_rl_node_link_list_before_turbo_render_node_socket_id_node_socket_id = set()
                    
                #     #both rl nodes will have identical outputs so we can just do it numerically
                #     for index,sock in enumerate(original_node.outputs):
                #         for l in sock.links:
                #             #from_sock = bpy.data.scenes[scene_name].node_tree.nodes[rl_node_being_denoised].outputs[index]
                #             from_sock = original_node.outputs[index]
                #             bpy.data.scenes[scene_name].node_tree.links.new(from_sock,l.to_socket)
                #             global_vars.original_rl_node_link_list_before_turbo_render_node_socket_id_node_socket_id.add((original_node.name,index,l.to_node.name,cache_operation_helpers.get_socket_id_from_socket(l.to_socket))) #if sending the socket out causes access violation move that function here (it's small)


                        

                    
            else:
                #its a standard cache node
                cache_operation_helpers.create_and_wire_file_output(scene_name,n, do_hash = False)

            
        global_vars.rendering = True                
        global_vars.timeline_position_before_rednering = bpy.data.scenes[scene_name].frame_current        
        
        #get rid of temp attribute from all original nodes
        for n in original_nodes:
            original_node = nodes[n]
            if 'has_turbo_render_tree_connected' in original_node:
                del original_node['has_turbo_render_tree_connected']
        

def move_links_to_one_render_layer_node(scene_name, original_node, rl_node_settings):

                # Move the links from all render layer nodes that have the samce scene/layer to this one, and for each new link created store the original node and output id for fast relinking.
                    #get the node that was done.                       
                    #get list of render layer nodes using the same scene/viewlayer
    rl_nodes = (rln.name for rln in bpy.data.scenes[scene_name].node_tree.nodes if rln.type =='R_LAYERS' and rln.name != original_node.name and rln.scene.name == rl_node_settings[0] and rln.layer == rl_node_settings[1])
    
    if global_vars.original_rl_node_link_list_before_turbo_render_node_socket_id_node_socket_id == None:
        global_vars.original_rl_node_link_list_before_turbo_render_node_socket_id_node_socket_id = set()
                    
                    
    for rl_node in rl_nodes:
                        #both rl nodes will have identical outputs so we can just do it numerically
        for index,sock in enumerate(bpy.data.scenes[scene_name].node_tree.nodes[rl_node].outputs):
            for l in sock.links:
                                #from_sock = bpy.data.scenes[scene_name].node_tree.nodes[rl_node_being_denoised].outputs[index]
                from_sock = bpy.data.scenes[scene_name].node_tree.nodes[original_node.name].outputs[index]
                bpy.data.scenes[scene_name].node_tree.links.new(from_sock,l.to_socket)
                                
                                # new_link['original_rl_node_before_turbo_render'] = n.name
                global_vars.original_rl_node_link_list_before_turbo_render_node_socket_id_node_socket_id.add((rl_node,index,l.to_node.name,cache_operation_helpers.get_socket_id_from_socket(l.to_socket))) #if sending the socket out causes access violation move that function here (it's small)
    
    # global_vars.muted_before_render = [n.name for n in nodes if n.type == 'SCALE' and 'quality_node' in n]
    # for n in global_vars.muted_before_render:
    #     nodes[n].mute = True
    #queue_system.register_timer()

def render_post(scene_name):
    #bpy.data.scenes[scene_name].use_nodes = False

    revert_all_scenes_back_to_the_users_original_render_settings()
    turbo_render_helpers.revert_from_turbo_render_passes_back_to_user_passes()
    temporal.disable_vector_passes_that_were_not_enabled_by_user()
    #print("post render globabl vars = ",global_vars.last_rendered_frame)
    scene = bpy.data.scenes[scene_name]
    nodes = scene.node_tree.nodes
    if global_vars.last_rendered_frame is not None:
        scene.frame_current = global_vars.last_rendered_frame
        #print('frame change in render post')
    if global_vars.muted_before_render is not None:
        for n in global_vars.muted_before_render:
                nodes[n].mute = False

    file_out_nodes_to_remove = [n for n in nodes if n.type == 'OUTPUT_FILE' and global_vars.file_out_keep is not None and n.name not in global_vars.file_out_keep]
    for fout_name in file_out_nodes_to_remove:
        nodes.remove(fout_name)
    
    cache_operation_helpers.delete_the_delete_me_nodes(scene_name)
    
    if global_vars.remove_after_cache is not None:
        for n in global_vars.remove_after_cache:
            nodes.remove(nodes[n])        
            global_vars.remove_after_cache = set()

    
    if global_vars.denoise_nodes_to_delete is not None:
        render_layer_operations.move_links_from_denoise_node_to_render_layer_node(scene_name)

    #move all links back to the render layers nodes they were connected to before the turbo render.
    if global_vars.original_rl_node_link_list_before_turbo_render_node_socket_id_node_socket_id is not None: # (end two node_socke_id indicate what goest to what)must be turbo render as this is the only time we move the links in the first place
        tree = bpy.data.scenes[scene_name].node_tree
        for l in global_vars.original_rl_node_link_list_before_turbo_render_node_socket_id_node_socket_id: #this loops through the tuples in the set           
           #inputs can only have one connect so no need to destroy the old one, although could do for good measure just in case multi inputs arrive in the compositor as they did in geo nodes.
           from_socket = bpy.data.scenes[scene_name].node_tree.nodes[l[0]].outputs[l[1]]
           to_node = bpy.data.scenes[scene_name].node_tree.nodes[l[2]]
           to_socket = to_node.inputs[l[3]]
           #get_from_socket
           tree.links.new(from_socket,to_socket)

    #move from denosie tree end back to render layer image output
    if global_vars.turbo_render_end_nodes_whose_links_to_move_back_to_their_render_layers_node_image_output is not None:
        for mix_and_original in global_vars.turbo_render_end_nodes_whose_links_to_move_back_to_their_render_layers_node_image_output:
            render_layer_node_image_output_socket = bpy.data.scenes[scene_name].node_tree.nodes[mix_and_original[0]].outputs[0]
            mix_node_output = bpy.data.scenes[scene_name].node_tree.nodes[mix_and_original[1]].outputs[0]
            for link in mix_node_output.links:
                scene.node_tree.links.new(
                                            render_layer_node_image_output_socket,
                                            link.to_socket
                                        )

    #turn denoising back on if we disabled it when setting up the turbo render.
    if global_vars.scenes_to_reenable_denoise is not None:
        for s in global_vars.scenes_to_reenable_denoise:
            bpy.data.scenes[s].cycles.use_denoising = True
    
    #delete turbo render nodes (mix nodes and alpha node)
    if global_vars.turbo_render_nodes_to_delete is not None:
        for n in global_vars.turbo_render_nodes_to_delete:
            bpy.data.scenes[scene_name].node_tree.nodes.remove(bpy.data.scenes[scene_name].node_tree.nodes[n])

    #get all the cache nodes and then refine the list to exclude those that don't have an image or whose original node is muted.
    cache_nodes = node_helpers.get_all_cache_nodes(scene.name,get_muted=False)
    cache_nodes = [n for n in cache_nodes if (nodes[n].image and 'original' in nodes[n].image and nodes[nodes[n].image['original']].mute == False) or (nodes[n].image and 'original' in nodes[n] and nodes[nodes[n]['original']].mute == False) ]
    
    
    #update the image blocks or create if necessary
    img_blocks_already_done = set()
    for n in cache_nodes :        
        node = nodes[n]
        if node.image.name not in img_blocks_already_done:

            cache_operation_helpers.update_cache_image_delete_exr_and_create_image_if_necessary(n,scene.name)
            img_blocks_already_done.add(node.image.name)
            
            
    #for every cache node, move the links from it's render layers node back to it
    for n in cache_nodes:                
        cache_operation_helpers.move_links_to_cache_node(n,scene.name)

    render_layer_node_names = [n.name for n in nodes if n.type == 'R_LAYERS' and n.mute == False and checks.node_has_linked_outputs(n.name,scene.name)]    
    

    
    render_layer_operations.create_render_layer_cache_node_for_render_layer_nodes_that_dont_yet_have_one(scene.name)
    
               
    render_layer_operations.move_remaining_render_layer_links_to_the_cache_node_closest_to_the_target_node(scene.name,render_layer_node_names)
   
    #bpy.data.scenes[scene_name].use_nodes = True
    
    
    global_vars.timeline_position_before_rednering = None
    global_vars.rendering = False
    global_vars.last_rendered_frame = None
    handlers.cleanup(scene_name)
    global_vars.render_type = []
    global_vars.muted_before_render = None
    global_vars.turbo_render_nodes_to_delete = None
    global_vars.turbo_render_end_nodes_whose_links_to_move_back_to_their_render_layers_node_image_output = None
    global_vars.scenes_to_reenable_denoise = None    
    global_vars.original_rl_node_link_list_before_turbo_render_node_socket_id_node_socket_id = None
    global_vars.cache_exrs_in_use_before_animation_render = None
    global_vars.was_cancelled = None
    


def render_job_cancelled(scene_name):
    
    
    try:
        
        revert_all_scenes_back_to_the_users_original_render_settings()
        cache_nodes = node_helpers.get_all_cache_nodes(scene_name,get_muted=False)
        global_vars.render_cancelled = True
        turbo_render_helpers.revert_from_turbo_render_passes_back_to_user_passes() 
        temporal.disable_vector_passes_that_were_not_enabled_by_user()

        file_out_nodes_to_remove = [n for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'OUTPUT_FILE' and n.name not in global_vars.file_out_keep]
        for fout_name in file_out_nodes_to_remove:
            bpy.data.scenes[scene_name].node_tree.nodes.remove(fout_name)
        
        cache_operation_helpers.delete_the_delete_me_nodes(scene_name)
        
        if global_vars.remove_after_cache is not None:
            for n in global_vars.remove_after_cache:
                bpy.data.scenes[scene_name].node_tree.nodes.remove(bpy.data.scenes[scene_name].node_tree.nodes[n])         
                global_vars.remove_after_cache = set()

        if global_vars.denoise_nodes_to_delete is not None:
            render_layer_operations.move_links_from_denoise_node_to_render_layer_node(scene_name)

        if global_vars.turbo_render_end_nodes_whose_links_to_move_back_to_their_render_layers_node_image_output is not None:
            for mix_and_original in global_vars.turbo_render_end_nodes_whose_links_to_move_back_to_their_render_layers_node_image_output:
                render_layer_node_image_output_socket = bpy.data.scenes[scene_name].node_tree.nodes[mix_and_original[0]].outputs[0]
                mix_node_output = bpy.data.scenes[scene_name].node_tree.nodes[mix_and_original[1]].outputs[0]
                for link in mix_node_output.links:
                    bpy.data.scenes[scene_name].node_tree.links.new(
                                                render_layer_node_image_output_socket,
                                                link.to_socket
                                            )        

         #move all links back to the render layers nodes they were connected to before the turbo render.
        if global_vars.original_rl_node_link_list_before_turbo_render_node_socket_id_node_socket_id is not None: #must be turbo render as this is the only time we move the links in the first place
            tree = bpy.data.scenes[scene_name].node_tree
            for l in global_vars.original_rl_node_link_list_before_turbo_render_node_socket_id_node_socket_id: #this loops through the tuples in the set           
                #inputs can only have one connect so no need to destroy the old one, although could do for good measure just in case multi inputs arrive in the compositor as they did in geo nodes.
                from_socket = bpy.data.scenes[scene_name].node_tree.nodes[l[0]].outputs[l[1]]
                to_socket = bpy.data.scenes[scene_name].node_tree.nodes[l[2]].inputs[l[3]]
                tree.links.new(from_socket,to_socket)

        if global_vars.turbo_render_nodes_to_delete is not None:
            for n in global_vars.turbo_render_nodes_to_delete:
                bpy.data.scenes[scene_name].node_tree.nodes.remove(bpy.data.scenes[scene_name].node_tree.nodes[n])

        if global_vars.scenes_to_reenable_denoise is not None:
            for s in global_vars.scenes_to_reenable_denoise:
                bpy.data.scenes[s].cycles.use_denoising = True

        for n in cache_nodes:
            
            cache_operation_helpers.move_links_to_cache_node(n,scene_name)
        bpy.data.scenes[scene_name].frame_current = global_vars.timeline_position_before_rednering
        
    except:
        pass
        #print('post_render_job error')
    finally:        
        handlers.cleanup(scene_name)   
        global_vars.timeline_position_before_rednering = None        
        global_vars.rendering = False
        global_vars.render_cancelled = False
        global_vars.last_rendered_frame = None
        #update_node_tree_without_caching(scene_name)
        global_vars.render_type = []
        global_vars.turbo_render_nodes_to_delete = None
        global_vars.turbo_render_end_nodes_whose_links_to_move_back_to_their_render_layers_node_image_output = None
        global_vars.scenes_to_reenable_denoise = None 
        global_vars.original_rl_node_link_list_before_turbo_render_node_socket_id_node_socket_id = None
        global_vars.cache_exrs_in_use_before_animation_render = None
        global_vars.was_cancelled = None
        