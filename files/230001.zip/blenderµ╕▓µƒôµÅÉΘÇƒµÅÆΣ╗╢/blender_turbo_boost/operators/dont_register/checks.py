
from ..dont_register import cache_operation_helpers,node_helpers,render_layer_operations,blender_bug_workarounds,file_system_helpers
import bpy
from..dont_register.report_custom_error import store_error
from ...variables import consts
import os

#scene checks
#------------------------------------------------------------------

def comp_is_enabled_in_properties(scene_name):
    if not bpy.data.scenes[scene_name].render.use_compositing:
        store_error(scene_name,'Turbo Tools caching system needs the compositor to be enabled in the output properties panel\'s post processing section.')
        return False
    return True

def scene_contains_unmuted_quality_node(scene_name):
    
    
    quality_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'SCALE' and 'quality_node' in n and n.space == 'RENDER_SIZE' and n.mute == False]
    if quality_nodes:
        return True
    else:
        return False


def there_are_cache_nodes(scene_name):
    
    if node_helpers.get_all_cache_nodes(scene_name):
        return True
    return False

def a_viewer_node_is_selected(scene_name):
    
    sel = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.select == True and n.type == 'VIEWER']
    if not sel:        
        return False
    return True

def a_composite_node_is_selected(scene_name):
    
    sel = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.select == True and n.type == 'COMPOSITE']
    if not sel:        
        return False
    return True

def scene_has_active_cam(scene_name,rl_scene_name):
    if bpy.data.scenes[rl_scene_name].camera is None:
        store_error(scene_name,f"scene named {rl_scene_name} has no active camera.  Add a camera or mute it's render layer node in this scene before rendering")
        return False
    else:
        
        return True

def  has_view_layer_specified(scene_name,rl_scene_name,rl_node_name):
    if bpy.data.scenes[scene_name].node_tree.nodes[rl_node_name].layer == '':
        store_error(scene_name,f"Render layer node {rl_node_name} has no viewlayer specified.  Specify one in the render layer node's viewlayer dropdown before rendering")
        return False
    return True
#cache helpers
#--------------------------------------------------------------------

def needs_hashing(file_name):
    '''checks if a standard cache nodes'''
    if file_name is not None and len(file_name) < 70 :
        return True
    return False

def all_links_have_valid_from_sockets(scene_name):
    found = False
    links_to_create = set()
    for link in bpy.data.scenes[scene_name].node_tree.links:
        if is_a_cache_node(link.from_node.name,scene_name):
            #make sure it's up to date
            
            if link.from_socket.name not in (n.name for n in bpy.data.scenes[scene_name].node_tree.nodes[link.from_node.name].outputs if n.enabled == True):
                from_socket_name_without_prefix = cache_operation_helpers.get_original_socket_name_from_cache_socket_name(link.from_socket.name)
                for l in link.from_node.outputs:
                    new_from_socket_name = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes[link.from_node.name].outputs if n.enabled == True 
                                            and cache_operation_helpers.get_original_socket_name_from_cache_socket_name(n.name) == from_socket_name_without_prefix ]
                    if not new_from_socket_name:
                        store_error(scene_name,f"on frame {bpy.data.scenes[scene_name].frame_current} the exr loaded for cache node {link.from_node.name} is missing layer {from_socket_name_without_prefix}.  As the compositor tree has links using that socket.  If it's a render layer node, then please re-render that frame with the {from_socket_name_without_prefix} pass enabled.  \nIf it's not a render layer cache node, then check you haven't changed any group outputs ")
                        return False
                    else:
                        new_from_socket_name = new_from_socket_name[0]
                        
                    if cache_operation_helpers.get_original_socket_name_from_cache_socket_name(l.identifier) == from_socket_name_without_prefix:
                        links_to_create.add((link.from_node.name,link.to_node.name,new_from_socket_name,cache_operation_helpers.get_socket_id_from_socket(link.to_socket)))
                        
                        found = True
                if not found:
                    return False
                else:
                    for link_details in links_to_create:
                        #print(link_details)
                        from_socket = bpy.data.scenes[scene_name].node_tree.nodes[link_details[0]].outputs[link_details[2]]
                        to_socket = bpy.data.scenes[scene_name].node_tree.nodes[link_details[1]].inputs[link_details[3]]
                        bpy.data.scenes[scene_name].node_tree.links.new(
                                                                                    from_socket,
                                                                                    to_socket
                                                                                    )                    
    return True


def output_is_divisible_by_two(scene_name):
    user_x_res = bpy.data.scenes[scene_name].render.resolution_x
    user_y_res = bpy.data.scenes[scene_name].render.resolution_y
    percent = bpy.data.scenes[scene_name].render.resolution_percentage
    end_res_x = (user_x_res * percent) /100
    end_rex_y = (user_y_res * percent) /100
    if (end_res_x % 2 == 0) and (end_rex_y % 2 == 0):
        return True
    return False
    

def scene_has_nodes(scene_name):
    try:
        nodes = bpy.data.scenes[scene_name].node_tree.nodes
        if nodes:
            return True
    except:
        return False
    return False


def node_has_no_linked_inputs(node_name,scene_name):
    
    for l in bpy.data.scenes[scene_name].node_tree.nodes[node_name].inputs:
        for link in l.links:
            return False
    return True


def node_has_linked_outputs(node_name,scene_name):
    
    for l in bpy.data.scenes[scene_name].node_tree.nodes[node_name].outputs:
        for link in l.links:
            return True
    return False

    
def has_outputs(node_name,scene_name):
    
    if len(bpy.data.scenes[scene_name].node_tree.nodes[node_name].outputs) > 0:
        return True
    else:
        return False


def is_inside_a_group_node(node_name,scene_name):
    
    if bpy.data.scenes[scene_name].node_tree.nodes[node_name].id_data == bpy.data.scenes[scene_name].node_tree:
        return False
    else:
        return True


def is_a_cache_node(node_name,scene_name):
    
    if 'temporal_parent' not in bpy.data.scenes[scene_name].node_tree.nodes[node_name] and bpy.data.scenes[scene_name].node_tree.nodes[node_name].type == 'IMAGE' and bpy.data.scenes[scene_name].node_tree.nodes[node_name].image and (file_system_helpers.get_file_name_from_path(bpy.data.scenes[scene_name].node_tree.nodes[node_name].image.filepath).startswith('RL_') 
                                                    or file_system_helpers.get_file_name_from_path(bpy.data.scenes[scene_name].node_tree.nodes[node_name].image.filepath).startswith('RLT_')
                                                    or file_system_helpers.get_file_name_from_path(bpy.data.scenes[scene_name].node_tree.nodes[node_name].image.filepath).startswith('CH_')):
        return True
    else:
        return False

    
def is_a_render_layer_cache_node(node_name,scene_name):
    
    if 'temporal_parent' not in bpy.data.scenes[scene_name].node_tree.nodes[node_name] and bpy.data.scenes[scene_name].node_tree.nodes[node_name].type == 'IMAGE' and bpy.data.scenes[scene_name].node_tree.nodes[node_name].image and (file_system_helpers.get_file_name_from_path(bpy.data.scenes[scene_name].node_tree.nodes[node_name].image.filepath).startswith('RL_') or file_system_helpers.get_file_name_from_path(bpy.data.scenes[scene_name].node_tree.nodes[node_name].image.filepath).startswith('RLT_')):
        return True
    else:
        return False


def is_a_non_render_layer_cache_node(node_name,scene_name):
    
    if 'temporal_parent' not in bpy.data.scenes[scene_name].node_tree.nodes[node_name] and bpy.data.scenes[scene_name].node_tree.nodes[node_name].type == 'IMAGE' and bpy.data.scenes[scene_name].node_tree.nodes[node_name].image and file_system_helpers.get_file_name_from_path(bpy.data.scenes[scene_name].node_tree.nodes[node_name].image.filepath).startswith('CH_'):
        return True
    else:
        return False


def is_a_render_layer_node(node_name,scene_name):
    
    if bpy.data.scenes[scene_name].node_tree.nodes[node_name].type == 'R_LAYERS':
        return True
    else:
        return False


def there_is_an_render_layer_node_downstream(node_name,scene_name):
    unused,start_node_names = node_helpers.get_downsttream_nodes(node_name,scene_name)
   
    for n in start_node_names:
         
        if bpy.data.scenes[scene_name].node_tree.nodes[n].type == 'R_LAYERS' and bpy.data.scenes[scene_name].node_tree.nodes[n].mute == False:
            #try and fix it
            if not render_layer_operations.create_render_layer_cache_node_for_render_layer_nodes_that_dont_yet_have_one(scene_name,[n]):
                store_error(scene_name,f"no cache file for {n}, mute it, remove it, or do a f12/ctrl f12 render before refreshing the cache")
                return True
            if not render_layer_operations.move_remaining_render_layer_links_to_the_cache_node_closest_to_the_target_node(scene_name,[n]):
                store_error(scene_name,f"unable to move link from node '{n}', the cache node does not have the necessary output, please re-render (f12) to update the cache node sockets (error rlo113)")
                return True
    return False


def there_is_a_wired_render_layer_node_anywhere_within_the_active_branch(scene_name,active_branch = None):
    if active_branch is None:
        active_branch = [n.name for n in  bpy.data.scenes[scene_name].node_tree.nodes if n.mute == False and n.type == 'R_LAYERS']
    for n in active_branch:
        
        if bpy.data.scenes[scene_name].node_tree.nodes[n].type == 'R_LAYERS':
            if not is_already_cached(n,scene_name):
                if not render_layer_operations.create_render_layer_cache_node_for_render_layer_nodes_that_dont_yet_have_one(scene_name,[n]):
                    store_error(scene_name,f"no cache file for {n}, mute it, remove it, or do a f12/ctrl f12 render before refreshing the cache")
                    return True
                
            if not render_layer_operations.move_remaining_render_layer_links_to_the_cache_node_closest_to_the_target_node(scene_name,[n]):
                store_error(scene_name,f"unable to move link from node '{n}', the cache node does not have the necessary output, please re-render (f12) to update the cache node sockets (error rlo113)")
                return True
            bpy.data.scenes[scene_name].node_tree.nodes[n].select = False
    return False


def there_is_a_unmuted_render_layer_node_with_no_cache(scene_name,create_missing = True):    
    if create_missing:
        if render_layer_operations.create_render_layer_cache_node_for_render_layer_nodes_that_dont_yet_have_one(scene_name):
            
            return False
        else: 
            store_error(scene_name, f"compositor contains a render layers node which has not yet been cached, please render first (f12)")
            return True
    else:
        rl_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'R_LAYERS' and n.mute == False]
        for rl_node in rl_nodes:
            if not is_already_cached(rl_node,scene_name):
                return True
        
        return False




def is_already_cached(node_name,scene_name):
    
    cache_node_names = cache_operation_helpers.get_all_cache_nodes_for_this_node(scene_name,node_name)
    if cache_node_names:
            return True
    return False


def img_belongs_to_this_scene(cache_node_name,scene_name):
     
          
    if bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image['scene'] == scene_name:
        return True
    return False

def cache_node_image_block_matches_the_rl_node_settings(scene_name,cache_node_name):
    
    if bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image is None:
        return False
    rl_node_name = cache_operation_helpers.get_original_node_name_from_cache_node(scene_name,cache_node_name)
    if rl_node_name == None:
        return False
    

    if (bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image['scene'] == bpy.data.scenes[scene_name].node_tree.nodes[rl_node_name].scene.name
        and (bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image['cam'] == bpy.data.scenes[scene_name].node_tree.nodes[rl_node_name].scene.camera.name)# or img['cam'] == scene.camera)
        and bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image['layer'] == bpy.data.scenes[scene_name].node_tree.nodes[rl_node_name].layer
        ):
        return True
    else:
        return False




def all_downstream_cache_nodes_have_valid_exrs(scene_name,node_to_cache_name):
    downstream_nodes,branch_start_node_names = node_helpers.get_downsttream_nodes(node_to_cache_name,scene_name)
    rl_cache_nodes = node_helpers.get_all_render_layer_cache_nodes(scene_name,branch_start_node_names)
    return all_render_layer_cache_nodes_have_valid_exrs(scene_name,rl_cache_nodes)


def all_render_layer_cache_nodes_have_valid_exrs(scene_name,nodes_to_check = None):
    
    if nodes_to_check is None:        
        nodes_to_check = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.mute == False]    
    rl_cache_node_names = [n for n in nodes_to_check if bpy.data.scenes[scene_name].node_tree.nodes[n].mute == False and is_a_render_layer_cache_node(n,scene_name) and check_the_original_node_exists(n,scene_name)]
    image_processed = set()

    for rl_cache_node_name  in rl_cache_node_names:
        
        if bpy.data.scenes[scene_name].node_tree.nodes[rl_cache_node_name].image.name not in image_processed:
            if not cache_operation_helpers.update_cache_image_delete_exr_and_create_image_if_necessary(rl_cache_node_name,scene_name):
                store_error(scene_name,f"render layer node named '{cache_operation_helpers.get_original_node_name_from_cache_node(scene_name,rl_cache_node_name)}' in it's current configuration and active scene cam does not have a cache file, please render with f12 or select the cache folder that was used when rendering")
                return False
        image_processed.add(bpy.data.scenes[scene_name].node_tree.nodes[rl_cache_node_name].image.name)
    return True

def there_are_aovs_with_dots(scene_name,view_layer_name):    
    
    aov_names = [aov.name for aov in bpy.data.scenes[scene_name].view_layers[view_layer_name].aovs]
    for aov_name in aov_names:
        if '.' in aov_name:
            store_error(scene_name,f"Viewlayer '{view_layer_name}' in scene '{scene_name}' has an AOV called '{aov_name}'.  Please remove dots from the AOV name to avoid issues")
            return True
    return False

def blend_file_is_saved():
    if bpy.data.is_saved:
        return True
    return False


#render checks

#----------------------------------------------------------
def make_render_region_divisible_by_2(scene_name):
    '''
        checks render region is divisible by 2 (necessary when rendering out to ffmpg and crop to region is enabled).
        if not it will be automatically corrected
    '''
    

    region_max_x = bpy.data.scenes[scene_name].render.border_max_x
    region_max_y = bpy.data.scenes[scene_name].render.border_max_y
    region_min_x = bpy.data.scenes[scene_name].render.border_min_x
    region_min_y = bpy.data.scenes[scene_name].render.border_min_y
    res_x = bpy.data.scenes[scene_name].render.resolution_x
    res_y = bpy.data.scenes[scene_name].render.resolution_y



    def get_region_res(region_max_x,region_max_y,region_min_x, region_min_y):

        width_percent = region_max_x - region_min_x
        height_percent = region_max_y - region_min_y

        render_region_res_x = round(res_x * width_percent)
        render_region_res_y = round(res_y * height_percent)
        
        return render_region_res_x,render_region_res_y

    render_region_res_x, render_region_res_y = get_region_res(region_max_x,region_max_y,region_min_x,region_min_y)
    render_region_res_x = int( 2 * round( render_region_res_x / 2. ))
    render_region_res_y = int( 2 * round( render_region_res_y / 2. ))

    #convert to decimal

    new_max_x = render_region_res_x / res_x
    new_max_y = render_region_res_y / res_y

    new_max_x += region_min_x
    new_max_y += region_min_y
    bpy.data.scenes[scene_name].render.border_max_x = new_max_x
    bpy.data.scenes[scene_name].render.border_max_y = new_max_y


#main cache check functions

#-----------------------------------------------------------


    


#uncache check helpers
#-------------------------------------------------------------

def check_the_original_node_exists(node_name,scene_name):
    
    if is_a_cache_node(node_name,scene_name):
        original_node_name = cache_operation_helpers.get_original_node_name_from_cache_node(scene_name,node_name)
        if original_node_name is not None and original_node_name in bpy.data.scenes[scene_name].node_tree.nodes:
            return True
        store_error(scene_name,f"The original node for cache node named '{node_name}' is missing, please manually remove node '{node_name}, or  re-add the original node named '{original_node_name}' and then retry")
        return False
    return True


def node_has_socket(socket_identifier,node_name,scene_name):
    
    enabled_outputs = [o for o in bpy.data.scenes[scene_name].node_tree.nodes[node_name].outputs if o.enabled == True]
    for output in enabled_outputs:
        if bpy.data.scenes[scene_name].node_tree.nodes[node_name].type == 'R_LAYERS':
            if output.name == socket_identifier or output.identifier == socket_identifier:
                return True
        else:
            if output.identifier == socket_identifier:
                return True
    return False      


def original_node_still_has_the_outputs_for_each_of_the_cache_nodes_wired_outputs(cache_node_name,scene_name):
    nodes = bpy.data.scenes[scene_name].node_tree.nodes    
    
    
    filename = str(file_system_helpers.get_file_name_from_path(bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image.filepath))    
    original_node_name = cache_operation_helpers.get_original_node_name_from_cache_node(scene_name,cache_node_name)  
    wired_outputs = [s for s in bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].outputs if s.enabled and len(s.links)>0]

    for socket in wired_outputs:
        original_socket = cache_operation_helpers.get_original_socket_name_from_cache_socket_name(socket.name)
        if not node_has_socket(original_socket,original_node_name,scene_name):           
            store_error(scene_name,f"can't move link from '{cache_node_name}'s {original_socket} socket. Socket is no longer present on {original_node_name} node.  You've probably removed a render pass or a group node output.  Manually remove the link from the cache node and retry.")
            return False
    return True


def there_are_no_other_image_nodes_using_this_exr(scene_name,exr_path):
    if (x for x in bpy.data.scenes[scene_name].node_tree.nodes if x.type == 'IMAGE' and x.image.filepath == exr_path):
        return False
    return True

    
#-------------------------------------------------------------------


def can_be_cached(node_name,scene_name):
    if not cache_folder_for_this_scene_is_valid(scene_name):
        return False
    failed = False
    if not comp_is_enabled_in_properties(scene_name):
        return False
    if not scene_has_nodes(scene_name):
        store_error(scene_name, f"{scene_name} can't be cached.  No nodes!")
        return False
    if is_a_non_render_layer_cache_node(node_name,scene_name):        
        #store_error(scene_name, f"{node_name} can't be cached.  Can't cache a cache node, add a reroute node and cache that instead.")
        return False
    if is_already_cached(node_name,scene_name):
        return False
    if not has_outputs(node_name,scene_name):
        store_error(scene_name, f"{node_name} can't be cached as it has no outputs")
        return False
    if is_inside_a_group_node(node_name,scene_name):
        store_error(scene_name, f"{node_name} can't be cached as it's inside a group.  Cache outer group node instead")
        return False    
    if  is_a_render_layer_node(node_name,scene_name):
        store_error(scene_name, f"{node_name} can't be cached.  Render layer nodes can only be cached during f12 and ctrl f12 renders, please render instead")
        return False
    if there_is_an_render_layer_node_downstream(node_name,scene_name):        
        store_error(scene_name, f" Node '{node_name}' can't be cached because there is a render layer node downstream which has not yet been cached, please render first (f12)")
        return False
    if not all_downstream_cache_nodes_have_valid_exrs(scene_name,node_name):
        return False    
    if failed:
        return False
    return True


def can_be_uncached(node_name,scene_name):
    blender_bug_workarounds.fix_all_bugs()
    if is_a_cache_node(node_name,scene_name):
        # if is_a_render_layer_cache_node(node_name,scene_name):
        #     return False
        if not check_the_original_node_exists(node_name,scene_name):
            return False 
        if not original_node_still_has_the_outputs_for_each_of_the_cache_nodes_wired_outputs(node_name,scene_name):
            return False 
        
        return True    
    else:
        if not is_already_cached(node_name,scene_name):
            return False        
        return True
    

def all_can_be_refreshed(scene_name,create_missing_cache_nodes = True):    
    if not cache_folders_for_all_scenes_that_are_in_this_scenes_compositor_have_valid_cache_folders(scene_name):
        return False
    if not comp_is_enabled_in_properties(scene_name):
        return False
    if not scene_has_nodes(scene_name):
        store_error(scene_name, f"{scene_name} has no nodes!")
        return False
    blender_bug_workarounds.fix_all_bugs()
    cache_nodes = node_helpers.get_all_standard_cache_nodes(scene_name)        
    for n in cache_nodes:
        if not original_node_still_has_the_outputs_for_each_of_the_cache_nodes_wired_outputs(n,scene_name):
                return False 
    
    if not all_render_layer_cache_nodes_have_valid_exrs(scene_name):
        return False    
    if there_is_a_unmuted_render_layer_node_with_no_cache(scene_name,create_missing_cache_nodes):
        return False
    if there_is_a_wired_render_layer_node_anywhere_within_the_active_branch(scene_name):
        return False
    
    return True


def selected_can_be_refreshed(scene_name,selected_nodes):
    if not cache_folder_for_this_scene_is_valid(scene_name):
        return False
    
    if not comp_is_enabled_in_properties(scene_name):
        return False
    if not scene_has_nodes(scene_name):
        store_error(scene_name, f"{scene_name} has no nodes!")
        return False
    blender_bug_workarounds.fix_all_bugs()
    nodes_not_to_mute,cache_nodes = node_helpers.get_upstream_and_downtream_from_selection_including_downstream_of_cache_nodes_original_nodes(selected_nodes,scene_name)
    rl_cache_nodes = node_helpers.get_all_render_layer_cache_nodes(scene_name,nodes_not_to_mute)
    for n in rl_cache_nodes:
        if not original_node_still_has_the_outputs_for_each_of_the_cache_nodes_wired_outputs(n,scene_name):
                return False 
    if not all_render_layer_cache_nodes_have_valid_exrs(scene_name,rl_cache_nodes):
        return False   
    if there_is_a_wired_render_layer_node_anywhere_within_the_active_branch(scene_name,nodes_not_to_mute):
        return False
     
    return True


def file_output_can_be_resaved(scene_name,unmuted_tree):
    if not comp_is_enabled_in_properties(scene_name):
        return False
    if not scene_has_nodes(scene_name):
        store_error(scene_name, f"{scene_name} has no nodes!")
        return False
    blender_bug_workarounds.fix_all_bugs()
    
    # rl_nodes = node_helpers.get_all_render_layer_cache_nodes(scene_name,unmuted_tree)
    # if not all_render_layer_cache_nodes_have_valid_exrs(scene_name,rl_nodes):
    #     return False   
    if there_is_a_wired_render_layer_node_anywhere_within_the_active_branch(scene_name,unmuted_tree):
        return False
     
    return True
    

def theres_a_wired_composite_node(scene_name):
    composite_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'COMPOSITE' and n.mute == False and [i for i in n.inputs if i.name == 'Image' and [l for l in i.links]]]
    if composite_nodes:
        return True
    return False


def cache_folders_for_all_scenes_that_are_in_this_scenes_compositor_have_valid_cache_folders(scene_name):
    '''checks that any scenes that will be rendered by this scenes compositor have valid cache locations'''
    failed = False
    rl_nodes_in_this_scene  = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'R_LAYERS' and n.mute == False]
    for rl_node in rl_nodes_in_this_scene:
        rl_scene_name = bpy.data.scenes[scene_name].node_tree.nodes[rl_node].scene.name
        if  bpy.data.scenes[scene_name].node_tree.nodes[rl_node].scene.Turbo_Cache_Folder == 'Please specify' or not os.path.isdir(bpy.data.scenes[scene_name].node_tree.nodes[rl_node].scene.Turbo_Cache_Folder):
            store_error(scene_name,f'Scene \'{rl_scene_name}\' has an invalid cache folder set.  Check the current cache path is accessible or set a valid path and retry (you can do this at the top of the turbo panel in the compositor, or at the bottom of the Turbo Render panel in the render settings).')
            failed = True
    if failed:
        return False
    return True

def cache_folder_for_this_scene_is_valid(scene_name):
    if not os.path.isdir(bpy.data.scenes[scene_name].Turbo_Cache_Folder):
        store_error(scene_name,'This scene has an invalid cache folder. Check the current cache path is accessible or set a valid path and retry (you can do this at the top of the turbo panel in the compositor, or at the bottom of the Turbo Render panel in the render settings)')
        return False
    return True



def can_be_rendered(scene_name,is_anim = False):
    # don't need to do the below here because the render will generate the folder if it doesnt exist (if it's a valid drive at least)
    #  if not cache_folders_for_all_scenes_that_are_in_this_scenes_compositor_have_valid_cache_folders(scene_name):
    #     failed = True
    #     return False

    failed = False
    if not comp_is_enabled_in_properties(scene_name):
        store_error(scene_name,'To render without the Turbo Tools caching system and Turbo Render, use alt f12 (still) or ctrl alt f12 (animation).')
        return False
    # if not blend_file_is_saved():
    #     store_error(scene_name, f"Blend file unsaved, please save before rendering")
    #     return False

    if not bpy.data.scenes[scene_name].use_nodes:
        bpy.data.scenes[scene_name].use_nodes = True
        #store_error(scene_name, f"{scene_name} compositor use nodes turned on to enable caching")
        
    #if there is not a wired up compositor node already then set shizzle up.
    if not theres_a_wired_composite_node(scene_name):
        node_helpers.create_and_wire_rl_and_composite_node_if_either_missing(scene_name)


    if bpy.data.scenes[scene_name].render.image_settings.file_format in ('FFMPEG', 'AVI_RAW', 'AVI_JPEG') and is_anim:
        if bpy.data.scenes[scene_name].render.use_border and bpy.data.scenes[scene_name].render.use_crop_to_border:
            make_render_region_divisible_by_2(scene_name)
        elif not output_is_divisible_by_two(scene_name):
            store_error(scene_name, f"The render resolution is not currently divisible by 2, this wil stop the output codec from working.")
            store_error(scene_name,'Please change the resolution or percentage slider so that the output will be divisible by 2 on both the x and y axis.')
            failed = True
    
    if not bpy.data.scenes[scene_name].render.use_compositing and bpy.data.scenes[scene_name].Turbo_Render:
        store_error(scene_name,'Turbo Render needs the compositor to be enabled in the output properties panel\'s post processing section.  Either enable it, or disable Turbo Render')
        failed = True
    
        
    blender_bug_workarounds.fix_all_bugs()
    
    
    unmuted_render_layer_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'R_LAYERS' and n.mute == False]
    for n in unmuted_render_layer_nodes:
        viewlayer = bpy.data.scenes[scene_name].node_tree.nodes[n].layer
        
        rl_scene_name = bpy.data.scenes[scene_name].node_tree.nodes[n].scene.name
        
        
        if not scene_has_active_cam(scene_name,rl_scene_name):            
            failed=True
        
        if not has_view_layer_specified(scene_name,rl_scene_name,n):
            failed=True
            return False
        
        if there_are_aovs_with_dots(rl_scene_name,viewlayer):                        
            failed = True

    
    

    
    all_cache_node_names = node_helpers.get_all_cache_nodes(scene_name)

    for n in all_cache_node_names:
        if not check_the_original_node_exists(n,scene_name):
            failed = True
            return False

    image_processed = set()
    for n in all_cache_node_names:
        if bpy.data.scenes[scene_name].node_tree.nodes[n].image.name not in image_processed:
            if not original_node_still_has_the_outputs_for_each_of_the_cache_nodes_wired_outputs(n,scene_name):
                failed = True 
            image_processed.add(bpy.data.scenes[scene_name].node_tree.nodes[n].image.name)
            

    
    
    if failed:
        return False
    return True
        

def contains_connected_composite_node(scene_name):
    
    composite_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'COMPOSITE' and not node_has_no_linked_inputs(n.name,scene_name)]
    return composite_nodes

def contains_multiple_composite_nodes(scene_name):
    
    composite_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'COMPOSITE']
    if composite_nodes and len(composite_nodes)>1:
        return True
    return False
    

def can_be_published(scene_name,publish_type = 'single'):
    if not comp_is_enabled_in_properties(scene_name):
        store_error(scene_name, f"To publish please enable the compositor in the output properties panel's Post Processing options")
        return False
    if bpy.data.scenes[scene_name].render.image_settings.file_format in ('FFMPEG', 'AVI_RAW', 'AVI_JPEG') and publish_type == 'single':
        store_error(scene_name, f"To publish a still image, please choose a non movie format in the properties panel's output section")
        return False
    if bpy.data.scenes[scene_name].render.image_settings.file_format in ('FFMPEG', 'AVI_RAW', 'AVI_JPEG') and publish_type == 'anim':
        if not output_is_divisible_by_two(scene_name):
            store_error(scene_name, f"The render resolution is not currently divisible by 2, this wil stop the output codec from working.")
            store_error(scene_name,'Please change the resolution or percentage slider so that the output will be divisible by 2 on both the x and y axis.')
            return False
    wired_composite_nodes = contains_connected_composite_node(scene_name)
    multiple_comp_nodes = contains_multiple_composite_nodes(scene_name)
    if wired_composite_nodes:
        if (a_composite_node_is_selected(scene_name) or not multiple_comp_nodes):
            standard_cache = node_helpers.get_all_standard_cache_nodes(scene_name)
            for n in standard_cache:
                if not can_be_uncached(n,scene_name):
                    return False
            return True
        elif multiple_comp_nodes:
            store_error(scene_name, f"There are multiple composite nodes, please select the one you want to publish")
            return False
    else:
        store_error(scene_name, f"Please wire up a composite node to specify what part of the node tree should be published")
        return False


#----------------------------------------------- temporal ------------------------------------------------

def has_vector_pass_in_cache(cache_node_name,scene_name):
    for socket in bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].outputs:
        if socket.name.endswith('_Vector'):
            return True
    return False

def can_be_temporal_stabilized(scene_name,node_name):
    '''checks if the render layer node refers to a scene that can be temporal stabilised.  eg its a cycles scene not eevee etc'''
    
    if bpy.data.scenes[scene_name].node_tree.nodes[node_name].type == 'IMAGE':
        if is_a_render_layer_cache_node(node_name,scene_name):
            if has_vector_pass_in_cache(node_name,scene_name):
                if 'scene' in bpy.data.scenes[scene_name].node_tree.nodes[node_name].image:
                    if  bpy.data.scenes[bpy.data.scenes[scene_name].node_tree.nodes[node_name].image['scene']].render.engine in consts.valid_turbo_render_engines:
                        return True        
        
    elif bpy.data.scenes[scene_name].node_tree.nodes[node_name].type == 'R_LAYERS':
        if bpy.data.scenes[scene_name].render.engine in consts.valid_turbo_render_engines:
            return True
    
    return False

def there_are_vector_passes_available(scene_name,cache_node_name):
    if is_a_non_render_layer_cache_node(cache_node_name,scene_name):
        if 'vector_path' in bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name]:
            if file_system_helpers.file_exists(bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name]['vector_path']):
                return True
    elif is_a_render_layer_cache_node(cache_node_name,scene_name):
        vec_path = file_system_helpers.get_exr(scene_name,cache_node_name,for_temporal_vector=True)
        if file_system_helpers.file_exists(vec_path):
            return True
    return False
    
