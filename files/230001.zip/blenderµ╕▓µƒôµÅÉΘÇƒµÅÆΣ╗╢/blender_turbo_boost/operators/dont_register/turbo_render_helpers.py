
# from asyncore import socket_map
from platform import node
from numpy import full
from ...variables import global_vars, consts
from . import file_system_helpers
import bpy



def create_mix_node_and_make_connections(pass_socket_a, pass_socket_b,blend_type,pass_node_a_name,new_mix_location,factor,scene_name,for_turbo_render):
        """for_turbo_render true will add the node to global_vars.turob_render_nodes_to_delete.  Pass_node_a_name will be used for the first part of the new node to avoid conflicts (probably not necessary)"""
        
        mix = bpy.data.scenes[scene_name].node_tree.nodes.new('CompositorNodeMixRGB')
        mix.name = f"{pass_node_a_name}_{blend_type}"
        mix.blend_type = blend_type
        mix.inputs[0].default_value = factor
        if global_vars.testing:
            if global_vars.location is None:
                global_vars.location = 250
            mix.location = (new_mix_location[0] + global_vars.location,new_mix_location[1] + global_vars.location)
            global_vars.location += 250
        else:
            mix.location = new_mix_location
        mix.hide = True
        mix['turbo_render_node'] = True
        if for_turbo_render:
            if global_vars.turbo_render_nodes_to_delete is None:
                global_vars.turbo_render_nodes_to_delete = set()
            global_vars.turbo_render_nodes_to_delete.add(mix.name)
            
                       
        #connect mix input 1
        bpy.data.scenes[scene_name].node_tree.links.new(
                                    pass_socket_a,
                                    mix.inputs[1]
                                )
        #connect mix input 2
        bpy.data.scenes[scene_name].node_tree.links.new(
                                    pass_socket_b,
                                    mix.inputs[2]
                                )
        return mix.name


def create_set_alpha_node_between_last_mix_node_and_image_input_on_file_output_node(last_mix_from_socket,node_with_passes_to_combine,scene_name,for_turbo_render,singular_passes_with_denoise = None,alpha_node = None):
        set_alpha = bpy.data.scenes[scene_name].node_tree.nodes.new('CompositorNodeSetAlpha')
        set_alpha.name = f"{node_with_passes_to_combine}_setAlpha"
        set_alpha.mode = 'REPLACE_ALPHA'
        set_alpha.location = bpy.data.scenes[scene_name].node_tree.nodes[node_with_passes_to_combine].location
        set_alpha.hide = True
        set_alpha['turbo_render_node'] = True
        if singular_passes_with_denoise is None or 'Alpha' not in singular_passes_with_denoise:
            alpha_socket = get_out_socket(node_with_passes_to_combine,'Alpha',scene_name)
        else:
            alpha_socket = get_out_socket(alpha_node,'Image',scene_name)

        if for_turbo_render:
            if global_vars.turbo_render_nodes_to_delete is None:
                global_vars.turbo_render_nodes_to_delete = set()
            global_vars.turbo_render_nodes_to_delete.add(set_alpha.name)

        #move links from last mix socket to 
        bpy.data.scenes[scene_name].node_tree.links.new(
                                    last_mix_from_socket,
                                    set_alpha.inputs[0]
                                )
        
        bpy.data.scenes[scene_name].node_tree.links.new(
                                    alpha_socket,
                                    set_alpha.inputs[1]
                                )
        
        return set_alpha.name

#only needed if node combining denoise nodes, denoise nodes only has one output
def get_out_socket(node_name,identifier,scene_name):
    node_for_out_socket = bpy.data.scenes[scene_name].node_tree.nodes[node_name]        
    return [s for s in node_for_out_socket.outputs if s.name == identifier][0]

def get_draft_rays_to_denoise(render_scene_name):
    ray_types_to_denoise = tuple()

    if bpy.data.scenes[render_scene_name].Turbo_Geo:
        #Diff
        if bpy.data.scenes[render_scene_name].Turbo_Diff:
            ray_types_to_denoise = ray_types_to_denoise + ("Diff",)        
            # if bpy.data.scenes[render_scene_name].Turbo_SSS or (bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Diff_Behind_Vol) or bpy.data.scenes[render_scene_name].Heavy_DOF:
            #     ray_types_to_denoise = ray_types_to_denoise + ("DiffCol",)
    #this will denoise the last node in the denoise tree
    ray_types_to_denoise = ray_types_to_denoise + ('end_node',)

    return ray_types_to_denoise

def get_rays_to_denoise(render_scene_name):

    ray_types_to_denoise = tuple()

    if bpy.data.scenes[render_scene_name].Turbo_Geo:
        #Diff
        if bpy.data.scenes[render_scene_name].Turbo_Diff:
            ray_types_to_denoise = ray_types_to_denoise + ("Diff",)        
            
        #Gloss            
        if bpy.data.scenes[render_scene_name].Turbo_Gloss:
            ray_types_to_denoise = ray_types_to_denoise + ("Gloss",)            
        #Emit
        if bpy.data.scenes[render_scene_name].Turbo_Emit and ((bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Emission_Behind_Vol) or bpy.data.scenes[render_scene_name].Heavy_DOF ):
            ray_types_to_denoise = ray_types_to_denoise + ("Emit",)
        #trans
        if bpy.data.scenes[render_scene_name].Turbo_Trans:
            ray_types_to_denoise = ray_types_to_denoise + ("Trans",)            

     #Alpha
    if bpy.data.scenes[render_scene_name].render.film_transparent:
        ray_types_to_denoise = ray_types_to_denoise + ("Alpha",)        
    #Environment
    if bpy.data.scenes[render_scene_name].Turbo_Env:
        if not bpy.data.scenes[render_scene_name].Env_Only_Behind_Glass or (bpy.data.scenes[render_scene_name].render.film_transparent and bpy.data.scenes[render_scene_name].cycles.film_transparent_glass):
            if (bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Env_Behind_Vol) or bpy.data.scenes[render_scene_name].Heavy_DOF:
                ray_types_to_denoise = ray_types_to_denoise + ("Env",)        
    #volume
    if bpy.data.scenes[render_scene_name].Turbo_Volume:
        ray_types_to_denoise = ray_types_to_denoise + ("Volume",)#,"VolumeInd")        

    return set(ray_types_to_denoise)



def get_extreme_ray_types_to_denoise(render_scene_name):

    sockets_to_denoise = tuple()
    if bpy.data.scenes[render_scene_name].Turbo_Geo:

        #Diff
        if bpy.data.scenes[render_scene_name].Turbo_Diff:
            sockets_to_denoise = sockets_to_denoise + ("DiffDir",)
            if bpy.data.scenes[render_scene_name].cycles.max_bounces > 0 and bpy.data.scenes[render_scene_name].cycles.diffuse_bounces > 0:
                sockets_to_denoise = sockets_to_denoise + ("DiffInd",)
            #if bpy.data.scenes[render_scene_name].Turbo_SSS or bpy.data.scenes[render_scene_name].Heavy_DOF or (bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Diff_Behind_Vol):
            if bpy.data.scenes[render_scene_name].Turbo_SSS or (bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Diff_Behind_Vol) or bpy.data.scenes[render_scene_name].Heavy_DOF:
                sockets_to_denoise = sockets_to_denoise + ("DiffCol",)
        #Gloss            
        if bpy.data.scenes[render_scene_name].Turbo_Gloss:
            sockets_to_denoise = sockets_to_denoise + ("GlossDir",)
            if bpy.data.scenes[render_scene_name].cycles.max_bounces > 0 and bpy.data.scenes[render_scene_name].cycles.glossy_bounces > 0:
                sockets_to_denoise = sockets_to_denoise + ("GlossInd",)
            if (bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Gloss_Behind_Vol) or bpy.data.scenes[render_scene_name].Heavy_DOF:
                sockets_to_denoise = sockets_to_denoise + ("GlossCol",)
        #Emit
        if bpy.data.scenes[render_scene_name].Turbo_Emit and ((bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Emission_Behind_Vol) or bpy.data.scenes[render_scene_name].Heavy_DOF ):
            sockets_to_denoise = sockets_to_denoise + ("Emit",)
        #trans
        if bpy.data.scenes[render_scene_name].Turbo_Trans:
            sockets_to_denoise = sockets_to_denoise + ("TransDir",)
            if bpy.data.scenes[render_scene_name].cycles.max_bounces > 0 and bpy.data.scenes[render_scene_name].cycles.transmission_bounces > 0:
                sockets_to_denoise = sockets_to_denoise + ("TransInd",)
            if bpy.data.scenes[render_scene_name].Heavy_DOF or (bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Trans_Behind_Vol):
                sockets_to_denoise = sockets_to_denoise + ("TransCol",)

     #Alpha
    if bpy.data.scenes[render_scene_name].render.film_transparent:
        sockets_to_denoise = sockets_to_denoise + ("Alpha",)
    #Environment
    if bpy.data.scenes[render_scene_name].Turbo_Env:
        if not bpy.data.scenes[render_scene_name].Env_Only_Behind_Glass or (bpy.data.scenes[render_scene_name].render.film_transparent and bpy.data.scenes[render_scene_name].cycles.film_transparent_glass):
            if (bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Env_Behind_Vol) or bpy.data.scenes[render_scene_name].Heavy_DOF:
                sockets_to_denoise = sockets_to_denoise + ("Env",)
    #volume
    if bpy.data.scenes[render_scene_name].Turbo_Volume:
        sockets_to_denoise = sockets_to_denoise + ("VolumeDir",)#,"VolumeInd")        
        if bpy.data.scenes[render_scene_name].cycles.max_bounces > 0 and bpy.data.scenes[render_scene_name].cycles.volume_bounces > 0:
            sockets_to_denoise = sockets_to_denoise + ("VolumeInd",)

    return set(sockets_to_denoise)

def create_and_wire_denoise_nodes(scene_name,denoising_candidates,render_scene_name,render_layer_node_name,denoise_mode = 'High'):
    
    #fully_combined_passes format = raytype,node name, socket name (names are fine as it's only every going to be nodes defined by the program, not the user.  so there is no chance of duplicates.)
    #geoemtry    
    #preserve_texture = bpy.data.scenes[render_scene_name].Turbo_Render_Enhance_Textures
    if denoise_mode == 'Ultra':
        ray_types_to_denoise = get_extreme_ray_types_to_denoise(render_scene_name)
    elif denoise_mode == 'Draft':
        ray_types_to_denoise = get_draft_rays_to_denoise(render_scene_name)
    else:
        ray_types_to_denoise = get_rays_to_denoise(render_scene_name)

    #create the denoise nodes:
    for index,p in enumerate(denoising_candidates):
        if denoise_mode == 'Ultra':
            denoise_candidate_pass = p[2]
        else:
            denoise_candidate_pass = p[0]

        if denoise_candidate_pass in ray_types_to_denoise:            
            node_to_connect_to_denoise = bpy.data.scenes[scene_name].node_tree.nodes[p[1]]
            #print('denoised',denoise_candidate_pass, p[2],p[1])
            original_node_name = node_to_connect_to_denoise.name
            s = node_to_connect_to_denoise.outputs[p[2]]
            denoise_node_names = []            #denoise_pos = (original_node.location.x + original_node.width + 50, original_node.location.y - 15)
            denoise_pos = node_to_connect_to_denoise.location

            denoise_node = bpy.data.scenes[scene_name].node_tree.nodes.new('CompositorNodeDenoise')            
            denoise_node.label = s.name
            denoise_node.name = f"dnoise_{original_node_name}_{s.name}"# file_system_helpers.create_exr_friendly_socket_name_with_prefix(scene_name,index,s.name)
            denoise_node_names.append(denoise_node.name)            
            denoise_node.location = denoise_pos
            global_vars.denoise_nodes_to_delete.append(denoise_node.name)
            denoise_node.hide = True
            denoise_node.use_hdr = True
            if bpy.data.scenes[render_scene_name].Turbo_Render_HQ:
                denoise_node.prefilter = 'ACCURATE'
            else:
                denoise_node.prefilter = 'NONE'

            if s.name == 'Alpha':
                denoise_node.use_hdr = False            

            #choose which pre-filters (albedo, normals) to connect to the denoise node
            denoise_normals_socket = [s for s in bpy.data.scenes[scene_name].node_tree.nodes[render_layer_node_name].outputs if s.name == 'Denoising Normal'][0]
            denoise_albedo_socket = [s for s in bpy.data.scenes[scene_name].node_tree.nodes[render_layer_node_name].outputs if s.name == 'Denoising Albedo'][0]

            #use 'skip' in from sockets if you want to skip an input, for example instead of denoise_albedo_socket use 'skip'
            if p[0] in ('Volume',):
                from_sockets = (s,'skip',denoise_albedo_socket)#added albedo to volume for better definition
                #denoise_node.prefilter = 'NONE' #disabled this so uses user very dirty setting
            
            elif s.name in ('Env','Alpha'): 
                from_sockets = (s,)
                denoise_node.prefilter = 'NONE'
            elif p[0] in ('Diff',):           
                if bpy.data.scenes[render_scene_name].Turbo_Render_Enhance_Textures:
                    if p[2].endswith('Col'):                    
                        from_sockets = (s,denoise_normals_socket,denoise_albedo_socket)
                    else:
                        from_sockets = (s,denoise_normals_socket, denoise_albedo_socket )
                else:
                    if denoise_mode in ('High','Ultra'):
                        #from_sockets = (s,denoise_normals_socket,'skip')#got rid of this because of bad results in gi areas
                        from_sockets = (s,denoise_normals_socket, denoise_albedo_socket )
                    else:
                        from_sockets = (s,denoise_normals_socket, denoise_albedo_socket )
            else:
                from_sockets = (s, denoise_normals_socket, denoise_albedo_socket)            

            #connect denoise inputs
            for i in range(len(from_sockets)):
                if from_sockets[i] == 'skip':
                    continue
                bpy.data.scenes[scene_name].node_tree.links.new(
                                            from_sockets[i],
                                            denoise_node.inputs[i]
                                        )

            #move all links from original node output to the denoise node to ensure denoised data received by upstream nodes
            for l in s.links:
                if l.to_node.name != denoise_node.name:
                    if denoise_mode not in ('Ultra','Draft') and 'turbo_render_node' not in l.to_node: #this ensures that the denoised passes arent saved when not in ultra mode
                        continue
                    bpy.data.scenes[scene_name].node_tree.links.new(
                                                denoise_node.outputs[0],
                                                l.to_socket
                                            )
            global_vars.location = None


    


def enable_turbo_render_passes(viewlayer_name,scene_name):
    viewlayer = bpy.data.scenes[scene_name].view_layers[viewlayer_name]
    current_render_engine = bpy.data.scenes[scene_name].render.engine
    varname = f'consts.turbo_passes_{str(current_render_engine).lower}'
    
    required_passes = getattr(consts,f'turbo_passes_{current_render_engine.lower()}')
    for p in required_passes:
        function_string = f'viewlayer.{p[0]}'
        if not eval(function_string):
            global_vars.turbo_passes_enabled.add((scene_name,viewlayer_name,p[0],p[1]))
            #print('turned on',p[0])
            exec(str(f'{function_string} = True'))
            #x = True
            # exec(eval(function_string))


def revert_from_turbo_render_passes_back_to_user_passes():
    if global_vars.turbo_passes_enabled is not None:
        for p in global_vars.turbo_passes_enabled:
            viewlayer = bpy.data.scenes[p[0]].view_layers[p[1]]
            function_string = f'viewlayer.{p[2]}'
            #print('turned off',p[2])
            exec(str(f'{function_string} = False'))
        global_vars.turbo_passes_enabled = None


def build_recombine_passes_tree(scene_name,node_with_passes_name,is_turbo,render_scene_name,file_output_node_name,denoise_mode = 'High'):    

    def add(ray_type):
        
        return create_mix_node_and_make_connections(bpy.data.scenes[scene_name].node_tree.nodes[node_with_passes_name].outputs[f'{ray_type}Dir'],
                                                        bpy.data.scenes[scene_name].node_tree.nodes[node_with_passes_name].outputs[f'{ray_type}Ind'],
                                                        'ADD',node_with_passes_name,location,1,scene_name,is_turbo)
    def multiply(from_add_node,ray_type):
        return create_mix_node_and_make_connections(bpy.data.scenes[scene_name].node_tree.nodes[from_add_node].outputs['Image'],
                                                    bpy.data.scenes[scene_name].node_tree.nodes[node_with_passes_name].outputs[f'{ray_type}Col'],
                                                    'MULTIPLY',node_with_passes_name,location,1,scene_name,is_turbo)

    def add_fully_combined_passes_to_each_other(a_details,b_details):
        
        return create_mix_node_and_make_connections(bpy.data.scenes[scene_name].node_tree.nodes[a_details[1]].outputs[a_details[2]],
                                                        bpy.data.scenes[scene_name].node_tree.nodes[b_details[1]].outputs[b_details[2]],
                                                        'ADD',node_with_passes_name,location,1,scene_name,is_turbo)

    location = bpy.data.scenes[scene_name].node_tree.nodes[node_with_passes_name].location

    


    ray_types_to_add_and_multiply = ('Diff','Gloss','Trans')#add dir and ind then multiply with col
    ray_types_to_add_only = ('Volume',)#no multiply so add only
    singular_passes = ('Env','Emit')
    

    fully_combined_passes = []#this will store the ray type so we know which ray it is when adding the denoise, the node to use as the from socket for the denoise, and the output socket to connect to the denoise node
    candidate_node_for_denoising = []
    preserve_texture = bpy.data.scenes[render_scene_name].Turbo_Render_Enhance_Textures
    preserve_glossy = bpy.data.scenes[render_scene_name].Turbo_Render_Enhance_Glossy
    preserve_trans = bpy.data.scenes[render_scene_name].Turbo_Render_Enhance_Trans

    
    for rt in ray_types_to_add_and_multiply:
        add_node = add(rt)      
        multiply_node = multiply(add_node,rt)
        fully_combined_passes.append((rt,multiply_node,'Image'))

        if denoise_mode == 'Ultra':
            candidate_node_for_denoising.append((rt,node_with_passes_name,f'{rt}Dir'))
            candidate_node_for_denoising.append((rt,node_with_passes_name,f'{rt}Ind'))
            candidate_node_for_denoising.append((rt,node_with_passes_name,f'{rt}Col'))
        
        elif denoise_mode == 'Draft':

            if rt == 'Diff' and preserve_texture:
                candidate_node_for_denoising.append((rt,add_node,'Image'))                
                if bpy.data.scenes[render_scene_name].Turbo_SSS or (bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Diff_Behind_Vol) or bpy.data.scenes[render_scene_name].Heavy_DOF:
                    candidate_node_for_denoising.append((rt,node_with_passes_name,f'{rt}Col'))

        else:
        
            # if preserve_texture == True and rt == 'Diff':
            #     candidate_node_for_denoising.append((rt,add_node,'Image'))
            #     if bpy.data.scenes[render_scene_name].Heavy_DOF:
            #         candidate_node_for_denoising.append((rt,node_with_passes_name,f'{rt}Col'))
            if rt == 'Diff':
                if denoise_mode == 'High':
                    candidate_node_for_denoising.append((rt,node_with_passes_name,f'{rt}Dir'))
                    if bpy.data.scenes[render_scene_name].cycles.max_bounces > 0 and bpy.data.scenes[render_scene_name].cycles.diffuse_bounces > 0:
                        candidate_node_for_denoising.append((rt,node_with_passes_name,f'{rt}Ind'))
                    if bpy.data.scenes[render_scene_name].Turbo_SSS or (bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Diff_Behind_Vol) or bpy.data.scenes[render_scene_name].Heavy_DOF:
                            candidate_node_for_denoising.append((rt,node_with_passes_name,f'{rt}Col'))
                else:
                    if preserve_texture == True:
                        candidate_node_for_denoising.append((rt,add_node,'Image'))
                        if bpy.data.scenes[render_scene_name].Turbo_SSS or (bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Diff_Behind_Vol) or bpy.data.scenes[render_scene_name].Heavy_DOF:
                            candidate_node_for_denoising.append((rt,node_with_passes_name,f'{rt}Col'))
                    else:
                        candidate_node_for_denoising.append((rt,multiply_node,'Image'))
                        
            
            elif preserve_glossy == True and rt == 'Gloss':
                candidate_node_for_denoising.append((rt,add_node,'Image'))
                if (bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Gloss_Behind_Vol) or bpy.data.scenes[render_scene_name].Heavy_DOF:
                    candidate_node_for_denoising.append((rt,node_with_passes_name,f'{rt}Col'))
            
            elif preserve_trans == True and rt == 'Trans':
                candidate_node_for_denoising.append((rt,add_node,'Image'))
                if bpy.data.scenes[render_scene_name].Heavy_DOF or (bpy.data.scenes[render_scene_name].Turbo_Volume and bpy.data.scenes[render_scene_name].Trans_Behind_Vol):
                    candidate_node_for_denoising.append((rt,node_with_passes_name,f'{rt}Col'))
            else:
                candidate_node_for_denoising.append((rt,multiply_node,'Image'))
    
    for rt in ray_types_to_add_only:
        add_node = add(rt)
        if denoise_mode == 'Ultra':
            candidate_node_for_denoising.append((rt,node_with_passes_name,f'{rt}Dir'))
            candidate_node_for_denoising.append((rt,node_with_passes_name,f'{rt}Ind'))
            fully_combined_passes.append((rt,add_node,'Image'))
        else:
            fully_combined_passes.append((rt,add_node,'Image'))
            candidate_node_for_denoising.append((rt,add_node,'Image'))

    for rt in singular_passes:
        if bpy.data.scenes[render_scene_name].render.film_transparent and rt =='Env':
            continue
        fully_combined_passes.append((rt,node_with_passes_name,rt))
        candidate_node_for_denoising.append((rt,node_with_passes_name,rt))
    
    #add them all together:
    last_node_added = tuple()
    #tuple_len = len(fully_combined_passes)
    fully_combined_passes = list(reversed(fully_combined_passes))
    for index,rt in enumerate(fully_combined_passes):
        if index >0:#dont do anything on the first iteration 
            if index == 1:
                last_node_added = ('', add_fully_combined_passes_to_each_other(fully_combined_passes[index -1],rt),'Image')
            else:
                if denoise_mode == 'Draft' and rt[0] == 'Diff' and preserve_texture:
                    #add alpha if needed
                    current_end_node_name,last_socket = add_alpha(scene_name, node_with_passes_name, is_turbo, render_scene_name, fully_combined_passes, candidate_node_for_denoising, last_node_added,draft = True)
                    candidate_node_for_denoising.append(('end_node',current_end_node_name,'Image'))
                    last_node_added = ('', current_end_node_name,'Image')
                    #last_node_added = ('',add_fully_combined_passes_to_each_other(last_node_added,rt),'Image')
                last_node_added = ('',add_fully_combined_passes_to_each_other(last_node_added,rt),'Image')
    
    
        
    current_end_node_name = last_node_added[1]
    last_socket = get_out_socket(last_node_added[1],last_node_added[2],scene_name)
    
    if denoise_mode != 'Draft' or not preserve_texture:
        #add alpha if needed
        current_end_node_name, last_socket = add_alpha(scene_name, node_with_passes_name, is_turbo, render_scene_name, fully_combined_passes, candidate_node_for_denoising, last_node_added)
        
    if denoise_mode == 'Draft' and not preserve_texture:
        candidate_node_for_denoising.append(('end_node',current_end_node_name,'Image'))
    #connect last mix to file output nodes image input (should always be 0 and called 0_Image) got with 0 just in case blender change it's name (it'll always be at the top)    
    file_output_image_input_socket = bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].inputs[0]
    #connect mix input 1
    bpy.data.scenes[scene_name].node_tree.links.new(
                                last_socket,
                                file_output_image_input_socket
                                )        

    #move all links from the image output to the last mix node so that it's result is used in the standard file output.

    for link in bpy.data.scenes[scene_name].node_tree.nodes[node_with_passes_name].outputs[0].links:
        if link.to_node.name not in global_vars.turbo_render_nodes_to_delete:
            bpy.data.scenes[scene_name].node_tree.links.new(
                                    last_socket,
                                    link.to_socket
                                    )        
    if global_vars.turbo_render_end_nodes_whose_links_to_move_back_to_their_render_layers_node_image_output is None:
        global_vars.turbo_render_end_nodes_whose_links_to_move_back_to_their_render_layers_node_image_output = []
    global_vars.turbo_render_end_nodes_whose_links_to_move_back_to_their_render_layers_node_image_output.append((node_with_passes_name,current_end_node_name))
    
    return candidate_node_for_denoising

def add_alpha(scene_name, node_with_passes_name, is_turbo, render_scene_name, fully_combined_passes, candidate_node_for_denoising, last_node_added,draft = False):
    #add alpha node if necessary
    current_end_node_name = last_node_added[1]
    last_socket = get_out_socket(last_node_added[1],last_node_added[2],scene_name)
    if bpy.data.scenes[render_scene_name].render.film_transparent:
        current_end_node_name = create_set_alpha_node_between_last_mix_node_and_image_input_on_file_output_node(last_socket,node_with_passes_name,scene_name,is_turbo)
        last_socket = get_out_socket(current_end_node_name,'Image',scene_name)
        if not draft:
            fully_combined_passes.append(('Alpha',node_with_passes_name,'Alpha'))
            candidate_node_for_denoising.append(('Alpha',node_with_passes_name,'Alpha'))
    return current_end_node_name,last_socket


