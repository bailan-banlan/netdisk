import bpy
from . import file_system_helpers
from ...data import get_data
from ...variables import global_vars,consts
from ..dont_register import checks,report_custom_error,node_helpers,cache_operation_helpers
from bpy.types import NodeTree


def enable_vector_pass(render_layer_node_name,scene_name):
    render_layer_scene = bpy.data.scenes[scene_name].node_tree.nodes[render_layer_node_name].scene.name
    render_layer_viewlayer = bpy.data.scenes[scene_name].node_tree.nodes[render_layer_node_name].layer    
    bpy.data.scenes[render_layer_scene].view_layers[render_layer_viewlayer].use_pass_vector = True

    if global_vars.vector_pass_enabled_for_render is None:
        global_vars.vector_pass_enabled_for_render = []
    global_vars.vector_pass_enabled_for_render.append((render_layer_viewlayer,render_layer_scene))

def disable_vector_passes_that_were_not_enabled_by_user():
    if global_vars.vector_pass_enabled_for_render is not None:
        for v in global_vars.vector_pass_enabled_for_render:
            bpy.data.scenes[v[1]].view_layers[v[0]].use_pass_vector = False
    global_vars.vector_pass_enabled_for_render = None
            


def create_median_group(scene_name):
    if not bpy.data.scenes[scene_name].Temporal_RGBA_Seperately:
        create_median_group_fast_mode(scene_name)
    else:
        create_median_group_seperate_rgba(scene_name)

def create_median_group_seperate_rgba(scene_name):
    #print('rgba median')
    Turbo_median_group = bpy.data.node_groups.new(
        type='CompositorNodeTree',
        name=".Turbo_Median_Group"
        )
    input_node = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new("NodeGroupInput")
    input_node_name = input_node.name
    input_node.location = (-200, 0)

    output_node = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new("NodeGroupOutput")
    output_node_name = output_node.name
    output_node.location = (1800, 0)

    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketColor", "Current Frame")
    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketColor", "Previous Frame")
    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketVector", "Previous Frame Vector")
    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketFloat", "Prev Disp Scale")
    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketColor", "Next Frame")
    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketVector", "Next Frame Vector")
    
    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketFloat", "Next Disp Scale")

    bpy.data.node_groups['.Turbo_Median_Group'].outputs.new("NodeSocketColor", "Median")
    
    
    disp_prev = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new('CompositorNodeDisplace')
    disp_prev_name = disp_prev.name
    disp_prev.label = disp_prev_name
    disp_prev.location = (0,0)
    disp_prev.inputs[2].default_value = 1
    disp_prev.inputs[3].default_value = 1

    disp_next = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new('CompositorNodeDisplace')
    disp_next_name = disp_next.name
    disp_next.label=disp_next_name
    disp_next.location=(0,200)
    disp_next.inputs[2].default_value = 1
    disp_next.inputs[3].default_value = 1


    max_a = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new("CompositorNodeGroup")
    max_a_name = max_a.name
    max_a.label = max_a_name
    max_a.location = (200,200)
    max_a.node_tree = bpy.data.node_groups[".Turbo_Max"]

    min_top = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new("CompositorNodeGroup")
    min_top_name = min_top.name
    min_top.label = min_top_name
    min_top.location = (200,-100)
    min_top.node_tree = bpy.data.node_groups[".Turbo_Min"]

    min_bottom = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new("CompositorNodeGroup")
    min_bottom_name = min_bottom.name
    min_bottom.label = min_bottom_name
    min_bottom.location = (400,0)
    min_bottom.node_tree = bpy.data.node_groups[".Turbo_Min"]

    max_b = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new("CompositorNodeGroup")
    max_b_name = max_b.name
    max_b.label = max_b_name
    max_b.location = (200,200)
    max_b.node_tree = bpy.data.node_groups[".Turbo_Max"]

    

    #prev to disp prev
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Previous Frame"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_prev_name].inputs["Image"]
            )    
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Previous Frame Vector"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_prev_name].inputs["Vector"]
            )
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Prev Disp Scale"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_prev_name].inputs["X Scale"]
            )
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Prev Disp Scale"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_prev_name].inputs["Y Scale"]
            )
    
    #next frame to disp
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Next Frame"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_next_name].inputs["Image"]
            )    
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Next Frame Vector"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_next_name].inputs["Vector"]
            )
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Next Disp Scale"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_next_name].inputs["X Scale"]
            )
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Next Disp Scale"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_next_name].inputs["Y Scale"]
            )
    
    #current to max_a soket A
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Current Frame"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[max_a_name].inputs["A"]
            )
    #disp next to max_a socket B
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_next_name].outputs["Image"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[max_a_name].inputs["B"]
            )
    
    #disp prev to min_top socket B
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_prev_name].outputs["Image"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_top_name].inputs["B"]
            )
    #min_top socket A
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[max_a_name].outputs["Max"],
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_top_name].inputs["A"]
        )

    #min bottom socket A
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Current Frame"],
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_bottom_name].inputs["A"]
        )
    #min_bottom socket B
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_next_name].outputs["Image"],
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_bottom_name].inputs["B"]
        )

    #max_b socket A
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_top_name].outputs["Min"],
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[max_b_name].inputs["A"]
        )
    #max_b socket B
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_bottom_name].outputs["Min"],
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[max_b_name].inputs["B"]
        )

    #group output
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[max_b_name].outputs["Max"],
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[output_node_name].inputs["Median"]
        )

def create_median_group_fast_mode(scene_name):

    Turbo_median_group = bpy.data.node_groups.new(
        type='CompositorNodeTree',
        name=".Turbo_Median_Group"
        )
    input_node = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new("NodeGroupInput")
    input_node_name = input_node.name
    input_node.location = (-200, 0)

    output_node = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new("NodeGroupOutput")
    outptut_node_name = output_node.name
    output_node.location = (1800, 0)

    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketColor", "Current Frame")
    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketColor", "Previous Frame")
    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketVector", "Previous Frame Vector")
    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketFloat", "Prev Disp Scale")
    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketColor", "Next Frame")
    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketVector", "Next Frame Vector")
    
    bpy.data.node_groups['.Turbo_Median_Group'].inputs.new("NodeSocketFloat", "Next Disp Scale")

    bpy.data.node_groups['.Turbo_Median_Group'].outputs.new("NodeSocketColor", "Median")
    
    
    disp_prev = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new('CompositorNodeDisplace')
    disp_prev_name = disp_prev.name
    disp_prev.label = disp_prev_name
    disp_prev.location = (0,0)
    disp_prev.inputs[2].default_value = 1
    disp_prev.inputs[3].default_value = 1

    disp_next = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new('CompositorNodeDisplace')
    disp_next_name = disp_next.name
    disp_next.label=disp_next_name
    disp_next.location=(0,200)
    disp_next.inputs[2].default_value = 1
    disp_next.inputs[3].default_value = 1


    min_max_a = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new("CompositorNodeGroup")
    min_max_a_name = min_max_a.name
    min_max_a.label = min_max_a_name
    min_max_a.location = (200,200)
    min_max_a.node_tree = bpy.data.node_groups[".Turbo_Min_Max"]

    min_max_b = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new("CompositorNodeGroup")
    min_max_b_name = min_max_b.name
    min_max_b.label = min_max_b_name
    min_max_b.location = (200,-100)
    min_max_b.node_tree = bpy.data.node_groups[".Turbo_Min_Max"]

    min_max_c = bpy.data.node_groups['.Turbo_Median_Group'].nodes.new("CompositorNodeGroup")
    min_max_c_name = min_max_c.name
    min_max_c.label = min_max_c_name
    min_max_c.location = (400,0)
    min_max_c.node_tree = bpy.data.node_groups[".Turbo_Min_Max"]

    #current to min_max_a
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Current Frame"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_max_a_name].inputs["A"]
            )

    #prev to disp prev
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Previous Frame"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_prev_name].inputs["Image"]
            )    
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Previous Frame Vector"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_prev_name].inputs["Vector"]
            )
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Prev Disp Scale"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_prev_name].inputs["X Scale"]
            )
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Prev Disp Scale"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_prev_name].inputs["Y Scale"]
            )
    
    #next frame to disp
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Next Frame"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_next_name].inputs["Image"]
            )    
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Next Frame Vector"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_next_name].inputs["Vector"]
            )
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Next Disp Scale"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_next_name].inputs["X Scale"]
            )
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[input_node_name].outputs["Next Disp Scale"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_next_name].inputs["Y Scale"]
            )
    
    #disp prev to mix max a - B
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_prev_name].outputs["Image"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_max_a_name].inputs["B"]
            )

    #disp next to mix max b - B
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[disp_next_name].outputs["Image"],
            bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_max_b_name].inputs["B"]
            )
    
    #mix_max_a
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_max_a_name].outputs["Max"],
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_max_b_name].inputs["A"]
        )
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_max_a_name].outputs["Min"],
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_max_c_name].inputs["B"]
        )

    #mix_max_b
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_max_b_name].outputs["Min"],
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_max_c_name].inputs["A"]
        )

    #mix_max_c
    bpy.data.node_groups['.Turbo_Median_Group'].links.new(
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[min_max_c_name].outputs["Max"],
        bpy.data.node_groups['.Turbo_Median_Group'].nodes[outptut_node_name].inputs["Median"]
        )


        


def create_min_max(scene_name):
    '''max unless max set to false on call'''
    turbo_min_max = bpy.data.node_groups.new(
        type='CompositorNodeTree',
        name=".Turbo_Min_Max"
        )
    
    input_node = bpy.data.node_groups['.Turbo_Min_Max'].nodes.new("NodeGroupInput")
    input_node.name="G_in"
    input_node.location = (-200, 0)

    output_node = bpy.data.node_groups['.Turbo_Min_Max'].nodes.new("NodeGroupOutput")
    output_node.name="G_out"
    output_node.location = (400, 0)

    bpy.data.node_groups['.Turbo_Min_Max'].inputs.new("NodeSocketColor", "A")
    bpy.data.node_groups['.Turbo_Min_Max'].inputs.new("NodeSocketColor", "B")
    bpy.data.node_groups['.Turbo_Min_Max'].outputs.new("NodeSocketColor", "Max")
    bpy.data.node_groups['.Turbo_Min_Max'].outputs.new("NodeSocketColor", "Min")

    math_node = bpy.data.node_groups['.Turbo_Min_Max'].nodes.new('CompositorNodeMath')
    math_node.name="less_than"
    math_node.operation = 'LESS_THAN'
    math_node.location = (0,0)
    find_max =   bpy.data.node_groups['.Turbo_Min_Max'].nodes.new('CompositorNodeMixRGB')
    find_max.name="mix_max"
    find_max.location = (200,0)
    find_min =   bpy.data.node_groups['.Turbo_Min_Max'].nodes.new('CompositorNodeMixRGB')
    find_min.name="mix_min"
    find_min.location = (200,-400)

    #in to math
    bpy.data.node_groups['.Turbo_Min_Max'].links.new(
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["G_in"].outputs["A"],
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["less_than"].inputs[0]
            )
    bpy.data.node_groups['.Turbo_Min_Max'].links.new(
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["G_in"].outputs["B"],
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["less_than"].inputs[1]
            )

    #in to mix max
    bpy.data.node_groups['.Turbo_Min_Max'].links.new(
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["G_in"].outputs["A"],
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["mix_max"].inputs[1]
            )
    bpy.data.node_groups['.Turbo_Min_Max'].links.new(
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["G_in"].outputs["B"],
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["mix_max"].inputs[2]
            )

    #in to mix min
    bpy.data.node_groups['.Turbo_Min_Max'].links.new(
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["G_in"].outputs["A"],
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["mix_min"].inputs[2]
            )
    bpy.data.node_groups['.Turbo_Min_Max'].links.new(
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["G_in"].outputs["B"],
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["mix_min"].inputs[1]
            )

    #less than out to mix max fac
    bpy.data.node_groups['.Turbo_Min_Max'].links.new(
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["less_than"].outputs["Value"],
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["mix_max"].inputs[0]
            )
    #less than out to mix min fac
    bpy.data.node_groups['.Turbo_Min_Max'].links.new(
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["less_than"].outputs["Value"],
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["mix_min"].inputs[0]
            )
    
    #mix max to out
    bpy.data.node_groups['.Turbo_Min_Max'].links.new(
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["mix_max"].outputs["Image"],
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["G_out"].inputs["Max"]
            )

    #mix min to out
    bpy.data.node_groups['.Turbo_Min_Max'].links.new(
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["mix_min"].outputs["Image"],
            bpy.data.node_groups['.Turbo_Min_Max'].nodes["G_out"].inputs["Min"]
            )

def create_min_max_with_seperate_rgba(scene_name,min_node = True):
    '''min for use in deep temporalisation mode'''
    #print('creating rgba min max')
    if min_node:
        group_name = '.Turbo_Min'
        operation = 'MINIMUM'
        out_sock_name = 'Min'
    else:
        group_name = '.Turbo_Max'
        operation = 'MAXIMUM'
        out_sock_name = 'Max'

    turbo_min_max_sep = bpy.data.node_groups.new(
        type='CompositorNodeTree',
        name=group_name
        )

    
    input_node = bpy.data.node_groups[group_name].nodes.new("NodeGroupInput")
    input_node_name= input_node.name
    input_node.location = (-200, 0)

    output_node = bpy.data.node_groups[group_name].nodes.new("NodeGroupOutput")
    output_node_name = output_node.name
    output_node.location = (1000, 0)

    bpy.data.node_groups[group_name].inputs.new("NodeSocketColor", "A")
    bpy.data.node_groups[group_name].inputs.new("NodeSocketColor", "B")
    bpy.data.node_groups[group_name].outputs.new("NodeSocketColor", out_sock_name)

    try:
        seperate_node_a = bpy.data.node_groups[group_name].nodes.new("CompositorNodeSeparateColor")    
        seperate_node_b = bpy.data.node_groups[group_name].nodes.new("CompositorNodeSeparateColor")    
        combine_image_node = bpy.data.node_groups[group_name].nodes.new("CompositorNodeCombineColor")
        combine_image_node.label = 'Temporalising'
        red = 'Red'
        green = 'Green'
        blue = 'Blue'
        alpha = 'Alpha'
        
    except:

        seperate_node_a = bpy.data.node_groups[group_name].nodes.new("CompositorNodeSepRGBA")    
        seperate_node_b = bpy.data.node_groups[group_name].nodes.new("CompositorNodeSepRGBA")
        combine_image_node = bpy.data.node_groups[group_name].nodes.new("CompositorNodeCombRGBA")
        combine_image_node.label = 'Temporalising'
        red = 'R'
        green = 'G'
        blue = 'B'
        alpha = 'A'
        

    seperate_name_a = seperate_node_a.name
    seperate_name_b = seperate_node_b.name
    seperate_node_a.location = (0,250)
    seperate_node_a.hide = True
    seperate_node_b.location = (0,-250)
    seperate_node_b.hide = True    

    math_node_r = bpy.data.node_groups[group_name].nodes.new('CompositorNodeMath')
    math_node_r_name = math_node_r.name
    math_node_r.operation = operation
    math_node_r.location = (400,500)

    math_node_g = bpy.data.node_groups[group_name].nodes.new('CompositorNodeMath')
    math_node_g_name = math_node_g.name
    math_node_g.operation = operation
    math_node_g.location = (400,250)

    math_node_b = bpy.data.node_groups[group_name].nodes.new('CompositorNodeMath')
    math_node_b_name = math_node_b.name
    math_node_b.operation = operation
    math_node_b.location = (400,-100)

    math_node_a = bpy.data.node_groups[group_name].nodes.new('CompositorNodeMath')
    math_node_a_name = math_node_a.name
    math_node_a.operation = operation
    math_node_a.location = (400,-400)


    combine_name = combine_image_node.name    
    combine_image_node.location = (900,0)
    combine_image_node.hide = True
    

    #in A to sep a
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[input_node_name].outputs["A"],
            bpy.data.node_groups[group_name].nodes[seperate_name_a].inputs['Image']
            )
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[input_node_name].outputs["B"],
            bpy.data.node_groups[group_name].nodes[seperate_name_b].inputs['Image']
            )

    #red
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[seperate_name_a].outputs[red],
            bpy.data.node_groups[group_name].nodes[math_node_r_name].inputs[0]
            )
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[seperate_name_b].outputs[red],
            bpy.data.node_groups[group_name].nodes[math_node_r_name].inputs[1]
            )

    #green
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[seperate_name_a].outputs[green],
            bpy.data.node_groups[group_name].nodes[math_node_g_name].inputs[0]
            )
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[seperate_name_b].outputs[green],
            bpy.data.node_groups[group_name].nodes[math_node_g_name].inputs[1]
            )
        

     #blue
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[seperate_name_a].outputs[blue],
            bpy.data.node_groups[group_name].nodes[math_node_b_name].inputs[0]
            )
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[seperate_name_b].outputs[blue],
            bpy.data.node_groups[group_name].nodes[math_node_b_name].inputs[1]
            )

     #alpha
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[seperate_name_a].outputs[alpha],
            bpy.data.node_groups[group_name].nodes[math_node_a_name].inputs[0]
            )
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[seperate_name_b].outputs[alpha],
            bpy.data.node_groups[group_name].nodes[math_node_a_name].inputs[1]
            )

    
    #math R to Combine
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[math_node_r_name].outputs['Value'],
            bpy.data.node_groups[group_name].nodes[combine_name].inputs[red]
            )
    #math g to Combine
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[math_node_g_name].outputs['Value'],
            bpy.data.node_groups[group_name].nodes[combine_name].inputs[green]
            )
    #math b to Combine
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[math_node_b_name].outputs['Value'],
            bpy.data.node_groups[group_name].nodes[combine_name].inputs[blue]
            )
    #math a to Combine
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[math_node_a_name].outputs['Value'],
            bpy.data.node_groups[group_name].nodes[combine_name].inputs[alpha]
            )

   

    #combine to out
    bpy.data.node_groups[group_name].links.new(
            bpy.data.node_groups[group_name].nodes[combine_name].outputs["Image"],
            bpy.data.node_groups[group_name].nodes[output_node_name].inputs[out_sock_name]
            )

def create_first_and_last_fix_nodes(scene_name):
    pass

    



def get_the_node_names_that_need_stabilising(scene_name):
    """
    returns the cache nodes that have vector passes available, and also returns user nodes that have vector outputs on the multilayer exr image sequence.
    if nodes are selected, only those will be  stabilised, if nothing is selected, then all valid nodes will be stabilised.
    
    """
    
    all_cache_nodes = node_helpers.get_all_cache_nodes(scene_name,get_muted=False)
    all_cache_nodes_with_vector_passes_available = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
                                                    if n.name in all_cache_nodes
                                                    and checks.there_are_vector_passes_available(scene_name, n.name) ]
    selected_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.select == True]

    save_file_outputs = bpy.data.scenes[scene_name].execute_file_output_nodes_during_publish

    valid_selected_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
                            if n.select == True 
                            and n.name in all_cache_nodes_with_vector_passes_available
                            and [s for s in n.outputs if s.name[s.name.find('_')+1:] not in eval(f'consts.invalid_temporal_socket_{get_render_engine_from_cache_node(scene_name,n.name)}') 
                                and s.links
                                and ((save_file_outputs) or (not save_file_outputs and [l for l in s.links if l.to_node.type != 'OUTPUT_FILE'] ))
                                ]
                            ]
    
    # if not bpy.data.scenes[scene_name].execute_file_output_nodes_during_publish:
    #     valid_selected_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
    #                             if n.name in valid_selected_nodes 
    #                             and [s for s in n.outputs if [l for l in s.links if l.to_node.type != 'OUTPUT_FILE']]]

    if len(valid_selected_nodes) == 0:
        #revert to all nodes
        cache_nodes_to_temporally_stabilize = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
                                                if n.name in all_cache_nodes_with_vector_passes_available
                                                and [s for s in n.outputs 
                                                        if s.name[s.name.find('_')+1:] not in eval(f'consts.invalid_temporal_socket_{get_render_engine_from_cache_node(scene_name,n.name)}')
                                                        and s.links
                                                        and ((save_file_outputs) or (not save_file_outputs and [l for l in s.links if l.to_node.type != 'OUTPUT_FILE'] ))
                                                    ]
                                                ]
    else:
        cache_nodes_to_temporally_stabilize = valid_selected_nodes
        
    #add any user image nodes that have vector passes.
    user_image_sequences_to_stabilize = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes
                                         if n.name in selected_nodes 
                                         and n.name not in all_cache_nodes
                                        and n.type == 'IMAGE' 
                                        and len([v for v in n.outputs if v.name in consts.valid_vector_names]) == 1]
    
    return cache_nodes_to_temporally_stabilize,user_image_sequences_to_stabilize




    

def update_standard_temporal_images(scene_name):
    frame = bpy.data.scenes[scene_name].frame_current
    temporal_images = [i.name for i in bpy.data.images if 'temporal_parent' in i ]
    for i in temporal_images:    
        render_engine = bpy.data.images[i]['render_engine']
        old_path = bpy.data.images[i].filepath
        parent_name = bpy.data.images[i]['temporal_parent']

        if 'temporal_vector' in bpy.data.images[i]:
            if 'downstream_rl_cache_node_name' in bpy.data.scenes[scene_name].node_tree.nodes[parent_name]:
                parent_name = bpy.data.scenes[scene_name].node_tree.nodes[parent_name]['downstream_rl_cache_node_name']
            vector = True
        else:
            vector = False
        if bpy.data.images[i]['temporal_type'] == 'PREV':
            new_path = file_system_helpers.get_exr(scene_name,parent_name,frame - 1,wildcard_hash=True,for_temporal_vector=vector,get_newest_rl_cache_if_not_found=False)            
        else:
            new_path = file_system_helpers.get_exr(scene_name,parent_name,frame + 1,wildcard_hash=True,for_temporal_vector=vector,get_newest_rl_cache_if_not_found=False)
        if new_path is not None:
            bpy.data.images[i].filepath = new_path        
        else:
            if vector:
                new_path = get_data.get_blank_image(render_engine)
                #new_path = 'missing'
            else:
                new_path = file_system_helpers.get_exr(scene_name,parent_name,wildcard_hash=True,for_temporal_vector=vector)
                if not new_path:
                    new_path = 'no_cache_available'
            bpy.data.images[i].filepath = new_path
        
        # print(frame)
        # print(new_path)        
        # print(bpy.data.images[i]['temporal_type'])
        # print('vector = ',vector)
        


def add_prev_next_frame_image_files_turbo_cache(scene_name,name_of_node_that_will_be_stabilised,render_engine,node_type='PREV',vector_node = False):
    
    render_layer_cache_bit_depth = bpy.context.preferences.addons[__name__.split('.')[0]].preferences.render_layer_bit_depth
    standard_cache_bit_depth = bpy.context.preferences.addons[__name__.split('.')[0]].preferences.non_render_layer_bit_depth
    original_node_name = cache_operation_helpers.get_original_node_name_from_cache_node(scene_name,name_of_node_that_will_be_stabilised)

    if vector_node:
        if bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].type != 'R_LAYERS':
            current_frame_filepath =  bpy.data.scenes[scene_name].node_tree.nodes[name_of_node_that_will_be_stabilised]['vector_path'] #vector path is added during publish setup when it checks there is only one downstream render layer node
            
        else:
            current_frame_filepath = file_system_helpers.get_exr(scene_name,name_of_node_that_will_be_stabilised,for_temporal_vector=True)
        
    else:
        current_frame_filepath = bpy.data.scenes[scene_name].node_tree.nodes[name_of_node_that_will_be_stabilised].image.filepath
    
    new_node = bpy.data.scenes[scene_name].node_tree.nodes.new('CompositorNodeImage')
    new_node.select = False
    
    if vector_node:
        new_node.label = f'Vec_{node_type}__{name_of_node_that_will_be_stabilised}'
        new_node['temporal_type'] = 'VECTOR' 
    else:
        new_node.label = f'{node_type}__{name_of_node_that_will_be_stabilised}'
        new_node['temporal_type'] = 'IMAGE' 

        

    new_node['temporal_parent'] = name_of_node_that_will_be_stabilised
    new_node['temporal_frame'] = node_type
    new_node['render_engine'] = render_engine

    
    current_frame_filepath_without_frame_and_extentsion = file_system_helpers.get_path_without_framenum_and_extension(current_frame_filepath)
    current_frame = bpy.data.scenes[scene_name].frame_current
    if node_type == 'PREV':
        temporal_path = f'{current_frame_filepath_without_frame_and_extentsion}{str(current_frame -1).zfill(4)}.exr'
    elif node_type == 'NEXT':
        temporal_path = f'{current_frame_filepath_without_frame_and_extentsion}{str(current_frame +1).zfill(4)}.exr'
    else:
        temporal_path = current_frame_filepath

        
    if temporal_path is None or not file_system_helpers.file_exists(temporal_path): 
        #it's the first or last frame, so use the same image to avoid pink pixels from missing image
        temporal_path = current_frame_filepath

    img = bpy.data.images.load(temporal_path,check_existing=False)
    img['temporal_type'] = node_type
    img['temporal_parent'] = name_of_node_that_will_be_stabilised
    img['render_engine'] = render_engine
    if vector_node:        
        img.use_half_precision = False
        
    else:        
        if bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].type == 'R_LAYERS':
            if render_layer_cache_bit_depth == '32':
                img.use_half_precision = False
        else:
            if standard_cache_bit_depth == '32':
                img.use_half_precision = False
    
    if vector_node:        
        img['temporal_vector'] = True
    
    new_node.image = img
    new_node.location = bpy.data.scenes[scene_name].node_tree.nodes[name_of_node_that_will_be_stabilised].location
    new_node.hide = True

    

    return new_node.name



def turn_off_displace_if_temporal_nodes_have_same_exr_as_current_node(scene_name,name_of_node_being_stabilised):
    
    def set_the_temporal_image_to_the_current_frame(vector_node):
        frame_direction = bpy.data.scenes[scene_name].node_tree.nodes[vector_node]['temporal_frame']        
        img_node = [n for n in temporal_nodes_for_this_node if bpy.data.scenes[scene_name].node_tree.nodes[n]['temporal_type'] == 'IMAGE'
                and bpy.data.scenes[scene_name].node_tree.nodes[n]['temporal_frame'] == frame_direction ][0]
        img = bpy.data.scenes[scene_name].node_tree.nodes[img_node].image.name
        img_path = bpy.data.images[img].filepath
        
        bpy.data.images[img].filepath = bpy.data.scenes[scene_name].node_tree.nodes[name_of_node_being_stabilised].image.filepath
        #print('image changed to ',bpy.data.images[img].filepath)
    
    
    temporal_nodes_for_this_node = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
                                    if 'temporal_parent' in n 
                                    and n['temporal_parent'] == name_of_node_being_stabilised
                                    
                                    ]
    
    for n in temporal_nodes_for_this_node:        
        if bpy.data.scenes[scene_name].node_tree.nodes[n].image.filepath.endswith('blank.exr'):
            if bpy.data.scenes[scene_name].node_tree.nodes[n]['temporal_type'] == 'VECTOR':
                #change the temporal img to current frame so median has no adverse effect
                set_the_temporal_image_to_the_current_frame(n)




    
def add_median_to_each_output(scene_name,name_of_node_to_stabilize,render_engine = 'cycles'):
    
    invalid_sockets = eval(f'consts.invalid_temporal_socket_{render_engine}')
    sockets_that_arent_only_connected_to_file_output_nodes = []
    save_file_outputs = bpy.data.scenes[scene_name].execute_file_output_nodes_during_publish
    if not save_file_outputs:
        sockets_that_arent_only_connected_to_file_output_nodes = [s.identifier for s in bpy.data.scenes[scene_name].node_tree.nodes[name_of_node_to_stabilize].outputs
                                if [l for l in s.links if l.to_node.type != 'OUTPUT_FILE']]
    
    
    
    valid_sockets = [s for s in bpy.data.scenes[scene_name].node_tree.nodes[name_of_node_to_stabilize].outputs 
                    if s.enabled 
                    and len(s.links) > 0 
                    and s.name[s.name.find('_')+1:] not in invalid_sockets
                    and ((save_file_outputs) or (not save_file_outputs and s.identifier in sockets_that_arent_only_connected_to_file_output_nodes))]

    #print('valid sockets')
    # for s in valid_sockets:
        
    #     print(s.name[s.name.find('_')+1:])
    
    if valid_sockets:
        for index,s in enumerate(valid_sockets):
            new_median_node = bpy.data.scenes[scene_name].node_tree.nodes.new("CompositorNodeGroup")
            socket_id = cache_operation_helpers.get_socket_id_from_socket(s)
            median_node_name = new_median_node.name
            bpy.data.scenes[scene_name].node_tree.nodes[median_node_name].node_tree = bpy.data.node_groups['.Turbo_Median_Group']
            if global_vars.testing:
                x = bpy.data.scenes[scene_name].node_tree.nodes[name_of_node_to_stabilize].location[0]
                y = bpy.data.scenes[scene_name].node_tree.nodes[name_of_node_to_stabilize].location[1]
                bpy.data.scenes[scene_name].node_tree.nodes[median_node_name].location = (x+50,y+(20*index))
            else:
                bpy.data.scenes[scene_name].node_tree.nodes[median_node_name].location = bpy.data.scenes[scene_name].node_tree.nodes[name_of_node_to_stabilize].location
                bpy.data.scenes[scene_name].node_tree.nodes[median_node_name].hide = True
            bpy.data.scenes[scene_name].node_tree.nodes[median_node_name]['parent_node'] = name_of_node_to_stabilize
            bpy.data.scenes[scene_name].node_tree.nodes[median_node_name]['parent_socket_index'] = socket_id
            bpy.data.scenes[scene_name].node_tree.nodes[median_node_name]['temporal_median_node'] = True
            bpy.data.scenes[scene_name].node_tree.nodes[median_node_name]['render_engine'] = render_engine
            bpy.data.scenes[scene_name].node_tree.nodes[median_node_name].select = False

            bpy.data.scenes[scene_name].node_tree.nodes[median_node_name].inputs['Prev Disp Scale'].default_value = -1
            bpy.data.scenes[scene_name].node_tree.nodes[median_node_name].inputs['Next Disp Scale'].default_value = 1


            global_vars.temporal_nodes_to_delete.add(median_node_name)

            for link in s.links:
                
                bpy.data.scenes[scene_name].node_tree.links.new(bpy.data.scenes[scene_name].node_tree.nodes[median_node_name].outputs['Median'],link.to_socket)
                
                bpy.data.scenes[scene_name].node_tree.links.new(
                                bpy.data.scenes[scene_name].node_tree.nodes[name_of_node_to_stabilize].outputs[socket_id],
                                bpy.data.scenes[scene_name].node_tree.nodes[median_node_name].inputs['Current Frame'])

                global_vars.links_before_temporal.add((name_of_node_to_stabilize, socket_id, link.to_node.name, cache_operation_helpers.get_socket_id_from_socket(link.to_socket)))
        
        return True
    return False


def swap_channels_for_current_render_engine(scene_name,from_node_name,from_node_socket_id,render_engine,vec_type,location):

    try:
        seperate_vector_node = bpy.data.scenes[scene_name].node_tree.nodes.new("CompositorNodeSeparateColor")    
        combine_image_node = bpy.data.scenes[scene_name].node_tree.nodes.new("CompositorNodeCombineColor")
        combine_image_node.label = 'Stabilizing'
        red = 'Red'
        green = 'Green'
        blue = 'Blue'
        alpha = 'Alpha'
        channel_dictionary = consts.vector_format.get(render_engine)
    except:
        seperate_vector_node = bpy.data.scenes[scene_name].node_tree.nodes.new("CompositorNodeSepRGBA")    
        combine_image_node = bpy.data.scenes[scene_name].node_tree.nodes.new("CompositorNodeCombRGBA")
        combine_image_node.label = 'Stabilizing'
        red = 'R'
        green = 'G'
        blue = 'B'
        alpha = 'A'
        channel_dictionary = consts.vector_format.get(f'{render_engine}_old')

    seperate_name = seperate_vector_node.name
    seperate_vector_node.location = location
    seperate_vector_node.hide = True

    combine_name = combine_image_node.name    
    combine_image_node.location = location
    combine_image_node.hide = True
    

    
    global_vars.temporal_nodes_to_delete.add(seperate_name)
    global_vars.temporal_nodes_to_delete.add(combine_name)
    

     #connect from node to seperate input
    bpy.data.scenes[scene_name].node_tree.links.new(
        bpy.data.scenes[scene_name].node_tree.nodes[from_node_name].outputs[from_node_socket_id],
        bpy.data.scenes[scene_name].node_tree.nodes[seperate_name].inputs['Image']
    )

    
    # #connect combine to median nodes vec input
    # bpy.data.scenes[scene_name].node_tree.links.new(
    #     bpy.data.scenes[scene_name].node_tree.nodes[combine_name].outputs['Image'],
    #     bpy.data.scenes[scene_name].node_tree.nodes[to_node_name].inputs[to_node_socket_name]
    # )

    
     
    
    if vec_type == 'PREV':
        #if the vector is from the previous frame, then we need to move it's pixels to the next frame
        #red
        bpy.data.scenes[scene_name].node_tree.links.new(
            bpy.data.scenes[scene_name].node_tree.nodes[seperate_name].outputs[channel_dictionary['x_current_to_next']],
            bpy.data.scenes[scene_name].node_tree.nodes[combine_name].inputs[red]
        )

        #green
        bpy.data.scenes[scene_name].node_tree.links.new(
            bpy.data.scenes[scene_name].node_tree.nodes[seperate_name].outputs[channel_dictionary['y_current_to_next']],
            bpy.data.scenes[scene_name].node_tree.nodes[combine_name].inputs[green]
        )

    elif vec_type in ('NEXT','CURRENT'):
        #if it's the next frame, then we need to move its pixels backwards to the current frame

        #red
        bpy.data.scenes[scene_name].node_tree.links.new(
            bpy.data.scenes[scene_name].node_tree.nodes[seperate_name].outputs[channel_dictionary['x_current_to_prev']],
            bpy.data.scenes[scene_name].node_tree.nodes[combine_name].inputs[red]
        )

        #green
        bpy.data.scenes[scene_name].node_tree.links.new(
            bpy.data.scenes[scene_name].node_tree.nodes[seperate_name].outputs[channel_dictionary['y_current_to_prev']],
            bpy.data.scenes[scene_name].node_tree.nodes[combine_name].inputs[green]
        )
    
    return combine_name


def add_scale_node_and_link_to_output_of_node_provided(scene_name,vector_node_name,offset,vector_socket_name):
    scale_node = bpy.data.scenes[scene_name].node_tree.nodes.new('CompositorNodeScale')
    scale_name = scale_node.name
    bpy.data.scenes[scene_name].node_tree.nodes[scale_name].space = 'RELATIVE'
    bpy.data.scenes[scene_name].node_tree.nodes[scale_name].inputs[1].default_value = offset
    bpy.data.scenes[scene_name].node_tree.nodes[scale_name].inputs[2].default_value = offset
    bpy.data.scenes[scene_name].node_tree.nodes[scale_name].hide = True
    bpy.data.scenes[scene_name].node_tree.nodes[scale_name].location = bpy.data.scenes[scene_name].node_tree.nodes[vector_node_name].location

    
    bpy.data.scenes[scene_name].node_tree.links.new(
                        bpy.data.scenes[scene_name].node_tree.nodes[vector_node_name].outputs[vector_socket_name],
                        bpy.data.scenes[scene_name].node_tree.nodes[scale_name].inputs['Image'])
    
    global_vars.temporal_nodes_to_delete.add(scale_name)

    return scale_name


def wire_up_median_inputs(scene_name,name_of_node_being_stabilised):
    prev_name = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
                    if 'temporal_parent' in n
                    and n['temporal_parent'] == name_of_node_being_stabilised
                    and n['temporal_type'] == 'IMAGE'
                    and n['temporal_frame'] == 'PREV'
                ][0]
    next_name = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
                    if 'temporal_parent' in n
                    and n['temporal_parent'] == name_of_node_being_stabilised
                    and n['temporal_type'] == 'IMAGE'
                    and n['temporal_frame'] == 'NEXT'
                ][0]    
    vec_next_name = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
                    if 'temporal_parent' in n
                    and n['temporal_parent'] == name_of_node_being_stabilised
                    and n['temporal_type'] == 'VECTOR'
                    and n['temporal_frame'] == 'NEXT'
                ][0]
    vec_prev_name = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
                    if 'temporal_parent' in n
                    and n['temporal_parent'] == name_of_node_being_stabilised
                    and n['temporal_type'] == 'VECTOR'
                    and n['temporal_frame'] == 'PREV'
                ][0]


    median_nodes =  [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if 'temporal_median_node' in n and n['parent_node'] == name_of_node_being_stabilised ]
    vector_socket_name = consts.valid_vector_names.get(str(bpy.data.scenes[scene_name].node_tree.nodes[median_nodes[0]]['render_engine']).lower(),'Vector')
    render_engine = bpy.data.scenes[scene_name].node_tree.nodes[median_nodes[0]]['render_engine'].lower()

    #add a scale node to the vector output if the node being stabilised is a standard node and it's cache percentage is < 100.  The cache % is stored in the parent node. 
    scale_the_vector = False
    offset = 1
    if 'downstream_rl_cache_node_name' in bpy.data.scenes[scene_name].node_tree.nodes[name_of_node_being_stabilised]:
        #its a standard cache node
        node_being_cached = cache_operation_helpers.get_original_node_name_from_cache_node(scene_name,name_of_node_being_stabilised)
        if 'cache_resolution' in bpy.data.scenes[scene_name].node_tree.nodes[node_being_cached]:
            cache_percent = bpy.data.scenes[scene_name].node_tree.nodes[node_being_cached]['cache_resolution']
            if cache_percent < 100:
                offset = cache_percent/100
                original_vec_prev = vec_prev_name
                original_vec_next = vec_next_name
                vec_prev_name = add_scale_node_and_link_to_output_of_node_provided(scene_name,vec_prev_name,offset,vector_socket_name)
                vec_next_name = add_scale_node_and_link_to_output_of_node_provided(scene_name,vec_next_name,offset,vector_socket_name)
                scale_the_vector = True
                # print('scale added to ',original_vec_next)
                # print('scale added to ',original_vec_prev)
                # print('scale size = ',offset)
    
    if scale_the_vector:
            vector_socket_name = 'Image'
    
    vec_prev_name = swap_channels_for_current_render_engine(scene_name,vec_prev_name,vector_socket_name,render_engine,'PREV',bpy.data.scenes[scene_name].node_tree.nodes[name_of_node_being_stabilised].location)
    vec_next_name = swap_channels_for_current_render_engine(scene_name,vec_next_name,vector_socket_name,render_engine,'NEXT',bpy.data.scenes[scene_name].node_tree.nodes[name_of_node_being_stabilised].location)

    vector_socket_name = 'Image' #because it's always going to be a combine node at this point

    for mn in median_nodes:
        bpy.data.scenes[scene_name].node_tree.nodes[mn]['offset'] = offset
        bpy.data.scenes[scene_name].node_tree.nodes[mn].inputs['Prev Disp Scale'].default_value = consts.displace_x_scale.get(render_engine,-1) * offset
        bpy.data.scenes[scene_name].node_tree.nodes[mn].inputs['Next Disp Scale'].default_value = consts.displace_y_scale.get(render_engine,1) * offset

        parent_socket_id = bpy.data.scenes[scene_name].node_tree.nodes[mn]['parent_socket_index'] #because the prev and next are duplicates of the original, the socket id on the duplicate will be the same as the socket id the median node is connected to on the node being stabilised
        bpy.data.scenes[scene_name].node_tree.links.new(
                            bpy.data.scenes[scene_name].node_tree.nodes[prev_name].outputs[parent_socket_id],
                            bpy.data.scenes[scene_name].node_tree.nodes[mn].inputs['Previous Frame'])
        bpy.data.scenes[scene_name].node_tree.links.new(
                            bpy.data.scenes[scene_name].node_tree.nodes[next_name].outputs[parent_socket_id],
                            bpy.data.scenes[scene_name].node_tree.nodes[mn].inputs['Next Frame'])

        #vector

        
        bpy.data.scenes[scene_name].node_tree.links.new(
                            bpy.data.scenes[scene_name].node_tree.nodes[vec_prev_name].outputs[vector_socket_name],
                            bpy.data.scenes[scene_name].node_tree.nodes[mn].inputs['Previous Frame Vector'])
        bpy.data.scenes[scene_name].node_tree.links.new(
                            bpy.data.scenes[scene_name].node_tree.nodes[vec_next_name].outputs[vector_socket_name],
                            bpy.data.scenes[scene_name].node_tree.nodes[mn].inputs['Next Frame Vector'])

        #arrange the rgba to the correct set up for the render engine
        
        

def get_render_engine_from_cache_node(scene_name,cache_node_name):
    '''returns the name of the render engine in lower case'''
    if 'render_engine' in bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name]:
        render_engine = bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name]['render_engine']
    else:
        parent = cache_operation_helpers.get_original_node_name_from_cache_node(scene_name,cache_node_name)
        render_engine = bpy.data.scenes[scene_name].node_tree.nodes[parent].scene.render.engine

    return render_engine.lower()


def set_up_for_temporal(scene_name):
    global_vars.links_before_temporal = set()
    global_vars.temporal_nodes_to_delete = set()
    cache_nodes_to_temporally_stabilize, user_nodes_to_stabilize = get_the_node_names_that_need_stabilising(scene_name)
    all_nodes_to_stabilize = cache_nodes_to_temporally_stabilize + user_nodes_to_stabilize
    if all_nodes_to_stabilize:
        

        for cn in cache_nodes_to_temporally_stabilize:
            bpy.data.scenes[scene_name].node_tree.nodes[cn]['cache_being_temporalised'] = True
        
        for cn in user_nodes_to_stabilize:
            bpy.data.scenes[scene_name].node_tree.nodes[cn]['user_being_temporalised'] = True

        
        if bpy.data.scenes[scene_name].Temporal_RGBA_Seperately:
            if '.Turbo_Min' not in bpy.data.node_groups:
                create_min_max_with_seperate_rgba(scene_name)
            if '.Turbo_Max' not in bpy.data.node_groups:
                create_min_max_with_seperate_rgba(scene_name,min_node=False)
            
        else:
            if '.Turbo_Min_Max' not in bpy.data.node_groups:
                create_min_max(scene_name)


        if '.Turbo_Median_Group' not in bpy.data.node_groups:
            create_median_group(scene_name)
        

        
        
        for cn in cache_nodes_to_temporally_stabilize:
            #print(cn)
            
            #render_engine = 'cycles' #need to replace this with logic that gets the engine from the render layer node's scene.render_engine.  could cause problem if they change the scene after rendering.
            
                
            

            render_engine = get_render_engine_from_cache_node(scene_name,cn)
            add_median_to_each_output(scene_name,cn,render_engine)

            #add render_layer_cache_duplicates
            global_vars.temporal_nodes_to_delete.add(add_prev_next_frame_image_files_turbo_cache(scene_name,cn,render_engine,'PREV'))
            global_vars.temporal_nodes_to_delete.add(add_prev_next_frame_image_files_turbo_cache(scene_name,cn,render_engine,'NEXT'))

            #add  vector nodes        
            global_vars.temporal_nodes_to_delete.add(add_prev_next_frame_image_files_turbo_cache(scene_name,cn,render_engine,'PREV', vector_node=True))
            global_vars.temporal_nodes_to_delete.add(add_prev_next_frame_image_files_turbo_cache(scene_name,cn,render_engine,'NEXT', vector_node=True))

            wire_up_median_inputs(scene_name,cn)

        #TO DO

        # for un in user_image_sequences_to_stabilize:
            
        #     if cn in user_image_sequences_to_stabilize: #get the render engine for user nodes
        #         for engine in consts.compatible_temporal_render_engines:
        #             img_path = bpy.data.scenes[scene_name].node_tree.nodes[cn].image.filepath
        #             image_file_name = file_system_helpers.get_file_name_from_path(img_path)
        #             if engine in image_file_name:
        #                 render_engine = engine
        #         if render_engine is None:
        #             report_custom_error.store_error(scene_name,f'Can\'t temporal stabilize node \'{cn}\' because its file name doesn\'t contain the render engine name used.  Add the engines name to the filename and retry')
        #             return False
                
        #     render_engine = render_engine.lower()
        #     add_median_to_each_output(scene_name,cn,render_engine)

        #     #add user image sequence duplicates these will be set to offset instead.
        #     global_vars.temporal_nodes_to_delete.add(add_prev_next_frame_image_files_turbo_cache(scene_name,cn,'PREV'))
        #     global_vars.temporal_nodes_to_delete.add(add_prev_next_frame_image_files_turbo_cache(scene_name,cn,'NEXT'))



        #     wire_up_median_inputs(scene_name,cn)
        
        
            
        
    return True



        
def remove_temporal_attributes_from_pre_existing_nodes(scene_name):
    nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if 'cache_being_temporalised' in n or 'user_being_temporalised' in n]
    for n in nodes:
        if 'cache_being_temporalised' in bpy.data.scenes[scene_name].node_tree.nodes[n]:
            del  bpy.data.scenes[scene_name].node_tree.nodes[n]['cache_being_temporalised']
        if 'user_being_temporalised' in bpy.data.scenes[scene_name].node_tree.nodes[n]:
            del bpy.data.scenes[scene_name].node_tree.nodes[n]['user_being_temporalised']



def revert_tree_to_pre_temporal_setup(scene_name):
    '''removes temporal nodes and wires back up the node being stabilised to it's pre-temporal state'''

    remove_temporal_attributes_from_pre_existing_nodes(scene_name)
    #delete all temporal nodes
    if global_vars.temporal_nodes_to_delete is not None:
        for n in global_vars.temporal_nodes_to_delete:
            bpy.data.scenes[scene_name].node_tree.nodes.remove(bpy.data.scenes[scene_name].node_tree.nodes[n])

    
    if global_vars.links_before_temporal:
        for l in global_vars.links_before_temporal:
            bpy.data.scenes[scene_name].node_tree.links.new(
                            bpy.data.scenes[scene_name].node_tree.nodes[l[0]].outputs[l[1]],
                            bpy.data.scenes[scene_name].node_tree.nodes[l[2]].inputs[l[3]])

    temporal_image_blocks = [i.name for i in bpy.data.images if 'temporal_type' in i]
    for i in temporal_image_blocks:
        bpy.data.images.remove(bpy.data.images[i])

    if '.Turbo_Median_Group' in bpy.data.node_groups:
        bpy.data.node_groups.remove(bpy.data.node_groups['.Turbo_Median_Group'])
    if '.Turbo_Min_Max' in bpy.data.node_groups:
        bpy.data.node_groups.remove(bpy.data.node_groups['.Turbo_Min_Max'])
    if '.Turbo_Min' in bpy.data.node_groups:
        bpy.data.node_groups.remove(bpy.data.node_groups['.Turbo_Min'])
    if '.Turbo_Max' in bpy.data.node_groups:
        bpy.data.node_groups.remove(bpy.data.node_groups['.Turbo_Max'])
    
    global_vars.links_before_temporal = None
    global_vars.temporal_nodes_to_delete = None
    



def post_render_checks(scene_name):
    pass
