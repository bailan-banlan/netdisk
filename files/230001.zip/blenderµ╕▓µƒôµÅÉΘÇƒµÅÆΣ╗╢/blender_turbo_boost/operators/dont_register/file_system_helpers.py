
from ..dont_register import checks
from ..dont_register import cache_operation_helpers,report_custom_error
import bpy
from hashlib import sha256,md5
from...variables import consts,global_vars
from os import path,listdir,rename,remove
from shutil import move
import glob
import pathlib
import os

def get_addon_directory():
    top_level = os.path.dirname(__file__)#.split('.')[0]
    #print(top_level)
    #folder_contents = os.listdir(os.path.join(str(pathlib.Path(__file__).parent.parent.parent.absolute()) , directory))

def get_absolute_path(inpath):
    abspath = get_safe_path(bpy.path.abspath(inpath))

    return abspath

def get_safe_path(inpath):
    """returns the path with the path seperators changed to match the OS"""
    safepath = bpy.path.native_pathsep(inpath)
    return safepath


def blend_file_name():
    try:
        #filename = get_file_name_from_path(bpy.data.filepath)
        filename = bpy.path.display_name_from_filepath(bpy.data.filepath)
        #print(filename)
        return filename
    except:
        pass

def get_file_name_from_path(inpath):
    filename = bpy.path.basename(get_safe_path(inpath))
    return filename

def get_directory_from_path(inpath):
    return path.dirname(inpath)

def get_file_modified_time(inpath):
    return path.getmtime(inpath)

def get_file_size(inpath):
    return path.getsize(inpath)


# main functions
#--------------------------------------------------------------------------------------------------

def get_path_without_cache_type_prefix(inpath):
    directory = get_directory_from_path(inpath)
    fname = get_file_name_from_path(inpath)
    fname = fname[fname.find('_') + 1:]
    return fname

def get_path_with_second_hash_replaced_by_wildcard(inpath,only_this_frame = True):
    frame_and_ext = inpath[inpath.rfind('_'):]
    without_f_and_ext = get_path_without_framenum_and_extension(inpath)
    without_sceond_hash = without_f_and_ext[:without_f_and_ext[:-1].rfind('_')]
    if only_this_frame:
        with_wild = without_sceond_hash + '*' + frame_and_ext
    else:
        with_wild = without_sceond_hash + '*' + '.exr'
    return with_wild


def get_path_without_framenum_and_extension(filepath,end_char_to_find = '_'):
    """return  hash_without_prefix_frame_and_extension, full_without_frame_and_extension"""
    if not filepath:        
        return None

    
    index_of_end_marker = filepath.rfind(end_char_to_find)
    if index_of_end_marker != -1:
        full_without_frame_and_extension = filepath[:index_of_end_marker + 1]
        
        return full_without_frame_and_extension

def get_frame_from_path(filepath):
    frame = filepath[filepath.rfind('_') + 1:filepath.rfind('.')]
    try:
        frame = int(frame)
    except:
        return
    return frame



def get_cache_file_path_from_original_node_name(scene_name,original_node_name,turbo = False, wildcard_prefix = False, do_hash = True,wildcard_hash = False,is_for_temporal_vector_only = False):
    """returns the absolute path including file name (excluding the frame number and externsion), 
    it works for all node types (render layer, image node, normal original node)
    """
    
    #blend_file = blend_file_name()
    
    #you could say if it's a render layer node then get the directory from the scene that render layer node represents
    #if its not a render layer node, then get the directory from the current scene.
    
    # directory = bpy.context.preferences.addons[__name__.split('.')[0]].preferences.cache_folder 
    # directory = get_absolute_path(directory)

    if bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].type == 'R_LAYERS':
        directory = bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].scene.Turbo_Cache_Folder
    else:
        directory = bpy.data.scenes[scene_name].Turbo_Cache_Folder


    directory = get_absolute_path(directory)
    #it's a non image node
    if bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].type == 'R_LAYERS':
        directory = bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].scene.Turbo_Cache_Folder
        if is_for_temporal_vector_only:
            folder = 'Vector'
        else:
            folder = 'render_layers'
        active_cam = bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].scene.camera.name        
        fname = md5(f'{active_cam}{bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].scene.name}{bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].layer}'.encode('ascii')).hexdigest()
        
        #at the moment just using a temp variable to determine this, but once added to each scene's properties panel, will use original_node.scene.name['turbo']
        if wildcard_prefix:
            fname = f'*_{fname}'
        elif is_for_temporal_vector_only:
            fname = f'V_{fname}'
        else:
            if turbo == True: #if this goes wrong do 'or 'Turbo_Render' in original_node.scene and original_node.scene.Turbo_Render == True'
                fname = f'RLT_{fname}'
            else:
                fname = f'RL_{fname}'

    else:
        #it's a non render layer node
        

        folder = 'cache'
        fname = md5(f'{scene_name}{original_node_name}'.encode('ascii')).hexdigest()
        if do_hash and not wildcard_hash:
            downstream_hash = cache_operation_helpers.get_hash_of_the_all_downstream_attributes_combined(scene_name,bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].name)
            fname = f'{fname}_{downstream_hash}'
        if wildcard_hash:
            fname = f'{fname}*'
        fname = f'CH_{fname}'
    
    #hash the file name
    full_path = f"{directory}{folder}/{fname}_"
    full_path = get_safe_path(full_path)
    return full_path



def create_exr_friendly_socket_name_with_prefix(scene_name,index,socket_identifier,add_prefix = True):
    """
    returns exr friendly name for the currently wired socket, with prefix
    """
    if add_prefix:
        if index <= 61:
            prefix = f'{consts.alphabet[index]}_'
        else:
            prefix = f'z{index}_'
    else:
        prefix = ''

    socket_name_safe = socket_identifier[0:31 - (len(prefix))]
    
    return f'{prefix}{socket_name_safe}'


def file_exists(file_path):
    
    if file_path is not None and path.exists(file_path):
        return True
    else:
        return False

    
def delete_file(filepath,scene_name,report_errors = True):
    
    image_path = get_absolute_path(filepath)
    if path.exists(image_path):
        scene = bpy.data.scenes[scene_name]
        
        try:
            remove(image_path)
            return True
        except:    
            if report_errors:           
                report_custom_error.store_error(scene_name,f"There was a problem deleting {image_path}, delete manually to free hard drive space.")
                
            return False
    

def rename_file(old_filepath,new_filepath):
    if file_exists(new_filepath):
        remove(new_filepath)
    rename(old_filepath,new_filepath)
    


def get_exr(scene_name,node_name,frame = None,wildcard_hash = False,for_temporal_vector = False,get_newest_rl_cache_if_not_found = True):
    """for rl cache nodes it'll get the newest current frame exr or if there isn't one for the current frame, gets the newest for any frame,
    for render layer cache it'll use a wildcard in place of the rl_ or rlt
    for standard cache it'll get the exr for the current frame only"""
    
    
    if frame is None:
        frame = bpy.data.scenes[scene_name].frame_current
    if checks.is_a_cache_node(node_name,scene_name):        
        original_node_name = cache_operation_helpers.get_original_node_name_from_cache_node(scene_name,node_name)        
    else:
        original_node_name = node_name

    
    
    if bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].type == 'R_LAYERS':
        path_of_exr = get_cache_file_path_from_original_node_name(scene_name,original_node_name,wildcard_prefix=True, is_for_temporal_vector_only = for_temporal_vector)
        #try with frame first
        path_of_exr_with_frame = f'{path_of_exr}{str(frame).zfill(4)}.exr'
        list_of_files = glob.glob(path_of_exr_with_frame)
        if not list_of_files and get_newest_rl_cache_if_not_found:
            #get any frame instead
            path_of_exr_with_wildcard = f'{path_of_exr}*'
            list_of_files = glob.glob(path_of_exr_with_wildcard)
    else:
        path_of_exr = get_cache_file_path_from_original_node_name(scene_name,original_node_name, wildcard_hash = wildcard_hash, is_for_temporal_vector_only = for_temporal_vector)
        path_of_exr_with_frame = f'{path_of_exr}{str(frame).zfill(4)}.exr'
        list_of_files = glob.glob(path_of_exr_with_frame)

    if list_of_files:
        return max(list_of_files, key= path.getmtime)


def get_files(inpath):
    return glob.glob(inpath)

    


