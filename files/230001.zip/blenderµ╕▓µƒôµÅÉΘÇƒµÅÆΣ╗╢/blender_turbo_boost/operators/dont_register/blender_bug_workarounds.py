import bpy

def fix_all_bugs():
    fix_custom_aov_enabled_property_not_updating()

def fix_custom_aov_enabled_property_not_updating():
    view_layer = bpy.context.view_layer.name
    scene_name = bpy.context.scene.name
    original = bpy.data.scenes[scene_name].view_layers[view_layer].use_pass_combined

    if original:
        bpy.data.scenes[scene_name].view_layers[view_layer].use_pass_combined = False
    else:
        bpy.data.scenes[scene_name].view_layers[view_layer].use_pass_combined = True

    bpy.data.scenes[scene_name].view_layers[view_layer].use_pass_combined = original