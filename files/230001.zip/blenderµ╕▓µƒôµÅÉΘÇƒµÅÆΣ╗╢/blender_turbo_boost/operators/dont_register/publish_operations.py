import bpy
from . import node_helpers,cache_operation_helpers,temporal,checks,file_system_helpers
from...variables import global_vars

def move_links_from_duplicates_to_single(scene_name):
    unmuted_cache_nodes = node_helpers.get_all_cache_nodes(scene_name)
    images_done = []
    
    for cn in unmuted_cache_nodes:        
        if bpy.data.scenes[scene_name].node_tree.nodes[cn].image and bpy.data.scenes[scene_name].node_tree.nodes[cn].image.name not in images_done:
            duplicates = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
                            if n.name != cn
                            and n.name in unmuted_cache_nodes 
                            and n.image 
                            and n.image.name == bpy.data.scenes[scene_name].node_tree.nodes[cn].image.name ]
            for d in duplicates:
                for index, socket in enumerate(bpy.data.scenes[scene_name].node_tree.nodes[d].outputs):
                    for link in socket.links:
                        bpy.data.scenes[scene_name].node_tree.links.new(bpy.data.scenes[scene_name].node_tree.nodes[cn].outputs[index],link.to_socket)
                        global_vars.links_before_publish.add((d, index, link.to_node.name, cache_operation_helpers.get_socket_id_from_socket(link.to_socket)))
                        bpy.data.scenes[scene_name].node_tree.nodes[d].mute = True
                        if global_vars.muted_before_render is None:
                            global_vars.muted_before_render = set()
                        global_vars.muted_before_render.add(d)
            
            images_done.append(bpy.data.scenes[scene_name].node_tree.nodes[cn].image.name)


def moves_links_back_after_publish(scene_name):
    '''call this before rewiring the standard cache nodes'''
    if global_vars.links_before_publish is not None:
        for l in global_vars.links_before_publish:
            bpy.data.scenes[scene_name].node_tree.links.new(bpy.data.scenes[scene_name].node_tree.nodes[l[0]].outputs[l[1]],bpy.data.scenes[scene_name].node_tree.nodes[l[2]].inputs[l[3]])


def number_of_render_layer_cache_nodes_downstream_that_have_a_vector_pass_available(scene_name,standard_cache_node_name):
    '''returns number of render layer cache node downstream.  also adds the vector path to the "vector_path" node attribute'''
    downstream,end_nodes,cache_nodes = node_helpers.get_downsttream_nodes_including_downstream_of_cache_nodes(standard_cache_node_name,scene_name)
    downstream_render_layer_cache_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
                                                if n.name in downstream 
                                                and checks.is_a_render_layer_cache_node(n.name,scene_name)
                                                and checks.there_are_vector_passes_available(scene_name,n.name)]
    unique_downstream_cache_images = set([n.image.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.name in downstream_render_layer_cache_nodes])
    if len(unique_downstream_cache_images) == 1:
        #store the vector exr path for the solitary render layer cache node in the standard cache node

        original_node_name = cache_operation_helpers.get_original_node_name_from_cache_node(scene_name, downstream_render_layer_cache_nodes[0])
        v_path = file_system_helpers.get_exr(scene_name,original_node_name,for_temporal_vector=True)
        bpy.data.scenes[scene_name].node_tree.nodes[standard_cache_node_name]['vector_path'] = v_path
        bpy.data.scenes[scene_name].node_tree.nodes[standard_cache_node_name]['downstream_rl_cache_node_name'] = original_node_name
        bpy.data.scenes[scene_name].node_tree.nodes[standard_cache_node_name]['render_engine'] = bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].scene.render.engine
    return len(unique_downstream_cache_images)
    

def remove_attributes_from_standard_cache_nodes(scene_name):
    nodes_with_vector_path_attribute = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if 'vector_path' in n]
    for n in nodes_with_vector_path_attribute:
        del bpy.data.scenes[scene_name].node_tree.nodes[n]['vector_path']
        del bpy.data.scenes[scene_name].node_tree.nodes[n]['downstream_rl_cache_node_name'] 
        del bpy.data.scenes[scene_name].node_tree.nodes[n]['render_engine']




def mute_what_can_be_muted_before_publish(scene_name,keep_file_output_nodes_unmuted = False):
    all_comp_node_names = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'COMPOSITE']
    if len(all_comp_node_names)>1:
        selected_comp_node_names = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.name in all_comp_node_names and bpy.data.scenes[scene_name].node_tree.nodes[n].select == True]
        comp_node = selected_comp_node_names[0]
    else:
        comp_node = all_comp_node_names[0]
    downstream,end_nodes = node_helpers.get_downsttream_nodes(comp_node,scene_name)
    nodes_not_to_mute = downstream.copy()
    nodes_not_to_mute.update(end_nodes)
    nodes_not_to_mute.add(comp_node)

    
    

    if keep_file_output_nodes_unmuted:
        unmuted_file_output_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'OUTPUT_FILE' and n.mute == False]
        # for n in unmuted_file_output_nodes:
        #     downstream,end_nodes = node_helpers.get_downsttream_nodes(n,scene_name,downstream,end_nodes)
        file_output_branches = set()
        upstream = nodes_not_to_mute.copy()
        for n in nodes_not_to_mute:
            upstream,upstream_cache_nodes = node_helpers.get_upstream_nodes(n,scene_name,upstream)
            for fn in  unmuted_file_output_nodes:
                if fn in upstream:
                    file_output_branches.update(upstream)
        nodes_not_to_mute.update(file_output_branches)
    
    #mute
    nodes_to_mute = set([n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.mute == False and n.name not in nodes_not_to_mute])
    nodes_to_mute.update(set([n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'R_LAYERS' and n.mute == False]))
    for n in nodes_to_mute:
        bpy.data.scenes[scene_name].node_tree.nodes[n].mute = True
        #print(f'{n} was muted before publish')

    global_vars.muted_before_render = nodes_to_mute
    


def set_up_pre_publish(scene_name,animation = True):
    bpy.data.scenes[scene_name].frame_current = bpy.data.scenes[scene_name].frame_start
    
    global_vars.links_before_publish = set()
    standard_cache = node_helpers.get_all_standard_cache_nodes(scene_name)
    if not bpy.data.scenes[scene_name].QuickPublish:
        for n in standard_cache:
            
            cache_operation_helpers.store_link_list_in_cache_node(n,scene_name)
            cache_operation_helpers.move_links_from_cache_node_to_original_node(n,scene_name)
    else:
        if bpy.data.scenes[scene_name].Temporal_Publish and animation:
        #also make sure we unhook standard cache that dont  have, or could have more than one vector pass
            for n in standard_cache:
                number_of_downstream_render_layer_cache_nodes = number_of_render_layer_cache_nodes_downstream_that_have_a_vector_pass_available(scene_name,n)
                if  number_of_downstream_render_layer_cache_nodes != 1:
                    cache_operation_helpers.store_link_list_in_cache_node(n,scene_name)
                    cache_operation_helpers.move_links_from_cache_node_to_original_node(n,scene_name)
    
    
    mute_what_can_be_muted_before_publish(scene_name, bpy.data.scenes[scene_name].execute_file_output_nodes_during_publish)
    move_links_from_duplicates_to_single(scene_name)

    if bpy.data.scenes[scene_name].Temporal_Publish and animation:
        try:
            temporal.set_up_for_temporal(scene_name)
                #return False            
        except Exception as e:
            print('temporal setup error',e)
            return False
    return True

        

def post_publish(scene_name,animation = True):

    temporal.revert_tree_to_pre_temporal_setup(scene_name)
    remove_attributes_from_standard_cache_nodes(scene_name)
    #global_vars.reset_all_vars()

    nodes_to_unmute = global_vars.muted_before_render
    moves_links_back_after_publish(scene_name)
    for n in nodes_to_unmute:
        bpy.data.scenes[scene_name].node_tree.nodes[n].mute = False
    standard_cache = node_helpers.get_all_standard_cache_nodes(scene_name)

    for n in standard_cache:
        if 'temp_links' in bpy.data.scenes[scene_name].node_tree.nodes[n]:
            cache_operation_helpers.move_links_to_cache_node(n,scene_name)
# else:
    #     bpy.data.scenes[scene_name].render.resolution_percentage = bpy.data.scenes[scene_name]['original render resolution']
    
    remove_attributes_from_standard_cache_nodes(scene_name)
    global_vars.muted_before_render = None
    global_vars.render_type = []
    global_vars.temporal_nodes_to_delete = None
    global_vars.links_before_publish = None