from ..dont_register import checks
from ..dont_register import file_system_helpers
from ..dont_register import cache_operation_helpers
import bpy



#get nodes
#---------------------------------------------------------------------------------------------------
def get_downsttream_nodes(start_node_name,scene_name, downstream_nodes= None,end_nodes = None):
    """returns all downstream nodes as a set, and all nodes at the beginning of a tree as a set

        return downstream_nodes,end_nodes
    """
    
     #= scene.node_tree.nodes
    
    if downstream_nodes is None:
        downstream_nodes = set()

    if end_nodes is None:
        end_nodes = set()
        
    #check at least one of the in sockets has a link
    #start_node_object = bpy.data.scenes[scene_name].node_tree.nodes[start_node_name]
    #if start_node_name not in downstream_nodes and start_node_name not in end_nodes:#already checked
    if checks.node_has_no_linked_inputs(start_node_name,scene_name):
        end_nodes.add(start_node_name)
    else:
        for i in bpy.data.scenes[scene_name].node_tree.nodes[start_node_name].inputs:
            
            for link in i.links:
                downstream_nodes.add(link.from_node.name)
                get_downsttream_nodes(link.from_node.name,scene_name,downstream_nodes,end_nodes)
        
    return downstream_nodes,end_nodes

# def get_downstream_and_upstream_of_downstream(start_node_name,scene_name):
#     downstream_nodes,downstream_end_nodes = get_downsttream_nodes(start_node_name,scene_name)
#     upstream_nodes = set()
#     for n in downstream_nodes:
#         upstream,cache_nodes_upstream = get_upstream_nodes(n,scene_name)
#         upstream_nodes.update(get_upstream_nodes())



def get_downsttream_nodes_including_downstream_of_cache_nodes(start_node_name,scene_name, downstream_nodes= None,end_nodes = None,cache_nodes = None):
    """returns all downstream nodes as a set, and all nodes at the beginning of a tree as a set

        return downstream_nodes,end_nodes
    """
    
    
    
    if downstream_nodes is None:
        downstream_nodes = set()

    if end_nodes is None:
        end_nodes = set()
    
    if cache_nodes is None:
        cache_nodes = set()
        
    #check at least one of the in sockets has a link
    if start_node_name in bpy.data.scenes[scene_name].node_tree.nodes:

        
        if checks.node_has_no_linked_inputs(start_node_name,scene_name):
            end_nodes.add(start_node_name)
            if checks.is_a_cache_node(start_node_name,scene_name):
                cache_nodes.add(start_node_name)
                original_node_name = cache_operation_helpers.get_original_node_name_from_cache_node(scene_name,start_node_name)
                if original_node_name is not None and original_node_name not in downstream_nodes:
                    downstream_nodes.add(original_node_name)
                    get_downsttream_nodes_including_downstream_of_cache_nodes(original_node_name,scene_name,downstream_nodes,end_nodes,cache_nodes)
        else:
            for i in bpy.data.scenes[scene_name].node_tree.nodes[start_node_name].inputs:
                
                for link in i.links:
                    downstream_nodes.add(link.from_node.name)
                    get_downsttream_nodes_including_downstream_of_cache_nodes(link.from_node.name,scene_name,downstream_nodes,end_nodes,cache_nodes)
        
    return downstream_nodes,end_nodes,cache_nodes


def get_upstream_nodes(start_node_name,scene_name, upstream_nodes= None,upstream_cache_nodes = None):
    
    
    if upstream_nodes is None:
        upstream_nodes = set()    
    
    if upstream_cache_nodes is None:
        upstream_cache_nodes = set()
        
    #check at least one of the in sockets has a link
    #start_node_object = bpy.data.scenes[scene_name].node_tree.nodes[start_node_name]
    if not checks.node_has_linked_outputs(start_node_name,scene_name):
        #check if there are any cache nodes for it
        cache_nodes = cache_operation_helpers.get_all_cache_nodes_for_this_node(scene_name,start_node_name)
        for node in cache_nodes:
            if node not in upstream_nodes:
                upstream_cache_nodes.add(node)
                upstream_nodes.add(node)
                get_upstream_nodes(node,scene_name,upstream_nodes,upstream_cache_nodes)
            
    else:
        for i in bpy.data.scenes[scene_name].node_tree.nodes[start_node_name].outputs:
            
            for link in i.links:
                if link.to_node.name not in upstream_nodes:
                    upstream_nodes.add(link.to_node.name)
                    get_upstream_nodes(link.to_node.name,scene_name,upstream_nodes,upstream_cache_nodes)
        
    return upstream_nodes,upstream_cache_nodes






def get_upstream_and_downtream_from_selection_including_downstream_of_cache_nodes_original_nodes(node_names, scene_name):
    
    #safety measure incase of duplicates
    node_names = set(node_names)   
    
    tree = set()
    
    #get all downstream
    downstream = set()
    end_nodes = set()
    cache_nodes = set()
      
    for n in node_names:
        downstream,end_nodes,cache_nodes = get_downsttream_nodes_including_downstream_of_cache_nodes(n,scene_name,downstream,end_nodes,cache_nodes)        
    
    tree.update(downstream)

    upstream = set()
    upstream_cache_nodes = set()
    for n in node_names:
        upstream, upstream_cache = get_upstream_nodes(n,scene_name,upstream,upstream_cache_nodes)
        if checks.is_a_non_render_layer_cache_node(n,scene_name):
            upstream_cache.add(n)
    
    tree.update(upstream)
    
    #check all  upstream nodes dont have inputs that dont lead to the selected node, and if they do, add all downstream nodes of that linked socket to the tree, otherwise mix nodes etc will have info missing
    downstream2=set()
    ends = set()
    cache = set()
    for n in tree:
        if n not in node_names:
            downstream2,end,cache = get_downsttream_nodes_including_downstream_of_cache_nodes(n,scene_name,downstream2,ends,cache)

    tree.update(downstream2)
        
    return tree,upstream_cache


def get_upstream_and_downtream_from_selection(node_names, scene_name):
    
    #safety measure incase of duplicates
    node_names = set(node_names)   
    
    tree = set()
    
    #get all downstream
    downstream = set()
    end_nodes = set()
    cache_nodes = set()
    upstream_cache = set()
      
    for n in node_names:
        if checks.is_a_non_render_layer_cache_node(n,scene_name):
            original = cache_operation_helpers.get_original_node_name_from_cache_node(scene_name,n)
            downstream,end_nodes = get_downsttream_nodes(original,scene_name,downstream,end_nodes)  
            downstream.add(original)
        else:
            downstream,end_nodes = get_downsttream_nodes(n,scene_name,downstream,end_nodes)        
    
    tree.update(downstream)

    upstream = set()
    upstream_cache_nodes = set()
    for n in node_names:
        upstream, upstream_cache = get_upstream_nodes(n,scene_name,upstream,upstream_cache_nodes)
        if checks.is_a_non_render_layer_cache_node(n,scene_name):
            upstream_cache.add(n)
    
    tree.update(upstream)
    
    #check all  upstream nodes dont have inputs that dont lead to the selected node, and if they do, add all downstream nodes of that linked socket to the tree, otherwise mix nodes etc will have info missing
    downstream2=set()
    ends = set()
    cache = set()
    for n in tree:
        if n not in node_names:
            downstream2,end = get_downsttream_nodes(n,scene_name,downstream2,ends)

    tree.update(downstream2)
        
    return tree,upstream_cache



def get_all_cache_nodes(scene_name,get_muted = False,nodes_to_check = None):
    
    if nodes_to_check is None or len(nodes_to_check) <1:
        nodes_to_check = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes]
    if get_muted:
        mute_check = '(bpy.data.scenes[scene_name].node_tree.nodes[n].mute == True or bpy.data.scenes[scene_name].node_tree.nodes[n].mute == False)'
    else:
        mute_check = 'bpy.data.scenes[scene_name].node_tree.nodes[n].mute == False'
    cache_node_names = [n for n in nodes_to_check 
                        if 'temporal_parent' not in bpy.data.scenes[scene_name].node_tree.nodes[n]
                        and bpy.data.scenes[scene_name].node_tree.nodes[n].type == 'IMAGE' 
                        and bpy.data.scenes[scene_name].node_tree.nodes[n].image 
                        and eval(mute_check)
                        and (file_system_helpers.get_file_name_from_path(bpy.data.scenes[scene_name].node_tree.nodes[n].image.filepath).startswith('RL_') 
                            or file_system_helpers.get_file_name_from_path(bpy.data.scenes[scene_name].node_tree.nodes[n].image.filepath).startswith('CH_')
                            or file_system_helpers.get_file_name_from_path(bpy.data.scenes[scene_name].node_tree.nodes[n].image.filepath).startswith('RLT_'))
                            ]
    return cache_node_names

def get_all_standard_cache_nodes(scene_name,nodes_to_check = None,get_muted = False):
    
    if nodes_to_check is None or len(nodes_to_check) <1:
        nodes_to_check = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes]
    if get_muted:
        mute_check = '(bpy.data.scenes[scene_name].node_tree.nodes[n].mute == True or bpy.data.scenes[scene_name].node_tree.nodes[n].mute == False)'
    else:
        mute_check = 'bpy.data.scenes[scene_name].node_tree.nodes[n].mute == False'
    cache_node_names = [n for n in  nodes_to_check 
                        if 'temporal_parent' not in bpy.data.scenes[scene_name].node_tree.nodes[n] 
                        and bpy.data.scenes[scene_name].node_tree.nodes[n].type == 'IMAGE' 
                        and bpy.data.scenes[scene_name].node_tree.nodes[n].image 
                        and eval(mute_check)
                        and file_system_helpers.get_file_name_from_path(bpy.data.scenes[scene_name].node_tree.nodes[n].image.filepath).startswith('CH_')]
    return cache_node_names


def get_all_render_layer_cache_nodes(scene_name,nodes_to_check = None,get_muted = False):
    
    if nodes_to_check is None or len(nodes_to_check) <1:
        nodes_to_check = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes]
    if get_muted:
        mute_check = '(bpy.data.scenes[scene_name].node_tree.nodes[n].mute == True or bpy.data.scenes[scene_name].node_tree.nodes[n].mute == False)'
    else:
        mute_check = 'bpy.data.scenes[scene_name].node_tree.nodes[n].mute == False'
    
    
    cache_node_names = [n for n in nodes_to_check 
                        if 'temporal_parent' not in bpy.data.scenes[scene_name].node_tree.nodes[n] 
                        and bpy.data.scenes[scene_name].node_tree.nodes[n].type == 'IMAGE' 
                        and bpy.data.scenes[scene_name].node_tree.nodes[n].image 
                        and ('original' in bpy.data.scenes[scene_name].node_tree.nodes[n] or 'original' in bpy.data.scenes[scene_name].node_tree.nodes[n].image)#do both for backward compatibility 
                        and eval(mute_check)
                        and (file_system_helpers.get_file_name_from_path(bpy.data.scenes[scene_name].node_tree.nodes[n].image.filepath).startswith('RL_')
                            or file_system_helpers.get_file_name_from_path(bpy.data.scenes[scene_name].node_tree.nodes[n].image.filepath).startswith('RLT_'))]
    return cache_node_names


def nodes_that_use_this_img_bLock(img_block_name,scene_name):
    
    cache_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if checks.is_a_cache_node(n.name,scene_name) and n.image and n.image.name == img_block_name]
    return cache_nodes


def get_latest_base_attributes():
    """returns a list of attributes that don't need to be checked when hashing downstream nodes"""
    # scene = bpy.context.scene
    # nodes = scene.node_tree.nodes    
    # node = nodes.new('CompositorNodeNormal')
    # base_attributes = dir(node)
    # nodes.remove(node)
    # return base_attributes
    #return set(bpy.types.CompositorNodeMixRGB.bl_rna.properties.keys()) - set(bpy.types.CompositorNode.bl_rna.properties.keys())
    return set(bpy.types.CompositorNode.bl_rna.properties.keys())

    #all_att = set()



def get_non_inherited_attributes_only(scene_name,node_name):
     
    node_type = type(bpy.data.scenes[scene_name].node_tree.nodes[node_name])
    bases = node_type.__mro__

    #print()
    return set(node_type.bl_rna.properties.keys()) - set(bases[1].bl_rna.properties.keys())





def create_and_wire_rl_and_composite_node_if_either_missing(scene_name):


    rl_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'R_LAYERS' and n.mute == False]
    if rl_nodes:
        rl_node_name = rl_nodes[0]
    else:
        rl_node = bpy.data.scenes[scene_name].node_tree.nodes.new('CompositorNodeRLayers')
        rl_node_name = rl_node.name
        bpy.data.scenes[scene_name].node_tree.nodes[rl_node_name].location = (0,0)
        #print('render_layer_node_added')
    
    
    upstream_nodes,surplus = get_upstream_nodes(rl_node_name,scene_name)

    for n in upstream_nodes:
        if bpy.data.scenes[scene_name].node_tree.nodes[n].type == 'COMPOSITE':
            return
    
    rl_cache_nodes = cache_operation_helpers.get_all_cache_nodes_for_this_node(scene_name,rl_node_name)
    for n in rl_cache_nodes:
        upstream_nodes,surplus = get_upstream_nodes(n,scene_name)
        for n in upstream_nodes:
            if bpy.data.scenes[scene_name].node_tree.nodes[n].type == 'COMPOSITE':
                return

    # for out in bpy.data.scenes[scene_name].node_tree.nodes[rl_node_name].outputs:
    #     for link in out.links:
    #         if link.to_node.type == 'COMPOSITE':
    #             return


    composite_nodes = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'COMPOSITE' and n.mute == False]
    if composite_nodes:
        composite_node_name = composite_nodes[0]
    else:
        composite_node = bpy.data.scenes[scene_name].node_tree.nodes.new('CompositorNodeComposite')
        composite_node_name = composite_node.name    
        bpy.data.scenes[scene_name].node_tree.nodes[composite_node_name].location = (400,0)
        #print('composite node added')
    
    bpy.data.scenes[scene_name].node_tree.links.new( bpy.data.scenes[scene_name].node_tree.nodes[rl_node_name].outputs['Image'],
                                                    bpy.data.scenes[scene_name].node_tree.nodes[composite_node_name].inputs['Image'])
    #print('links made')



 
