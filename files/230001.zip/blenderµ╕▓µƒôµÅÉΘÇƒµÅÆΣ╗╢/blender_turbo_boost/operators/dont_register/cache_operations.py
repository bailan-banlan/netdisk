from..dont_register.report_custom_error import store_error
from ..dont_register import checks # img_belongs_to_this_scene, is_a_cache_node, is_a_non_render_layer_cache_node, is_a_render_layer_cache_node, original_node_still_has_the_outputs_for_each_of_the_cache_nodes_wired_outputs,scene_contains_unmuted_quality_node
from ..dont_register import cache_operation_helpers
from ..dont_register import node_helpers,scene_helpers
from ..dont_register import file_system_helpers
import bpy
import threading
from ...variables import global_vars

def cache(node_names,scene_name):
    '''generates an exr for standard cache and creates the standard cache node.  Not used for render layers'''
    
      

    nodes_to_mute = set([n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if (n.type == ('OUTPUT_FILE') or n.type == ('R_LAYERS')) and n.mute == False])        
    nodes_to_mute.update(cache_operation_helpers.mute_everything_but_upstream_and_downstream_nodes(node_names,scene_name,mute_upstream=True))
    for n in nodes_to_mute:
        node = bpy.data.scenes[scene_name].node_tree.nodes[n]
        node.mute = True   
        
    new_file_output_nodes = []    
    for n in node_names:
        #store the resolution
        bpy.data.scenes[scene_name].node_tree.nodes[n]['cache_resolution'] = bpy.data.scenes[scene_name].Standard_Cache_Resolution
        new_file_output_nodes.append(cache_operation_helpers.create_and_wire_file_output(scene_name,n,do_hash=False))    
    
    cache_operation_helpers.do_cache_render(scene_name)#,execution='INVOKE_DEFAULT')

    for n in nodes_to_mute:
        node = bpy.data.scenes[scene_name].node_tree.nodes[n]
        node.mute = False
    
    for n in new_file_output_nodes:        
        node = bpy.data.scenes[scene_name].node_tree.nodes[n]
        bpy.data.scenes[scene_name].node_tree.nodes.remove(node)
    
    if global_vars.remove_after_cache is not None:
        for n in global_vars.remove_after_cache:
            bpy.data.scenes[scene_name].node_tree.nodes.remove(bpy.data.scenes[scene_name].node_tree.nodes[n])        
        global_vars.remove_after_cache = set()

    new_cache_nodes = set()
    for n in node_names:
        #store the resolution
        bpy.data.scenes[scene_name].node_tree.nodes[n]['cache_resolution'] = bpy.data.scenes[scene_name].Standard_Cache_Resolution
        partial_path = file_system_helpers.get_cache_file_path_from_original_node_name(scene_name,n,do_hash=False)
        full_path = f'{partial_path}{str(bpy.data.scenes[scene_name].frame_current).zfill(4)}.exr'    
        if file_system_helpers.file_exists(full_path):
            new_cache_nodes.add(cache_operation_helpers.create_cache_node_and_wire_up(scene_name,full_path,n))
        else:
            store_error(scene_name,f"Unable to create cache node for node '{n}'', it can't generate an image without inputs!")

    cache_operation_helpers.append_hash_to_exr_and_update_image_datablock(scene_name,new_cache_nodes)
    


def uncache(node_names,scene_name):
    

    for node_name in node_names:
        #node = nodes[node_name]
        cache_node_names = []
        
        if checks.is_a_cache_node(node_name,scene_name):            
            cache_node_names.append(node_name)
        else:
            cache_node_names.extend(cache_operation_helpers.get_all_cache_nodes_for_this_node(scene_name,node_name))
        
        for n in cache_node_names:
            node = bpy.data.scenes[scene_name].node_tree.nodes[n]
            if 'cache_resolution' in node:
                del node['cache_resolution']
            #check original node still has all necessary sockets
            if checks.original_node_still_has_the_outputs_for_each_of_the_cache_nodes_wired_outputs(n,scene_name):
                cache_operation_helpers.move_links_from_cache_node_to_original_node(n, scene_name)
                img = node.image
                node_name = node.name
                original_is_a_render_layer_node = checks.is_a_render_layer_cache_node(node_name,scene_name)
                
                bpy.data.scenes[scene_name].node_tree.nodes.remove(node)
                if not original_is_a_render_layer_node:
                    if img.users == 0:# and checks.there_are_no_other_image_nodes_using_this_exr(scene_name,img.filepath): #and there are no other rl cache nodes using that exr
                        wild_path = file_system_helpers.get_path_with_second_hash_replaced_by_wildcard(img.filepath,False)
                        all_matching_files = file_system_helpers.get_files(wild_path)
                        for f in all_matching_files:                        
                            file_system_helpers.delete_file(f,scene_name)
                        
                        bpy.data.images.remove(img)#perhaps it would be wise to move this outs of the if statement so that the image data block always gets removed even if its a render layer node.  have to check if that would cause issues when updating upstream standard cache. yes it will, keep them.
        #cache_operation_helpers.update_rl_cache_nodes_from_temp_path_variable(scene_name)
        scene_helpers.update_node_tree_and_get_latest_cache_exr(scene_name)

def clear_cache_of_selected_nodes(scene_name,standard_cache_node_names):
     
     for n in standard_cache_node_names:
        node = bpy.data.scenes[scene_name].node_tree.nodes[n]
        img = node.image
        wild_path = file_system_helpers.get_path_with_second_hash_replaced_by_wildcard(img.filepath,False)
        all_matching_files = file_system_helpers.get_files(wild_path)
        for f in all_matching_files:                        
            file_system_helpers.delete_file(f,scene_name)

            
def refresh_all(scene_name,perform_mute_unmute = True):
    """refreshes all standard cache nodes"""
    
    if perform_mute_unmute:
        nodes_to_mute = set([n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if (n.type == ('OUTPUT_FILE') or n.type == ('R_LAYERS')) and n.mute == False])  
        for n in nodes_to_mute:
            
            bpy.data.scenes[scene_name].node_tree.nodes[n].mute = True

    
    cache_nodes = node_helpers.get_all_standard_cache_nodes(scene_name)    
    for n in cache_nodes:        
        cache_operation_helpers.store_link_list_in_cache_node(n,scene_name)
        cache_operation_helpers.move_links_from_cache_node_to_original_node(n,scene_name)        

    new_file_output_nodes = []
    original_nodes = set([bpy.data.scenes[scene_name].node_tree.nodes[n].image['original'] for n in cache_nodes if 'original' in bpy.data.scenes[scene_name].node_tree.nodes[n].image])
    #original_nodes.update(set([nodes[n]['original'] for n in cache_nodes if 'original' in nodes[n]['original']]))
    new_file_output_nodes = []    
    for n in original_nodes:
        new_file_output_nodes.append(cache_operation_helpers.create_and_wire_file_output(scene_name,n,do_hash=False))   
    
    cache_operation_helpers.do_cache_render(scene_name)

    for n in new_file_output_nodes:
        
        bpy.data.scenes[scene_name].node_tree.nodes.remove(bpy.data.scenes[scene_name].node_tree.nodes[n])

    if global_vars.remove_after_cache is not None:
        for n in global_vars.remove_after_cache:
            bpy.data.scenes[scene_name].node_tree.nodes.remove(bpy.data.scenes[scene_name].node_tree.nodes[n])        
        global_vars.remove_after_cache = set()
    
    if perform_mute_unmute:
        for n in nodes_to_mute:
            
            bpy.data.scenes[scene_name].node_tree.nodes[n].mute = False    
    
    img_blocks_already_done = set()
    for n in cache_nodes:        
        
        if bpy.data.scenes[scene_name].node_tree.nodes[n].image.name not in img_blocks_already_done:
            cache_operation_helpers.update_cache_image_delete_exr_and_create_image_if_necessary(n,scene_name)
            img_blocks_already_done.add(bpy.data.scenes[scene_name].node_tree.nodes[n].image.name)
    
    
        

    
    for n in cache_nodes:
        
        cache_operation_helpers.move_links_to_cache_node(n,scene_name)
    #do_cache_render(scene_name,False)
    cache_operation_helpers.append_hash_to_exr_and_update_image_datablock(scene_name, cache_nodes)

    cache_operation_helpers.delete_redundant_exr(scene_name,cache_nodes)


def refresh_selected_and_upstream(node_names,scene_name,perform_mute_unmute = True):#,all_cache_nodes_to_refresh, nodes_not_to_mute, cache_nodes):
    
    #the nodes not to mute are all upstream and downstream nodes of selected nodes.  cache_nodes_to_re-render are just those including and upstream of the selected nodes.
    nodes_not_to_mute,cache_nodes_to_re_render = node_helpers.get_upstream_and_downtream_from_selection(node_names, scene_name)

    
    
    if perform_mute_unmute:
        nodes_to_mute = set()
        nodes_to_mute.update(set([n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
                                if (n.name not in nodes_not_to_mute and n.type !='COMPOSITE')
                                or(n.type == ('OUTPUT_FILE') or n.type == ('R_LAYERS'))# or (n.type == 'SCALE' and 'quality_node' in n)) 
                                and n.mute == False
                                ]))
        for n in nodes_to_mute:
            bpy.data.scenes[scene_name].node_tree.nodes[n].mute = True
    
    # #place a viewer on all inputs of active mix nodes to avoid different sizes
    # mixes = [n for n in nodes_not_to_mute if nodes[n].type =='MIX_RGB']
    # temp_quality = create_quality_node(scene_name,mixes,make_space=False)
    
    for n in cache_nodes_to_re_render:        
        cache_operation_helpers.store_link_list_in_cache_node(n,scene_name)
        cache_operation_helpers.move_links_from_cache_node_to_original_node(n,scene_name)        

    all_original_nodes_to_re_render = [cache_operation_helpers.get_original_node_name_from_image_block_name(bpy.data.scenes[scene_name].node_tree.nodes[n].image.name) for n in cache_nodes_to_re_render]
    file_list = []

    #it has to be rendered without the hash because the cache nodes are missing at the moment due to the original nodes being wired bacvk up instead
    for n in all_original_nodes_to_re_render:
        file_list.append(cache_operation_helpers.create_and_wire_file_output(scene_name,n,do_hash=False))    
    #print('just about to rerender the cache')
    cache_operation_helpers.do_cache_render(scene_name)
    
    for n in file_list:        
        bpy.data.scenes[scene_name].node_tree.nodes.remove(bpy.data.scenes[scene_name].node_tree.nodes[n])
    
    # nodes = bpy.data.scenes[scene_name].node_tree.nodes
    # remove_quality_nodes(scene_name,temp_quality)
    
    
    if global_vars.remove_after_cache is not None:
        for n in global_vars.remove_after_cache:
            bpy.data.scenes[scene_name].node_tree.nodes.remove(bpy.data.scenes[scene_name].node_tree.nodes[n])        
        global_vars.remove_after_cache = set()

    if perform_mute_unmute:
        for n in nodes_to_mute:
            bpy.data.scenes[scene_name].node_tree.nodes[n].mute = False    
    
    # scene.render.resolution_percentage = scene['original render resolution']
    
    for n in cache_nodes_to_re_render:        
        cache_operation_helpers.update_cache_image_delete_exr_and_create_image_if_necessary(n,scene_name)
    
    for n in cache_nodes_to_re_render:
        
        cache_operation_helpers.move_links_to_cache_node(n,scene_name)
    #do_cache_render(scene_name,False)

    #before doing this we have to update the  image block to the new exr and rewire the cache nodes so that the correct hash is calculated.
    cache_operation_helpers.append_hash_to_exr_and_update_image_datablock(scene_name, cache_nodes_to_re_render)

    cache_operation_helpers.delete_redundant_exr(scene_name,cache_nodes_to_re_render)


def set_up_for_render(scene_name):
    #print('inside setup for renderer = ',threading.currentThread().ident)
    
    cache_nodes = node_helpers.get_all_cache_nodes(scene_name)    
    for n in cache_nodes:        
        cache_operation_helpers.store_link_list_in_cache_node(n,scene_name)
        cache_operation_helpers.move_links_from_cache_node_to_original_node(n,scene_name)
        
    original_nodes = set([bpy.data.scenes[scene_name].node_tree.nodes[n].image['original'] for n in cache_nodes])
    original_nodes.update([n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'R_LAYERS' and n.mute == False])
    new_file_output_nodes = []    
    for n in original_nodes:
        cache_operation_helpers.create_and_wire_file_output(scene_name,n,do_hash=False)