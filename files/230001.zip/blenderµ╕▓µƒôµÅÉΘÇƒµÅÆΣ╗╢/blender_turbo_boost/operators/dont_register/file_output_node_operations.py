import bpy
from bpy.types import Preferences
from . import node_helpers,cache_operation_helpers,checks
from ...variables import global_vars

def prepare_to_resave_selected_file_output_nodes(scene_name,file_output_node_names,do_anim = False):
    nodes = bpy.data.scenes[scene_name].node_tree.nodes
    downstream = set()
    end_nodes = set()
    for n in file_output_node_names:
        
        downstream,end_nodes = node_helpers.get_downsttream_nodes(n,scene_name,downstream,end_nodes)
    if checks.file_output_can_be_resaved(scene_name,downstream):
        nodes_to_mute = [n.name for n in nodes if (n.name not in downstream)  and n.mute == False and n.name not in file_output_node_names] #removed or (n.type == 'SCALE' and 'quality_node' in n))
        global_vars.nodes_muted_at_beginning_of_playback = nodes_to_mute
        for node in nodes_to_mute:
            nodes[node].mute = True
        return True
    else:
        return False

    
        
        #or (n.type == 'SCALE' and 'quality_node' in n)
        
    #muted_nodes = cache_operation_helpers.mute_everything_but_upstream_and_downstream_nodes(file_output_node_names,scene_name)



def put_tree_back_to_original_state(scene_name):
    nodes = bpy.data.scenes[scene_name].node_tree.nodes
    for n in global_vars.nodes_muted_at_beginning_of_playback:
        nodes[n].mute = False
    global_vars.render_type = []
    global_vars.nodes_muted_at_beginning_of_playback = None
   
    #print('has done the file output')
