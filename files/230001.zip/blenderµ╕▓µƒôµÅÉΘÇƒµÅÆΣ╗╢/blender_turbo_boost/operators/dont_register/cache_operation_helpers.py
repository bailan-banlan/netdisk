import hashlib

from bl_ui.space_toolsystem_common import ToolDef
from ..dont_register import checks
from ..dont_register.report_custom_error import store_error
from ..dont_register import node_helpers
from ..dont_register import file_system_helpers 
from ...variables import global_vars
import json
import bpy
import collections
collections.Callable = collections.abc.Callable


#get information from nodes
#-----------------------------------------------------------------------------------------------
def get_original_node_name_from_image_block_name(image_block_name):
    
    original = bpy.data.images[image_block_name]['original']
    return original

def get_original_node_name_render_layer_cache_node(scene_name,cache_node_name):
    
    original = bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name]['original']
    return original

def get_original_node_name_from_cache_node(scene_name,cache_node_name):
    try:
        if 'original' in bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name]: #its a render layer cache node
            return get_original_node_name_render_layer_cache_node(scene_name,cache_node_name)
        else:
            return get_original_node_name_from_image_block_name(bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image.name)
    except:
        return None
    

def get_all_cache_nodes_for_this_node(scene_name,node_name,get_muted = True):
    
    if get_muted:
        mute_check = '(n.mute == True or n.mute == False)'
    else:
        mute_check = 'n.mute == False'
    if bpy.data.scenes[scene_name].node_tree.nodes[node_name].type == 'R_LAYERS':        
        #we may not need to know that it has an image loaded in. Will need to check if this is automatically updated in update exr or elsewhere
        cache_node_names = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
                            if n.type =='IMAGE'
                            and n.image 
                            and eval(mute_check)
                            and (file_system_helpers.get_file_name_from_path(n.image.filepath).startswith('RL_') 
                                or
                                file_system_helpers.get_file_name_from_path(n.image.filepath).startswith('RLT_'))
                            and get_original_node_name_from_cache_node(scene_name,n.name) == node_name]
    else:
        cache_node_names = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes 
                            if n.type =='IMAGE'
                            and n.image 
                            and eval(mute_check)
                            and file_system_helpers.get_file_name_from_path(n.image.filepath).startswith('CH_')
                            and get_original_node_name_from_image_block_name(n.image.name) == node_name]

    return cache_node_names


def get_original_socket_name_from_cache_socket_name(socket_name):
    pos = socket_name.find('_')
    return socket_name[pos + 1:]


def get_socket_id_from_socket(socket):

    full_path_to_socket = socket.path_from_id()[:-1]
    index_of_last_square_bracket = full_path_to_socket.rfind('[')    
    id = full_path_to_socket[index_of_last_square_bracket + 1:]

    return int(id)

def delete_the_delete_me_nodes(scene_name):
    nodes_to_delete = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if 'delete_me' in n]
    for n in nodes_to_delete:
        bpy.data.scenes[scene_name].node_tree.nodes.remove(bpy.data.scenes[scene_name].node_tree.nodes[n])

def convert_vector_to_RGBA(scene_name,file_output_node_name,input_socket_id):

    try:
        seperate_vector_node = bpy.data.scenes[scene_name].node_tree.nodes.new("CompositorNodeSeparateColor")    
        combine_image_node = bpy.data.scenes[scene_name].node_tree.nodes.new("CompositorNodeCombineColor")
        combine_image_node.label = 'Rendering'
        red = 'Red'
        green = 'Green'
        blue = 'Blue'
        alpha = 'Alpha'
    except:
        seperate_vector_node = bpy.data.scenes[scene_name].node_tree.nodes.new("CompositorNodeSepRGBA")    
        combine_image_node = bpy.data.scenes[scene_name].node_tree.nodes.new("CompositorNodeCombRGBA")
        combine_image_node.label = 'Rendering'
        red = 'R'
        green = 'G'
        blue = 'B'
        alpha = 'A'

    seperate_name = seperate_vector_node.name
    combine_name = combine_image_node.name

    bpy.data.scenes[scene_name].node_tree.nodes[seperate_name]['delete_me'] = True
    bpy.data.scenes[scene_name].node_tree.nodes[combine_name]['delete_me'] = True

    flocation = bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].location
    if global_vars.testing:
        bpy.data.scenes[scene_name].node_tree.nodes[seperate_name].location = (flocation[0]-400,flocation[1])
        bpy.data.scenes[scene_name].node_tree.nodes[combine_name].location = (flocation[0]-200,flocation[1])
    else:
        bpy.data.scenes[scene_name].node_tree.nodes[seperate_name].location = flocation
        bpy.data.scenes[scene_name].node_tree.nodes[seperate_name].hide = True
        bpy.data.scenes[scene_name].node_tree.nodes[combine_name].location = flocation
        bpy.data.scenes[scene_name].node_tree.nodes[combine_name].hide = True

    from_node_name = bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].inputs[input_socket_id].links[0].from_node.name
    from_node_socket_id = get_socket_id_from_socket(bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].inputs[input_socket_id].links[0].from_socket)
    
    #connect from node to seperate input
    bpy.data.scenes[scene_name].node_tree.links.new(
        bpy.data.scenes[scene_name].node_tree.nodes[from_node_name].outputs[from_node_socket_id],
        bpy.data.scenes[scene_name].node_tree.nodes[seperate_name].inputs['Image']
    )

    #connect combine to file output
    bpy.data.scenes[scene_name].node_tree.links.new(
        bpy.data.scenes[scene_name].node_tree.nodes[combine_name].outputs['Image'],
        bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].inputs[input_socket_id]
    )

    #red
    bpy.data.scenes[scene_name].node_tree.links.new(
        bpy.data.scenes[scene_name].node_tree.nodes[seperate_name].outputs[red],
        bpy.data.scenes[scene_name].node_tree.nodes[combine_name].inputs[red]
    )

    #green
    bpy.data.scenes[scene_name].node_tree.links.new(
        bpy.data.scenes[scene_name].node_tree.nodes[seperate_name].outputs[green],
        bpy.data.scenes[scene_name].node_tree.nodes[combine_name].inputs[green]
    )

    #blue
    bpy.data.scenes[scene_name].node_tree.links.new(
        bpy.data.scenes[scene_name].node_tree.nodes[seperate_name].outputs[blue],
        bpy.data.scenes[scene_name].node_tree.nodes[combine_name].inputs[blue]
    )

    #alpha
    bpy.data.scenes[scene_name].node_tree.links.new(
        bpy.data.scenes[scene_name].node_tree.nodes[seperate_name].outputs[alpha],
        bpy.data.scenes[scene_name].node_tree.nodes[combine_name].inputs[alpha]
    )



def create_vector_pass_file_output(scene_name,render_layer_node_name):
    file_output_node = bpy.data.scenes[scene_name].node_tree.nodes.new("CompositorNodeOutputFile")
    file_output_node_name = file_output_node.name    
    vector_path = file_system_helpers.get_cache_file_path_from_original_node_name(scene_name,render_layer_node_name,is_for_temporal_vector_only=True)
    
    bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].format.file_format = 'OPEN_EXR_MULTILAYER'
    bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].format.color_depth = '32'
    bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].format.color_mode = 'RGBA'
    bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].location = bpy.data.scenes[scene_name].node_tree.nodes[render_layer_node_name].location
    bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].base_path = vector_path
    bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].file_slots.remove(bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].inputs[0])
    
    bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].format.exr_codec = 'ZIP'
    bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].hide = True
    

    bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].file_slots.new('Vector')
    bpy.data.scenes[scene_name].node_tree.links.new(
        bpy.data.scenes[scene_name].node_tree.nodes[render_layer_node_name].outputs['Vector'],
        bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].inputs['Vector']
    )

    file_vector_input_id = get_socket_id_from_socket(bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name].inputs['Vector'])
    convert_vector_to_RGBA(scene_name,file_output_node.name,file_vector_input_id)


#operations

def vector_pass_is_user_enabled(scene_name,render_layer_node_name):
    render_layer_scene = bpy.data.scenes[scene_name].node_tree.nodes[render_layer_node_name].scene.name
    render_layer_viewlayer = bpy.data.scenes[scene_name].node_tree.nodes[render_layer_node_name].layer
    #global_vars.turbo_passes_enabled.add((scene_name,viewlayer_name,p[0],p[1]))
    if bpy.data.scenes[render_layer_scene].view_layers[render_layer_viewlayer].use_pass_vector:
        if global_vars.vector_pass_enabled_for_render is not None and global_vars.vector_pass_enabled_for_render == True:
            return False
        return True
    return False
    
    
#---------------------------------------------------------------------------------------------
def create_and_wire_file_output(scene_name,node_name,node_position = None, partial_path = None,for_caching = True,for_denoise = False,do_hash = True,image_format = "OPEN_EXR_MULTILAYER",only_linked = False,minimise = False):

    
    #for caching is only false when creating a new file output using the file output node create and wire operator.
    if for_caching == True and checks.is_a_non_render_layer_cache_node(node_name,scene_name):
        original_node_name = get_original_node_name_from_image_block_name(bpy.data.scenes[scene_name].node_tree.nodes[node_name].image.name)
    else:
        original_node_name = node_name
    
    cache_percent = None

    color_depth = str()
    color_mode = 'RGBA'
    if bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].type == 'R_LAYERS':
        color_depth = bpy.context.preferences.addons[__name__.split('.')[0]].preferences.render_layer_bit_depth        
        if not bpy.data.scenes[bpy.data.scenes[scene_name].node_tree.nodes[node_name].scene.name].render.film_transparent and not vector_pass_is_user_enabled(scene_name,node_name): #need to also keep rgba if vector pass is enabled by the user
            color_mode = 'RGB'
        
    else:
        color_depth = bpy.context.preferences.addons[__name__.split('.')[0]].preferences.non_render_layer_bit_depth
        if 'cache_resolution' in bpy.data.scenes[scene_name].node_tree.nodes[original_node_name]:
            cache_percent = bpy.data.scenes[scene_name].node_tree.nodes[original_node_name]['cache_resolution']

     
    file_output_node = bpy.data.scenes[scene_name].node_tree.nodes.new("CompositorNodeOutputFile")
    if cache_percent is not None:
        file_output_node['cache_resolution'] = cache_percent
    
    if partial_path == None:        
        partial_path = file_system_helpers.get_cache_file_path_from_original_node_name(scene_name,original_node_name,do_hash=do_hash)
    if node_position == None and for_caching == True:
        node_position = (bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].location.x + (bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].width/2), bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].location.y + (bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].width/2))
    if node_position == None and for_caching == False:
        node_position = (bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].location.x + (bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].width + 30), bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].location.y + file_output_node.height + 20)
    file_output_node.location = node_position
    file_output_node.base_path = file_system_helpers.get_safe_path(partial_path)
    file_output_node.file_slots.remove(file_output_node.inputs[0])
    file_output_node.format.file_format = image_format
    file_output_node.hide = True

    #try and assign it the current color mode, and if it doesnt work fall back to rgb.  Same for color depth.
    try:
        file_output_node.format.color_mode = color_mode
    except:
        file_output_node.format.color_mode = 'RGB'
    file_output_node.format.exr_codec = 'ZIP'
    
    try:
        file_output_node.format.color_depth = color_depth
    except:
         file_output_node.format.color_depth = '8'
    
    if only_linked:
        valid_sockets = [socket for socket in bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].outputs if socket.enabled == True and len(socket.links)>0]  
    else:
        valid_sockets = [socket for socket in bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].outputs if socket.enabled == True] 
    for index,out in enumerate(valid_sockets):
        if for_caching:
            if bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].type == 'R_LAYERS':
                to_socket_name = file_system_helpers.create_exr_friendly_socket_name_with_prefix(scene_name,index,out.name)
            else:
                to_socket_name = file_system_helpers.create_exr_friendly_socket_name_with_prefix(scene_name,index,out.identifier)
        else:
            if checks.is_a_cache_node(original_node_name,scene_name):
                to_socket_name = file_system_helpers.create_exr_friendly_socket_name_with_prefix(scene_name,index,out.identifier,False)
            else:
                to_socket_name = file_system_helpers.create_exr_friendly_socket_name_with_prefix(scene_name,index,out.identifier)
                
           
        file_output_node.file_slots.new(to_socket_name)
        bpy.data.scenes[scene_name].node_tree.links.new(
            out,
            file_output_node.inputs[to_socket_name]
        )

        if out.type == 'VECTOR':
            fout_id = get_socket_id_from_socket(file_output_node.inputs[to_socket_name])
            convert_vector_to_RGBA(scene_name,file_output_node.name,fout_id)

    if for_caching == True and bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].type !='R_LAYERS':
        
        add_scale_crop_between_file_output_and_original(scene_name,file_output_node.name)
    
    
        
        
    return file_output_node.name


def do_cache_render(scene_name,is_cache_render = True, anim = False, execution = 'EXEC_DEFAULT',write_still_frame = False,lock_ui = True):
    locked = False
    if lock_ui and not bpy.context.scene.render.use_lock_interface:
        locked = True        
        bpy.context.scene.render.use_lock_interface = True

    bpy.data.scenes[scene_name]['cache_render'] = True
    bpy.ops.render.render(execution,animation = anim,write_still=write_still_frame,use_viewport=False)
    del bpy.data.scenes[scene_name]['cache_render']

    if locked:
         bpy.context.scene.render.use_lock_interface = False
    


def create_cache_node_and_wire_up(scene_name,exr_path,original_node_name):
    """
    use this after rendering the cache exr to create the cache node, load the latest exr, and then move the links from the current node to the cache node.
    """
    
    
    if bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].type == 'R_LAYERS':
        #check if there is an image datablock for this rl node already (user may have deleted it but the datablock could still be here)
        existing_img = [n for n in bpy.data.images 
                        if n.filepath == exr_path]#here I should probably no bother seeing if it's for original because several nodes will use the same image datablock
        if existing_img:
            img = existing_img[0]
        else:
            img = bpy.data.images.load(exr_path, check_existing=True)
        img['scene'] = bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].scene.name
        img['cam'] = bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].scene.camera.name
        img['layer'] = bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].layer
        img.name = f'cache for {bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].scene.name}-{bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].scene.camera.name}-{bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].layer}'
        
        
        
    else:
        img = bpy.data.images.load(exr_path, check_existing=True)    
        img['scene'] = scene_name

        img['original'] = original_node_name    
        img.name = f'cache for {original_node_name} in {scene_name}'
   
    #create the image node
    cache_node = bpy.data.scenes[scene_name].node_tree.nodes.new("CompositorNodeImage")

    #check if original is inside a frame
    cache_node.parent = bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].parent
    if bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].type == 'R_LAYERS':
        cache_node.location.x = bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].location.x 
        cache_node.location.y = bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].location.y - 30
        bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].hide = True
        cache_node['original'] = original_node_name
    else:
        cache_node.location.x = bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].location.x + (bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].width/2) 
        cache_node.location.y = bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].location.y + (bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].width/2)
    cache_node.image = img
    cache_node.image.reload()
    #cache_node.label = f'cache for {original_node_name}'
    #cache node options
    cache_node.show_preview = True
    cache_node.image.use_half_precision = False
    cache_node.show_options = True
    #loop throught the outputs and swap the link to the cache node
    move_links_to_cache_node(cache_node.name,scene_name)
    cache_node.select = True
    
    return cache_node.name


def mute_everything_but_upstream_and_downstream_nodes(selected_node_names,scene_name,mute_upstream=False,mute_downstream=False):
    """mutes everything apart from upstreams, downstream, composite nodes, and the selected nodes.  setting either mute_upstream or mute_downstream to True will also mute those nodes"""
    
    nodes_not_to_mute = set([n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'COMPOSITE'])      
    for n in selected_node_names:
        nodes_not_to_mute.add(n)
        if not mute_upstream:
            upstream_nodes,unused = node_helpers.get_upstream_nodes(n,scene_name)
            nodes_not_to_mute.update(upstream_nodes)
        if not mute_downstream:
            downstream_nodes,unused = node_helpers.get_downsttream_nodes(n,scene_name)           
            nodes_not_to_mute.update(downstream_nodes)


    muted_nodes = set()
    for n in bpy.data.scenes[scene_name].node_tree.nodes:
        if n.name not in nodes_not_to_mute and n.mute == False:
            n.mute = True
            muted_nodes.add(n.name)

    return muted_nodes


def update_cache_image_delete_exr_and_create_image_if_necessary(cache_node_name,scene_name):
    
    if checks.is_a_render_layer_cache_node(cache_node_name,scene_name):
        return rl_cache_full_update_with_delete_and_create_if_necessary(scene_name,cache_node_name)
    else:
        return standard_cache_node_full_update_exr_with_just_rendered_and_create_new_image_block_if_necessary(scene_name,cache_node_name)


def rl_cache_full_update_with_delete_and_create_if_necessary(scene_name,cache_node_name):
    """this updates the render layer image datablock for this cache node to the latest exr based on the render layer nodes: scene, viewlayer, render layer node's scene's camera, and the blend file
    
        returns true if there is a recent exr and false if not
    """
      
    
    
    #try and get the exr for this frame and if not exist get the latest.
   
    new_exr_path = file_system_helpers.get_exr(scene_name,cache_node_name)
    if file_system_helpers.file_exists(new_exr_path):
        
        rl_node_name = get_original_node_name_from_cache_node(scene_name,cache_node_name)
        #need to check that this image is worthy of this rl nodes credentials
        if checks.cache_node_image_block_matches_the_rl_node_settings(scene_name,cache_node_name):
            
            old_path = bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image.filepath            
            bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image.filepath = new_exr_path
            bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image.reload()
            old_without_frame_and_ext = file_system_helpers.get_path_without_framenum_and_extension(old_path)
            old_without_frame_ext_and_prefix = file_system_helpers.get_path_without_cache_type_prefix(old_without_frame_and_ext)
            new_without_frame_and_ext = file_system_helpers.get_path_without_framenum_and_extension(new_exr_path)
            new_without_frame_ext_and_prefix = file_system_helpers.get_path_without_cache_type_prefix(new_without_frame_and_ext)

            old_frame = file_system_helpers.get_frame_from_path(old_path)
            new_frame = file_system_helpers.get_frame_from_path(new_exr_path)
            
            if old_without_frame_ext_and_prefix == new_without_frame_ext_and_prefix and old_frame != new_frame and global_vars.rendering and not global_vars.render_cancelled and bpy.data.scenes[scene_name].Keep_Cache == False:
                file_system_helpers.delete_file(old_path,scene_name)
        else:
            #create new image block
            new_img = bpy.data.images.load(new_exr_path,check_existing=True)#changing this to true should avoid duplicate image blocks - need to test thoroughly to see if it causes issues.
            new_img['scene'] = bpy.data.scenes[scene_name].node_tree.nodes[rl_node_name].scene.name
            new_img['cam'] = bpy.data.scenes[scene_name].node_tree.nodes[rl_node_name].scene.camera.name
            new_img['layer'] = bpy.data.scenes[scene_name].node_tree.nodes[rl_node_name].layer
            
            new_img.name = f"cache for {bpy.data.scenes[scene_name].node_tree.nodes[rl_node_name].scene.name}-{bpy.data.scenes[scene_name].node_tree.nodes[rl_node_name].scene.camera.name}-{bpy.data.scenes[scene_name].node_tree.nodes[rl_node_name].layer}"
            bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image = new_img

            users = node_helpers.nodes_that_use_this_img_bLock(bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image.name,scene_name)            
            for user in users:
                bpy.data.scenes[scene_name].node_tree.nodes[user].image = new_img
                
        return bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image.name
    else:
        return None


def standard_cache_node_full_update_exr_with_just_rendered_and_create_new_image_block_if_necessary(scene_name,cache_node_name):
    """all this does is load the newest exr file into the existing image block, or create a new image block if the image block is from a different scene (due to duplicating a full scene)
    
        returns true if there is an exr for this cache node's orignal node, false if not
    """
    
    frame = bpy.data.scenes[scene_name].frame_current
    new_exr_path = file_system_helpers.get_cache_file_path_from_original_node_name(scene_name, get_original_node_name_from_image_block_name(bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image.name),do_hash=False)
    new_exr_path = f'{new_exr_path}{str(frame).zfill(4)}.exr'
    if file_system_helpers.file_exists(new_exr_path):
        img = bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image
        #make sure the datablock (not exr) is not for a the same named node in a different scene (this could happen if the scene was duplicated)

        #if the image datablock is correct, then just upate
        if bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image['scene'] == scene_name:
            old_path = bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image.filepath            
            
            bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image.filepath = new_exr_path
            bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image.reload()
            
            #always delete the old image if we're not keeping the cache, but only if they're differnet 
            if old_path != new_exr_path and bpy.data.scenes[scene_name].Keep_Cache == False:
                file_system_helpers.delete_file(old_path,scene_name)
               
        else:
            #else create a new one because it was for a different scene, then assign the new datablock to this cache node and all other cache nodes that use the original image datablock (in this scene)
            img_new = bpy.data.images.load(new_exr_path,check_existing=True)
            img_new['scene'] = scene_name
            img_new['original'] = img['original']
            img_new.name = f"cache for {img_new['original']}"
            users = node_helpers.nodes_that_use_this_img_bLock(img.name,scene_name)
            bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image = img_new
            for user in users:
                bpy.data.scenes[scene_name].node_tree.nodes[user].image = img_new
        return True
    else:        
        return False

def delete_redundant_exr(scene_name,cache_nodes,delete_current_frame_only = True):
    
    for nn in cache_nodes:
        
        if bpy.data.scenes[scene_name].node_tree.nodes[nn].mute == True:
            current_path = bpy.data.scenes[scene_name].node_tree.nodes[nn].image['temp_path']
        else:
            current_path = bpy.data.scenes[scene_name].node_tree.nodes[nn].image.filepath
        #delete all other files that have the same start hash and frame, ignore the dowstream(second) hash
        wild_path = file_system_helpers.get_path_with_second_hash_replaced_by_wildcard(current_path,only_this_frame= delete_current_frame_only)
        all_matching_files = file_system_helpers.get_files(wild_path)
        for f in all_matching_files:
            if f != current_path:
                file_system_helpers.delete_file(f,scene_name)
                #print('deleted file',f)

def get_hash_of_the_all_downstream_attributes_combined(scene_name,node_name):
    
    def add_texture_value_to_all_attributes():
        #it's a generated texture from the texture panel
        #print('it is an image')
        a = val.evaluate((0,30,60,))
        b = val.evaluate((50,150,0,))
        c = val.evaluate((9,10,0,))
        d = val.evaluate((5,60,8,))
        all_attributes.append((att,(a,b,c,d)))

    def add_ramp_value_to_all_attributes():
        
        all_attributes.append((att,val.color_mode))
        all_attributes.append((att,val.hue_interpolation))
        all_attributes.append((att,val.interpolation))
        for elem in val.elements:
            all_attributes.append((att,elem.alpha))
            all_attributes.append((att,list(elem.color)))
            all_attributes.append((att,elem.position))

    
    def evaluate_exr_and_add_value_to_all_attributes():
        
        pass
        if bpy.data.scenes[scene_name].node_tree.nodes[n].mute == False or not checks.is_a_cache_node(n,scene_name):
            the_path = file_system_helpers.get_absolute_path(val.filepath)
        else:
            if 'temp_path' in bpy.data.scenes[scene_name].node_tree.nodes[n].image and bpy.data.scenes[scene_name].node_tree.nodes[n].image['temp_path'] is not None:
                the_path = file_system_helpers.get_absolute_path(bpy.data.scenes[scene_name].node_tree.nodes[n].image['temp_path'])
            else:
                all_attributes.append((att,'muted_with_no_temp_path'))
                return
        if file_system_helpers.file_exists(the_path):
            """below is too slow with large files"""
            # with open(the_path,"rb") as f:
            #     the_bytes = f.read() # read entire file as bytes
            #     the_hash = hashlib.md5(the_bytes).hexdigest()
            #file_size = file_system_helpers.get_file_size(the_path)
            file_modified = file_system_helpers.get_file_modified_time(the_path)
            all_attributes.append((att,file_modified))#,int(file_modified)))
            # if node.name == 'Image.002':
            #     print(att,file_size,int(file_modified))
        else:
            all_attributes.append((att,'MISSING'))

    def add_curve_points_to_all_attributes():
        val.initialize()
        all_points = set()
        for cv in val.curves:
            for p in cv.points:
                all_points.add(str(p.location))
            
        #for p in all_points:
        all_attributes.append((att,str(all_points)))
        #print(str(all_attributes))

    #print('\nstart\n')

    
    frame = bpy.data.scenes[scene_name].frame_current
    downstream = set()
    end_nodes = set()
    cache_nodes = set()
    
    
    
    #THIS IS THE PROPER ONE
    downstream,end_nodes,cache_nodes = node_helpers.get_downsttream_nodes_including_downstream_of_cache_nodes(node_name,scene_name,downstream,end_nodes,cache_nodes)
    to_do = set()
    downstream.add(node_name)

    all_attributes = []
    
    for n in downstream:

        #if already hashed skip (continue)
        
        
        if (bpy.data.scenes[scene_name].node_tree.nodes[n].type == 'SCALE' and 'quality_node'  in bpy.data.scenes[scene_name].node_tree.nodes[n]) or 'ignore_in_hash' in bpy.data.scenes[scene_name].node_tree.nodes[n]:
            continue
        
        invalid_attributes = node_helpers.get_latest_base_attributes()
        invalid_attributes.remove('mute')

        for att in dir(bpy.data.scenes[scene_name].node_tree.nodes[n]):
            
            
            if att not in invalid_attributes and not att.startswith('__') and not (bpy.data.scenes[scene_name].node_tree.nodes[n].type == 'IMAGE' and ((bpy.data.scenes[scene_name].node_tree.nodes[n].has_layers == False and att == 'layer') or (bpy.data.scenes[scene_name].node_tree.nodes[n].has_views == False and att == 'view'))):
                #print(type(att))
                #print(att)
                #print(att)
                val = getattr(bpy.data.scenes[scene_name].node_tree.nodes[n],att) 
                
                if isinstance(val,collections.Callable):
                    continue
                if 'bpy.types' in str(type(val)) or type(val) == bpy.types.bpy_prop_array:
                    #it's a blender class
                    
                    
                    
                    if 'bpy_types.Texture' in str(type(val).__mro__):
                        if val.type != 'NOISE': #using mro here to ensure all different texture types are covered
                            add_texture_value_to_all_attributes()
                        #pass
                    elif type(val) == bpy.types.ColorRamp:
                        add_ramp_value_to_all_attributes()
                    elif type(val) == bpy.types.Image and val.source != 'MOVIE':                         
                        evaluate_exr_and_add_value_to_all_attributes()
                    elif type(val) == bpy.types.Scene:
                        all_attributes.append((att,val.name))
                    elif type(val) == bpy.types.CompositorNodeTree:                        
                        all_attributes.append((att,val.name))
                        #print(att)
                    elif 'bpy.types.NodeTreeInterface_NodeGroup' in str(type(val)):
                        pass
                    elif type(val) == bpy.types.bpy_prop_collection:
                        #don't need to worry about these as I think they're just user set properties (which cant exist unless from python when its nodes)
                        pass
                    elif type(val) == bpy.types.MovieClip:
                        all_attributes.append((att,val.name))
                    elif type(val) == bpy.types.CurveMapping:
                        add_curve_points_to_all_attributes()
                    elif type(val) == bpy.types.Mask:
                        all_attributes.append((att,val.name))
                    elif type(val) == bpy.types.bpy_prop_array:
                        #print('prop array')
                        try:
                            all_attributes.append((str(bpy.data.scenes[scene_name].node_tree.nodes[n].name).upper(),list(val)))
                        except:
                            all_attributes.append((str(bpy.data.scenes[scene_name].node_tree.nodes[n].name).upper(),str(val)))
                    else:
                        to_do.add(f'{att},on,{bpy.data.scenes[scene_name].node_tree.nodes[n].name},needs looking at wally, its of type {type(val)}')

                else:
                    #it's a standard python class int, float, string, bool....
                    #print(type(val))
                    if not (checks.is_a_cache_node and att == 'filepath'):
                        if att == 'mute':
                            if global_vars.nodes_muted_at_beginning_of_playback is not None and n in global_vars.nodes_muted_at_beginning_of_playback:
                                all_attributes.append(('mute',False))
                            else:
                                all_attributes.append((att,val))
                        else:
                            all_attributes.append((att,val))
                    

        #now for links and inputs
        all_node_socket_types = set()
        
        if not (bpy.data.scenes[scene_name].node_tree.nodes[n].type == 'SCALE' and 'quality_node'  in bpy.data.scenes[scene_name].node_tree.nodes[n]) or 'ignore_in_hash' in bpy.data.scenes[scene_name].node_tree.nodes[n]:
            #
            for i in bpy.data.scenes[scene_name].node_tree.nodes[n].inputs:
                if i.links:
                    for link in i.links:
                        if link.from_node.type == 'SCALE' and 'quality_node' in link.from_node: 
                            from_node = link.from_node.inputs[0].links[0].from_node.name
                            from_socket = link.from_node.inputs[0].links[0].from_socket.identifier
                        else:
                            from_node = link.from_node.name
                            from_socket = link.from_socket.identifier
                        all_attributes.append((i.identifier,from_node,from_socket))
                else:
                    
                    try:
                        all_attributes.append((str(bpy.data.scenes[scene_name].node_tree.nodes[n].name).upper(),list(i.default_value)))
                    except:
                        all_attributes.append((str(bpy.data.scenes[scene_name].node_tree.nodes[n].name).upper(),str(i.default_value)))
                
    #print(f'\n{node_name},frame {scene.frame_current}')
    
    #all_attributes.sort()
    sorted = []
    for a in all_attributes:
        sorted.append(hashlib.md5(str(a).encode('ascii')).hexdigest())

    #[hashlib.md5(str(i).encode('ascii')).hexdigest() for i in all_attributes].sort()
    sorted.sort()
    # for s in sorted:
    #     print(s)
    #print('\n\n')
    
    # if node_name == 'Sun Beams.001' and frame == 3:
    #     print('\n\n')
    #     print(node_name,'\n')
    #     for a in all_attributes:
    #         print(a) 
    #     print('\n\n')
    #     print(hashlib.md5(''.join(str(x) for x in sorted).encode('ascii')).hexdigest())
    #     print('\n')

    return hashlib.md5(''.join(str(x) for x in sorted).encode('ascii')).hexdigest()
    #print('\n',all_node_socket_types)
    


#wiring
#----------------------------------------------------------------------------------------------------
def move_links_to_cache_node(cache_node_name, scene_name):
    if 'original' in bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name]:
            original_node_name = bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name]['original']
    else:
        original_node_name = bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].image['original']

    
    
    valid_sockets = [s for s in bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].outputs if s.enabled]# and len(s.links)>0]
    #load_new_exr(cache_node_name,scene_name)
    #if not a new cache node, then it should have temp links from before the links where moved back to the original node.
    if 'temp_links' in bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name]:
        
        stored_links = json.loads(bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name]['temp_links'])
        for link_info in stored_links:
            to_node_name =link_info[0]
            to_socket_id = link_info[1]
            from_socket_name = link_info[2]

            if bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].type == 'R_LAYERS':
                for s in bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].outputs:
                    name_without_prefix = get_original_socket_name_from_cache_socket_name(s.name)
                    if from_socket_name == name_without_prefix:

                        bpy.data.scenes[scene_name].node_tree.links.new(
                                                                                s,
                                                                                bpy.data.scenes[scene_name].node_tree.nodes[to_node_name].inputs[to_socket_id]
                                                                                )                    
            else:

                for socket in valid_sockets:
                    out_socket_on_cache_node = [
                                                x for x in bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].outputs 
                                                if get_original_socket_name_from_cache_socket_name(x.name) == socket.identifier
                                                or (len(x.name)==31 and socket.identifier.startswith(get_original_socket_name_from_cache_socket_name(x.name)))
                                                ]
                    for link in socket.links:
                        if link.to_node.name == to_node_name and get_socket_id_from_socket(link.to_socket) == to_socket_id:
                            bpy.data.scenes[scene_name].node_tree.links.new(
                                                                            bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].outputs[get_socket_id_from_socket(out_socket_on_cache_node[0])],
                                                                            link.to_socket
                                                                            )

                    
        del bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name]['temp_links']
    else:
        
        if bpy.data.scenes[scene_name].node_tree.nodes[original_node_name].type == 'R_LAYERS':

        

            for socket in valid_sockets:
                
                out_socket_on_cache_node = [
                                            x for x in bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].outputs 
                                            if get_original_socket_name_from_cache_socket_name(x.name) == socket.name
                                            or (len(x.name)==31 and socket.name.startswith(get_original_socket_name_from_cache_socket_name(x.name)))
                                        ]

                for link in socket.links:                
                    bpy.data.scenes[scene_name].node_tree.links.new(
                                                                    bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].outputs[get_socket_id_from_socket(out_socket_on_cache_node[0])],
                                                                    link.to_socket
                                                                    )
        else:
            for socket in valid_sockets:
                
                out_socket_on_cache_node = [
                                            x for x in bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].outputs 
                                            if get_original_socket_name_from_cache_socket_name(x.name) == socket.identifier
                                            or (len(x.name)==31 and socket.identifier.startswith(get_original_socket_name_from_cache_socket_name(x.name)))
                                        ]

                for link in socket.links:                
                    bpy.data.scenes[scene_name].node_tree.links.new(
                                                                    bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].outputs[get_socket_id_from_socket(out_socket_on_cache_node[0])],
                                                                    link.to_socket
                                                                    )


def move_links_from_cache_node_to_original_node(cache_node_name,scene_name):
    
    
    original_node = get_original_node_name_from_cache_node(scene_name,cache_node_name)
    
    wired_sockets_on_cache = [s for s in bpy.data.scenes[scene_name].node_tree.nodes[cache_node_name].outputs if len(s.links)>0]

    for out_socket in wired_sockets_on_cache:

        if bpy.data.scenes[scene_name].node_tree.nodes[original_node].type == 'R_LAYERS':
            
            out_socket_on_original_node = [x for x in bpy.data.scenes[scene_name].node_tree.nodes[original_node].outputs 
                                        if get_original_socket_name_from_cache_socket_name(out_socket.name) == x.name
        
                                        or (len(out_socket.name)==31 and out_socket.identifier.startswith(get_original_socket_name_from_cache_socket_name(out_socket.name)))]
            if not out_socket_on_original_node: #the cache node was created with an old version that used the socket identifier for render layer nodes.  compare with the idnetifier instead.
                out_socket_on_original_node = [x for x in bpy.data.scenes[scene_name].node_tree.nodes[original_node].outputs 
                                            if get_original_socket_name_from_cache_socket_name(out_socket.name) == x.identifier
            
                                            or (len(out_socket.name)==31 and out_socket.identifier.startswith(get_original_socket_name_from_cache_socket_name(out_socket.name)))]
        else:
            out_socket_on_original_node = [x for x in bpy.data.scenes[scene_name].node_tree.nodes[original_node].outputs 
                                            if get_original_socket_name_from_cache_socket_name(out_socket.name) == x.identifier
            
                                            or (len(out_socket.name)==31 and out_socket.identifier.startswith(get_original_socket_name_from_cache_socket_name(out_socket.name)))]

        if out_socket_on_original_node:
            for link in out_socket.links:
                bpy.data.scenes[scene_name].node_tree.links.new(
                                        bpy.data.scenes[scene_name].node_tree.nodes[original_node].outputs[get_socket_id_from_socket(out_socket_on_original_node[0])],
                                        link.to_socket
                                        )
        else:
            store_error(scene_name,f"original node {original_node} has been modified and is now missing outputs which the cache node has, check the tree as links have been lost")



#storage
#------------------------------------------------------------------------------------------------------------------

def store_link_list_in_cache_node(cache_node,scene_name):
    
    link_list = []
    for output in bpy.data.scenes[scene_name].node_tree.nodes[cache_node].outputs:
        for link in output.links:
            to_socket_id = get_socket_id_from_socket(link.to_socket)
            link_list.append([link.to_node.name,to_socket_id, get_original_socket_name_from_cache_socket_name(output.name)]) 
    
    bpy.data.scenes[scene_name].node_tree.nodes[cache_node]['temp_links'] = json.dumps(link_list)


def append_hash_to_exr_and_update_image_datablock(scene_name, cache_nodes):
    '''appends hash to the exr of standard cache nodes, not render layer cache nodes'''
    
    done = set()
    for n in cache_nodes:
        # now that all cache nodes are updated, append hash to exr filenames .  no ned to delete anything this would have been don in the previous loop.
        frame = bpy.data.scenes[scene_name].frame_current
        
        if bpy.data.scenes[scene_name].node_tree.nodes[n].image.name in done:
            continue
        if bpy.data.scenes[scene_name].node_tree.nodes[n].mute == True:
            old_path = bpy.data.scenes[scene_name].node_tree.nodes[n].image['temp_path']
        else:
            old_path = bpy.data.scenes[scene_name].node_tree.nodes[n].image.filepath        
        original_name = get_original_node_name_from_cache_node(scene_name,n)
        new_exr_path = file_system_helpers.get_cache_file_path_from_original_node_name(scene_name,original_name)
        new_exr_path = f'{new_exr_path}{str(frame).zfill(4)}.exr'

        #rename the original file
        file_system_helpers.rename_file(old_path,new_exr_path)
        if bpy.data.scenes[scene_name].node_tree.nodes[n].mute == True:
            bpy.data.scenes[scene_name].node_tree.nodes[n].image['temp_path'] = new_exr_path
        else:
            bpy.data.scenes[scene_name].node_tree.nodes[n].image.filepath = new_exr_path
        done.add(bpy.data.scenes[scene_name].node_tree.nodes[n].image.name)

def add_scale_crop_between_file_output_and_original(scene_name,file_output_node_name):
    
    
    
    user_x_res = bpy.data.scenes[scene_name].render.resolution_x
    user_y_res = bpy.data.scenes[scene_name].render.resolution_y
    if 'cache_resolution' in bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name]:
        cache_percent = bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name]['cache_resolution']
    else:
        cache_percent = bpy.data.scenes[scene_name].Standard_Cache_Resolution
    new_x = user_x_res * (cache_percent/100)
    new_y = user_y_res * (cache_percent/100)
    each_side = (1 - (cache_percent/100)) /2
    
    file_output_node = bpy.data.scenes[scene_name].node_tree.nodes[file_output_node_name]
    location = file_output_node.location
    for sock in file_output_node.inputs:
        for link in sock.links:
            original_from = link.from_socket

            #create viewer node to make sure 
            upscale = bpy.data.scenes[scene_name].node_tree.nodes.new('CompositorNodeScale')
            upscale.space = 'RENDER_SIZE'
            upscale.label = 'Caching'
            upscale.location = location#(file_output_node.location.x +200,file_output_node.location.y)
            upscale.frame_method = 'FIT'
            upscale.hide = True
            global_vars.remove_after_cache.add(upscale.name)
             #create crop node
            crop = bpy.data.scenes[scene_name].node_tree.nodes.new('CompositorNodeCrop')
            crop.location = location#(file_output_node.location.x -200,file_output_node.location.y)
            crop.relative = True
            crop.use_crop_size = True
            crop.hide = True
            crop.rel_min_x = 0 + each_side
            crop.rel_max_x = 1 - each_side
            crop.rel_min_y = 1 - each_side
            crop.rel_max_y = 0 + each_side
            global_vars.remove_after_cache.add(crop.name)
            crop['ignore_in_hash'] = True

           #create scale node
            scale = bpy.data.scenes[scene_name].node_tree.nodes.new('CompositorNodeScale')
            scale.location = location#(crop.location.x - 200, crop.location.y)
            scale['ignore_in_hash'] = True
            scale.label = 'Caching'
            scale.space = 'RELATIVE'
            scale.inputs['X'].default_value = cache_percent/100
            scale.inputs['Y'].default_value = cache_percent/100
            scale.hide = True
            global_vars.remove_after_cache.add(scale.name)

            #link fout to crop
            
            bpy.data.scenes[scene_name].node_tree.links.new(crop.outputs[0], sock)
            bpy.data.scenes[scene_name].node_tree.links.new(scale.outputs[0],crop.inputs[0])
            bpy.data.scenes[scene_name].node_tree.links.new(upscale.outputs[0],scale.inputs[0])
            bpy.data.scenes[scene_name].node_tree.links.new(original_from,upscale.inputs[0])





def create_quality_node(scene_name,selected_node_names,make_space = True):
    
    
    quality_nodes_created = set()
    
    for n in selected_node_names:
        
    
        node_height = bpy.data.scenes[scene_name].node_tree.nodes[n].height
        socket_count = len(bpy.data.scenes[scene_name].node_tree.nodes[n].inputs)
        
        for index,socket in enumerate(bpy.data.scenes[scene_name].node_tree.nodes[n].inputs):
            if socket.links:            
                for link in socket.links:
                    from_socket = link.from_socket
            
                    scale = bpy.data.scenes[scene_name].node_tree.nodes.new('CompositorNodeScale')
                    scale.location = (bpy.data.scenes[scene_name].node_tree.nodes[n].location.x,bpy.data.scenes[scene_name].node_tree.nodes[n].location.y - (node_height / socket_count) - (index * 40))
                    scale.space = 'RENDER_SIZE'
                    quality_nodes_created.add(scale.name)
                    scale.color = (0,1,0)
                    scale['quality_node'] = True
                    scale.show_options = False
                    scale.width = 170
                    scale.hide = True

                    bpy.data.scenes[scene_name].node_tree.links.new(
                                                        from_socket,
                                                        scale.inputs[0]
                                                        )
                    
                    bpy.data.scenes[scene_name].node_tree.links.new(
                                                        scale.outputs[0],
                                                        link.to_socket
                                                        )

        
                    scale.label = f'resize node'
                    bpy.data.scenes[scene_name]['user_playback_render_percentage'] = 20

        if make_space:
        #move other nodes to the right
            nodes_to_move,cache = node_helpers.get_upstream_nodes(n,scene_name)
            nodes_to_move.add(n)
            #nodes_to_move = [n for n in nodes if n.location.x >= bpy.data.scenes[scene_name].node_tree.nodes[n].location.x and n.name != scale.name]
            for nm in nodes_to_move:
                bpy.data.scenes[scene_name].node_tree.nodes[nm].location.x += 200
        bpy.data.scenes[scene_name].node_tree.nodes[n].select = False

    return quality_nodes_created


def remove_quality_nodes(scene_name,quality_node_names):
    #nodes = bpy.data.scenes[scene_name].node_tree.nodes
    for n in quality_node_names:
        
        to_socket =  bpy.data.scenes[scene_name].node_tree.nodes[n].outputs[0].links[0].to_socket
        for i in  bpy.data.scenes[scene_name].node_tree.nodes[n].inputs:
            for l in i.links:
                bpy.data.scenes[scene_name].node_tree.links.new( l.from_socket,to_socket)
        bpy.data.scenes[scene_name].node_tree.nodes.remove( bpy.data.scenes[scene_name].node_tree.nodes[n])


    


def update_rl_cache_nodes_from_temp_path_variable(scene_name):
    rl_cache_nodes = node_helpers.get_all_render_layer_cache_nodes(scene_name)
    for rl in rl_cache_nodes:
        if bpy.data.scenes[scene_name].node_tree.nodes[rl].image and 'temp_path' in bpy.data.scenes[scene_name].node_tree.nodes[rl].image:
            bpy.data.scenes[scene_name].node_tree.nodes[rl].image.filepath = bpy.data.scenes[scene_name].node_tree.nodes[rl].image['temp_path']
            do_cache_render(scene_name,False)
        else:
            store_error(scene_name,"some render layer cache nodes couln't be updated.  Please refresh manually.")