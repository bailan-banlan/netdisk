from ..dont_register import file_system_helpers
from .import cache_operation_helpers,checks
from ...variables import global_vars
import bpy

def create_render_layer_cache_node_for_render_layer_nodes_that_dont_yet_have_one(scene_name,render_layer_node_names = None):
    """
     creates and wires a render layer cache node for all render layer nodes that don't yet have a cache node. (ignores muted render layers)

     optionally pass in a list of render layer nodes, and then only those will be processed.

     returns False if it fails to cache one of the render layer nodes that doesnt already have a cache.  This will be because there isn't an existing exr for the render layer node, so will need a full f12 render by the user
    """
    #print('in create cache nodes, thread is: ',threading.currentThread().ident)
    
    if render_layer_node_names is None:
        render_layer_node_names = [n.name for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type == 'R_LAYERS' and n.mute == False]
    
    

    render_layer_nodes_with_no_cache_yet = set([rl for rl in render_layer_node_names if not checks.is_already_cached(rl,scene_name)])
    
    for n in render_layer_nodes_with_no_cache_yet:
        
        full_path = file_system_helpers.get_exr(scene_name,n)
          
        if file_system_helpers.file_exists(full_path):
            cache_operation_helpers.create_cache_node_and_wire_up(scene_name,full_path,n)
        else:            
            return False
    
    return True

def move_remaining_render_layer_links_to_the_cache_node_closest_to_the_target_node(scene_name,render_layer_node_names = None):

    """
    there may be a situation where if the socket wasn't on the cache node prior to rendering, ie because a new render layer has been added to the scene, then 
    there will be leftover links from the render layer node.

    This function will search through all render layer nodes that arent muted, and move any links from it to the cache node that's closest on the x axis to the 
    target node.

    Optionally you can pass in a list of render layer nodes, and then just those will be processed.  Handy if when refreshing selected.

    if for any reason the cache node doesn't have a matching socket, then all other render layer nodes will be skipped and the function will return False. True if it makes it to the end.
    """
    #gprint('in move rl links to closest, thread is ',threading.currentThread().ident)
    scene = bpy.data.scenes[scene_name]
    nodes = scene.node_tree.nodes
    if render_layer_node_names is None:        
        render_layer_node_names = [n.name for n in nodes if n.type == 'R_LAYERS' and n.mute == False and checks.node_has_linked_outputs(n.name,scene_name)]
    
    for rl_name in render_layer_node_names:
        
        all_cache_nodes_for_this_render_layer_node = cache_operation_helpers.get_all_cache_nodes_for_this_node(scene_name,rl_name,get_muted=False)
        
        wired_sockets = [socket for socket in nodes[rl_name].outputs if len(socket.links)>0]
        for socket in wired_sockets:
            for link in socket.links:
                to_node = link.to_node
                to_node_x_position = to_node.location.x                
                
                #get all cache nodes to the left of the to node
                left_cache_nodes = [lc for lc in all_cache_nodes_for_this_render_layer_node if (nodes[lc].location.x + nodes[lc].width) < to_node_x_position]
                closest_cache_node = None
                if not left_cache_nodes:
                    #there are definitely cache nodes at this point, but they must all be to the right of the node we're going to link to so
                    right_cache_nodes = [lc for lc in all_cache_nodes_for_this_render_layer_node if (nodes[lc].location.x + nodes[lc].width) > to_node_x_position]
                    #find the farthest to the left
                    for node_name in right_cache_nodes:
                        n = bpy.data.scenes[scene_name].node_tree.nodes[node_name]
                        if closest_cache_node is None:
                            closest_cache_node = n
                        else:
                            if n.location.x < closest_cache_node.location.x:
                                closest_cache_node = n
                    
                else:
                    #find the farthest to the right
                    for node_name in left_cache_nodes:
                        n = bpy.data.scenes[scene_name].node_tree.nodes[node_name]
                        if closest_cache_node is None:
                            closest_cache_node = n
                        else:
                            if n.location.x > closest_cache_node.location.x:
                                closest_cache_node = n

                try:
                    closest_cache_node_name = closest_cache_node.name
                    
                    out_socket_on_cache_node = [
                                                x for x in closest_cache_node.outputs 
                                                if cache_operation_helpers.get_original_socket_name_from_cache_socket_name(x.name) == socket.name
                                                or (len(x.name)==31 and socket.name.startswith(cache_operation_helpers.get_original_socket_name_from_cache_socket_name(x.name)))
                                               ]

                    
                    bpy.data.scenes[scene_name].node_tree.links.new(
                                                                    closest_cache_node.outputs[cache_operation_helpers.get_socket_id_from_socket(out_socket_on_cache_node[0])],
                                                                    link.to_socket
                                                                    )                    
                    closest_cache_node.select = True
                except:
                    
                    return False
    for rl_name in render_layer_node_names:
        wired_sockets = [socket for socket in nodes[rl_name].outputs if len(socket.links)>0]
        if wired_sockets:
            return False 
    return True




def move_links_from_denoise_node_to_render_layer_node(scene_name):
    #this will need changing if we add denoise after multiply option
    scene = bpy.data.scenes[scene_name]
    nodes = scene.node_tree.nodes
    for denoise_node_name in global_vars.denoise_nodes_to_delete:
        denoise_node = nodes[denoise_node_name]
        from_socket = denoise_node.inputs[0].links[0].from_socket
        for l in denoise_node.outputs[0].links:
            scene.node_tree.links.new(
                                        from_socket,
                                        l.to_socket
                                     )
        nodes.remove(denoise_node)