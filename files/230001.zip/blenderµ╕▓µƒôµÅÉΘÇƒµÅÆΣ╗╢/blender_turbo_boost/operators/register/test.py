import bpy
from ..dont_register import report_custom_error,temporal
from ...variables import global_vars




class ThreeDi_OT_Test(bpy.types.Operator):
    bl_idname = "threedi.test"
    bl_label = "turbo tools test operators"
    bl_description = "test stuff end user shouldnt see this"
    bl_options = {"REGISTER", "UNDO"}
    
    # def invoke(self,context,event):
    #     print('invoked')
    #     return{'INTERFACE'}
    def execute(self,context):
        print('exectute')
        scene = context.scene
        global_vars.reset_all_vars()

        sel = context.selected_nodes
        for s in sel:
            print('type = ',s.type)
        #temporal.set_up_for_temporal(scene.name)
                
        #temporal.append_median_group(scene.name)
            
        #let the user know of any problems after successful completion
        if 'custom_error' in scene and len(scene['custom_error']) > 0:
            report_custom_error.notify_user(scene.name)


        return {'FINISHED'}


    


    

