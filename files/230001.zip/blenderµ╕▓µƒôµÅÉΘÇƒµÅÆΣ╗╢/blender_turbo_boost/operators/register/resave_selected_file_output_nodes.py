
import bpy
from ..dont_register.report_custom_error import store_error,notify_user
from ..dont_register import cache_operation_helpers,checks,cache_operations,file_output_node_operations
from ...variables import global_vars

class ThreeDi_OT_resave_file_output_node(bpy.types.Operator):
    bl_idname = "threedi.clear_resave_file_output_node"
    bl_label = "resave selected (current frame)"
    bl_description = f"resaves the selected file output nodes without having to re-render! Current frame only."
    bl_options = {"REGISTER"}
    

    @classmethod
    def poll(cls,context):
        return (context.space_data.type == 'NODE_EDITOR' and
                context.space_data.tree_type == 'CompositorNodeTree' and not global_vars.playing and not global_vars.rendering)
    
    def execute(self,context):
        
        scene = context.scene
        global_vars.reset_all_vars()
        if checks.comp_is_enabled_in_properties(scene.name):
            selected = bpy.context.selected_nodes
            original_render_editor_type = context.preferences.view.render_display_type
            
            try:
                #global_vars.original_render_window_type = context.preferences.view.render_display_type
                valid_nodes = [n.name for n in selected if n.type == 'OUTPUT_FILE' and not checks.node_has_no_linked_inputs(n.name,scene.name) and n.mute == False]
                if valid_nodes:
                    if file_output_node_operations.prepare_to_resave_selected_file_output_nodes(scene.name,valid_nodes):
                        global_vars.render_type = ['file_output_node']
                        context.preferences.view.render_display_type = 'NONE'
                        cache_operation_helpers.do_cache_render(scene.name,is_cache_render = False,execution='INVOKE_DEFAULT')

                else:
                    store_error(scene.name,"no file output nodes selected (make sure they're not muted)")
            except Exception as e:                          
                
                notify_user(scene.name,messages = [str(e)])
                #print(str(e))
                return {"CANCELLED"}
            
            context.preferences.view.render_display_type = original_render_editor_type
        



        #advise user of issues needing manual attention
        if 'custom_error' in scene and len(scene['custom_error']) > 0:
            notify_user(scene.name)

        return {'FINISHED'}


   


    

