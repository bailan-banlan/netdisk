
import bpy
from ..dont_register.report_custom_error import store_error,notify_user
from ..dont_register import checks,cache_operations
from ...variables import global_vars

class ThreeDi_OT_cache_branch(bpy.types.Operator):
    bl_idname = "threedi.clear_cache_selected"
    bl_label = "Clear cache of selected nodes"
    bl_description = f"removes cache of selected nodes from the cache folder. This is useful if you need to force the cache to be recalculated after changing something outside of the node tree that doesn't automatically trigger a refresh, for example the render resolution or frame start/stop etc."
    bl_options = {"REGISTER", "UNDO"}
    

    @classmethod
    def poll(cls,context):
        return (context.space_data.type == 'NODE_EDITOR' and
                context.space_data.tree_type == 'CompositorNodeTree' and not global_vars.playing and not global_vars.rendering)
    
    def execute(self,context):
        
        scene = context.scene
        selected = bpy.context.selected_nodes

        try:
            valid_nodes = [n.name for n in selected if checks.is_a_non_render_layer_cache_node(n.name,scene.name)]
            if valid_nodes:
                cache_operations.clear_cache_of_selected_nodes(scene.name,valid_nodes)
            else:
                store_error(scene.name,'no cache nodes selected')
        except Exception as e:                          
            
            notify_user(scene.name,messages = [str(e)])
            #print(str(e))
            return {"CANCELLED"}


        #advise user of issues needing manual attention
        if 'custom_error' in scene and len(scene['custom_error']) > 0:
            notify_user(scene.name)

        return {'FINISHED'}


   


    

