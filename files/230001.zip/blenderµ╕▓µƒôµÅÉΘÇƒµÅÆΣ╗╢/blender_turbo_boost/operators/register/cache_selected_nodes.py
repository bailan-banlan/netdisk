from ..dont_register.cache_operations import cache, uncache,checks
import bpy
from ..dont_register import report_custom_error
from ...variables import global_vars

class ThreeDi_OT_cache_branch(bpy.types.Operator):
    bl_idname = "threedi.cache_comp_branch"
    bl_label = "Cache/Uncache"
    bl_description = "make the compositor rapid by caching all nodes downstream from the selected nodes."
    bl_options = {"REGISTER", "UNDO_GROUPED"}
    

    @classmethod
    def poll(cls,context):
        return (context.space_data.type == 'NODE_EDITOR' and
                context.space_data.tree_type == 'CompositorNodeTree' and not global_vars.playing and not global_vars.rendering)
    
    def execute(self,context):
        scene = context.scene
        if not global_vars.playing:
            global_vars.reset_all_vars()
            
            if checks.comp_is_enabled_in_properties(scene.name):
            
                nodes = scene.node_tree.nodes
                sel =  context.selected_nodes
                
                try:
                    nodes_to_cache = [n.name for n in sel if checks.can_be_cached(n.name,scene.name)]
                    nodes_to_uncache = [n.name for n in sel 
                                        if n.name not in nodes_to_cache
                                        and checks.can_be_uncached(n.name,scene.name)]
                    if nodes_to_cache:
                        cache(nodes_to_cache,scene.name)
                    if nodes_to_uncache:
                        uncache(nodes_to_uncache,scene.name)
                except Exception as e:                          
                    
                    report_custom_error.notify_user(scene.name,messages = [str(e)])
                    #print(str(e))
                    return {"CANCELLED"}
        else:
            report_custom_error.store_error(scene.name,'stop playback before caching')



        #advise user of issues needing manual attention
        if 'custom_error' in scene and len(scene['custom_error']) > 0:
            report_custom_error.notify_user(scene.name)

        return {'FINISHED'}


   


    

