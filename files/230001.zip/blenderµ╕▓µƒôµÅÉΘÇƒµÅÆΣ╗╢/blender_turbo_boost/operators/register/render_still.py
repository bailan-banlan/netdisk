import bpy
from ..dont_register import checks,report_custom_error,render_operations
from ...variables import global_vars

# import OpenEXR
# import imghdr


class ThreeDi_OT_render_still(bpy.types.Operator):
    bl_idname = "threedi.render_still"
    bl_label = "turbo tools render still image"
    bl_description = "renders a still image using turbo tools"
    bl_options = {"REGISTER", "UNDO"}

    write_still : bpy.props.BoolProperty(default=False)
    

    def execute(self,context):
        scene = context.scene
        global_vars.reset_all_vars()
                
        if checks.can_be_rendered(context.scene.name):
            render_operations.render_setup_pre(scene.name)
            global_vars.render_type = ['turbo_comp']
            bpy.ops.render.render("INVOKE_DEFAULT",animation=False,use_viewport=True,write_still=self.write_still)
            
        #let the user know of any problems after successful completion
        if 'custom_error' in scene and len(scene['custom_error']) > 0:
            report_custom_error.notify_user(scene.name)


        return {'FINISHED'}


   


    

