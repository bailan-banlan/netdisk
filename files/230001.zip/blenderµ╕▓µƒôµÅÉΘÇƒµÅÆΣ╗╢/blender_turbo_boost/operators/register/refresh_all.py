from ..dont_register import report_custom_error
from ..dont_register.cache_operations import refresh_all
from ..dont_register import checks
from ...variables import global_vars
import bpy


class ThreeDi_OT_refresh_cache_nodes(bpy.types.Operator):
    bl_idname = "threedi.refresh_cache_nodes"
    bl_label = "refreshes all cache nodes"
    bl_description = "all cached nodes in the current scenes compositor will be updated\n\n"\
        "Only refreshes the current frame.  To refresh all frames select the cache nodes you want to be refreshed, click 'clear cache of selected' (below) and then start playback.  " \
            "During playback all cache nodes with missing cache or out of date cache will be recalculated"
    bl_options = {"REGISTER", "UNDO"}
    

    @classmethod
    def poll(cls,context):
        if context.space_data is not None:
            return (context.space_data.type == 'NODE_EDITOR' and
                context.space_data.tree_type == 'CompositorNodeTree' and not global_vars.playing and not global_vars.rendering)
        else:
            return True
    
    
    def execute(self,context):
        scene = context.scene
        if not global_vars.playing:
            global_vars.reset_all_vars()
            
            
            if checks.comp_is_enabled_in_properties(scene.name):
                try:
                    if checks.all_can_be_refreshed(scene.name):
                        refresh_all(scene.name)
                    else:
                        report_custom_error.notify_user(scene.name,[f"There is a problem preventing the cache from being refreshed"])
                    
                    
                except Exception as e:
                    report_custom_error.store_error(scene.name,str(e))            
                    report_custom_error.store_error(scene.name,'check there isn\'t a scene without a camera that has a render layer node in this compositor')
                    report_custom_error.notify_user(scene.name)
                    return {"CANCELLED"}
                
                finally:
                    #unmute the file output nodes we muted for the refresh
                    pass
        else:
            report_custom_error.store_error(scene.name,'can\'t refresh during playback, stop playback or turn on validate cache to automatically refresh cache during playback')
        #let the user know of any problems after successful completion
        if 'custom_error' in scene and len(scene['custom_error']) > 0:
            report_custom_error.notify_user(scene.name)


        return {'FINISHED'}