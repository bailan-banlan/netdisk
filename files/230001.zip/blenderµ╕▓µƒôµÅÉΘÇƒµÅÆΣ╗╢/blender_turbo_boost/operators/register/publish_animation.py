from ..dont_register.cache_operations import cache, uncache
from ..dont_register.checks import can_be_published, can_be_uncached, is_already_cached,can_be_cached
from ..dont_register import publish_operations,cache_operation_helpers
import bpy
from ..dont_register import report_custom_error
from ...variables import global_vars

class ThreeDi_OT_cache_branch(bpy.types.Operator):
    bl_idname = "threedi.compositor_publish_animation"
    bl_label = "publish animation"
    bl_description = "Temporarily disables all cache and publishes the full quality animation to the location/format specified in Blenders output section of the properties panel."
    bl_options = {"REGISTER", "UNDO_GROUPED"}
    

    @classmethod
    def poll(cls,context):
        return (context.space_data.type == 'NODE_EDITOR' and
                context.space_data.tree_type == 'CompositorNodeTree' and  not global_vars.playing and not global_vars.rendering)
    
    def execute(self,context):
        
        scene = context.scene
        if not global_vars.playing:
            global_vars.reset_all_vars()

            try:
                if can_be_published(scene.name,publish_type='anim'):
                    if publish_operations.set_up_pre_publish(scene.name,True):
                        global_vars.render_type = ['publish']
                        cache_operation_helpers.do_cache_render(scene.name,is_cache_render = False,execution='INVOKE_DEFAULT',anim=True)
                    else:
                        publish_operations.post_publish(scene.name)
                
            except Exception as e:                          
                print(e)
                report_custom_error.notify_user(scene.name,messages = [str(e)])
                #print(str(e))
                return {"CANCELLED"}
        else:
            report_custom_error.store_error(scene.name,'can\'t publish during playback.  Stop the timeline and retry')

        #advise user of issues needing manual attention
        if 'custom_error' in scene and len(scene['custom_error']) > 0:
            report_custom_error.notify_user(scene.name)

        return {'FINISHED'}


   


    

