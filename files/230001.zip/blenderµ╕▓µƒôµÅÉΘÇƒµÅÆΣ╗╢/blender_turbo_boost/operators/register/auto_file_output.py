import bpy
from ...variables import global_vars
from .. dont_register import file_system_helpers,report_custom_error,cache_operation_helpers
#from ...variables import global_vars
import threading

class ThreeDi_OT_auto_file_output(bpy.types.Operator):
    bl_idname = "threedi.auto_file_output"
    bl_label = "solidify"
    bl_description = "creates file output node and automatically wires it to the selected node"
    bl_options = {"REGISTER", "UNDO"}
    
    
    @classmethod
    def poll(cls,context):
        return (context.space_data.type == 'NODE_EDITOR' and
                context.space_data.tree_type == 'CompositorNodeTree'  and not global_vars.playing and not global_vars.rendering)

    
    # #Directory : StringProperty(name='Directory',default = f'//EXR/{file_system_helpers.blend_file_name()}/')
    
    # def draw(self,context):
    #     layout = self.layout
    #     row = layout.row()
    #     row.prop(self,'Directory')
    
    #this is no longer used as it became messy.  Now the file output node is placed at a set location from the selected node rather than at the cursor.
    def invoke(self, context, event):
        region = context.region.view2d  
        ui_scale = context.preferences.system.ui_scale     
        x, y = region.region_to_view(event.mouse_region_x, event.mouse_region_y)
        self.x,self.y = x /ui_scale,y/ui_scale
        return self.execute(context)

    def execute(self,context):
        
        scene = context.scene
        nodes = scene.node_tree.nodes       
        global_vars.reset_all_vars()
        

        try:
            selected_nodes = bpy.context.selected_nodes
            valid_nodes = [n.name for n in selected_nodes if len([output for output in n.outputs if output.enabled == True]) > 0 ]
            
            if not valid_nodes:
                report_custom_error.store_error(scene.name,'no valid nodes selected, make sure all selected nodes have output sockets!')

            #loop through all selected nodes and set up the file output
            for node_name in valid_nodes:
                blend_file = bpy.path.clean_name(file_system_helpers.blend_file_name())
                directory = f'//file_output_node_images/{blend_file}'
                selected_node = nodes[node_name]
                
                if selected_node.type == 'R_LAYERS':
                    rl_scene_name = bpy.path.clean_name(selected_node.scene.name)
                    rl_layer = bpy.path.clean_name(selected_node.layer)
                    active_cam = bpy.path.clean_name(selected_node.scene.camera.name)
                    partial_path = file_system_helpers.get_safe_path(f"{directory}/render_layers_node-{rl_scene_name}-{rl_layer}-{active_cam}-")                
                else:
                    active_cam = bpy.path.clean_name(scene.camera.name)
                    if selected_node.label == '':
                        monika = selected_node.name
                    else:
                        monika = selected_node.label
                    partial_path = file_system_helpers.get_safe_path(f'{directory}/{bpy.path.clean_name(monika)}/')
                pos = None
                # if len(valid_nodes) == 1:
                #     pos = (self.x,self.y)
                f_node_name = cache_operation_helpers.create_and_wire_file_output(scene.name,node_name, pos, partial_path,False,image_format=scene.file_out_format,only_linked=scene.only_linked)
                selected_node.select = False
                nodes[f_node_name].select = True
            
           
        except Exception as e:
            report_custom_error.store_error(scene.name,str(e))            
            report_custom_error.notify_user(scene.name)
            return {"CANCELLED"}        
        
        #let the user know of any problems after successful completion
        if 'custom_error' in scene and len(scene['custom_error']) > 0:
            report_custom_error.notify_user(scene.name)


        return {'FINISHED'}

   


    

