
import bpy
from ..dont_register.report_custom_error import store_error,notify_user
from ..dont_register import cache_operation_helpers,checks,cache_operations

class ThreeDi_OT_combine_render_passes(bpy.types.Operator):
    bl_idname = "threedi.combine_render_passes"
    bl_label = "Combine render passes"
    bl_description = f"Combines active render passes to make final image.  Works from any selected node that has outputs containing the pass names (diffuse indirect, diffuse direct, diffuse colour, etc."
    bl_options = {"REGISTER", "UNDO"}
    

    @classmethod
    def poll(cls,context):
        return (context.space_data.type == 'NODE_EDITOR' and
                context.space_data.tree_type == 'CompositorNodeTree')
    
    def execute(self,context):
        
        scene = context.scene
        selected = bpy.context.selected_nodes

        try:
            #node has wired up sockets


            valid_nodes = [n.name for n in selected if checks.is_a_non_render_layer_cache_node(n.name,scene.name)]
            if valid_nodes:
                cache_operations.clear_cache_of_selected_nodes(scene.name,valid_nodes)
            else:
                store_error(scene.name,'no cache nodes selected')
        except Exception as e:                          
            
            notify_user(scene.name,messages = [str(e)])
            #print(str(e))
            return {"CANCELLED"}


        #advise user of issues needing manual attention
        if 'custom_error' in scene and len(scene['custom_error']) > 0:
            notify_user(scene.name)

        return {'FINISHED'}


   


    

