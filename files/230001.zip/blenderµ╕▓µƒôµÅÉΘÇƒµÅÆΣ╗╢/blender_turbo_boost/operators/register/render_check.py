import bpy
from ..dont_register import checks,report_custom_error,scene_helpers
import threading
from ...variables import global_vars

class ThreeDi_OT_render_check(bpy.types.Operator):
    bl_idname = "threedi.render_check"
    bl_label = "checks the cache can be temporarily uncached during rendering"
    bl_description = "checks that the cache can be temporarily removed to ensure correct render result"
    bl_options = {"REGISTER", "UNDO"}
    
    
    def execute(self,context):
        scene = context.scene
        print('keep cache =',scene.Keep_Cache)
        print('Main Thread = ',threading.currentThread().ident)
        scene_helpers.update_node_tree_without_caching(scene.name)
 
        if checks.can_be_rendered(context.scene.name):
            report_custom_error.notify_user(scene.name,[f"No problems found. Go forth and render!"])        
        else:
            report_custom_error.notify_user(scene.name,['Problems found, please fix before rendering'],"OH NO!",'ERROR')


        #let the user know of any problems after successful completion
        if 'custom_error' in scene and len(scene['custom_error']) > 0:
            report_custom_error.notify_user(scene.name)


        return {'FINISHED'}


   


    

