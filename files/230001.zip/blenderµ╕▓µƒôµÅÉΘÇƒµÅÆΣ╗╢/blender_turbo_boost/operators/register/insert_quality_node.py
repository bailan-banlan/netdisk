
import bpy
from ..dont_register.report_custom_error import store_error,notify_user
from ..dont_register import cache_operation_helpers,checks

class ThreeDi_OT_cache_branch(bpy.types.Operator):
    bl_idname = "threedi.add_quality_node"
    bl_label = "Insert Cache Rescale Node"
    bl_description = f"Adds a scale node before the selected node to resize preceeding lower resolution cache nodes back to the render resolution. \n\n These are ignored during rendering, publishing (unless quick publish is enabled) and the resave options found in the file output node section above "\
        "(Use a standard Blender scale node if you want it to affect those tasks).\n\n WARNING - scale nodes may crash blender if they receive 4k data or above, use with low resolution cache nodes only.  They can also "\
            'drastically reduce performance, so always manually increase the backdrop size instead where possible.'
    bl_options = {"REGISTER", "UNDO"}
    

    @classmethod
    def poll(cls,context):
        return (context.space_data.type == 'NODE_EDITOR' and
                context.space_data.tree_type == 'CompositorNodeTree')
    
    def execute(self,context):
        
        scene = context.scene
        selected = bpy.context.selected_nodes

        try:
            valid_nodes = [n.name for n in selected if not checks.node_has_no_linked_inputs(n.name,scene.name)]
            if valid_nodes:
                cache_operation_helpers.create_quality_node(scene.name,valid_nodes)
            else:
                store_error(scene.name,'selected node has no valid linked inputs')
        except Exception as e:                          
            
            notify_user(scene.name,messages = [str(e)])
            #print(str(e))
            return {"CANCELLED"}


        #advise user of issues needing manual attention
        if 'custom_error' in scene and len(scene['custom_error']) > 0:
            notify_user(scene.name)

        return {'FINISHED'}


   


    

