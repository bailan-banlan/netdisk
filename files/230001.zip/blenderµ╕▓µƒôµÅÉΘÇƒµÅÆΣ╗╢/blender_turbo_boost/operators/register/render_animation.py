import bpy

from ..dont_register import checks,report_custom_error, render_operations

from ...variables import global_vars

class ThreeDi_OT_render_animation(bpy.types.Operator):
    bl_idname = "threedi.render_animation"
    bl_label = "turbo tools render animation"
    bl_description = "renders the animation using turbo tools"
    bl_options = {"REGISTER", "UNDO"}
    
    def execute(self,context):
        scene = context.scene
        global_vars.reset_all_vars()
                
        if checks.can_be_rendered(context.scene.name,is_anim=True):
            render_operations.render_setup_pre(scene.name)
            global_vars.render_type = ['turbo_comp']
            bpy.ops.render.render("INVOKE_DEFAULT",animation=True,use_viewport=True)
            #print('just called render.render')
            
        #else:

            #report_custom_error.notify_user(scene.name,['Turbo Tools Message'])


        #let the user know of any problems after successful completion
        if 'custom_error' in scene and len(scene['custom_error']) > 0:
            report_custom_error.notify_user(scene.name)


        return {'FINISHED'}


   


    

