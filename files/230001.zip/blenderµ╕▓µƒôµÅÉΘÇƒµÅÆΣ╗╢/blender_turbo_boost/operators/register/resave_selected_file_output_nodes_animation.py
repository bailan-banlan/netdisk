
import bpy
from ..dont_register.report_custom_error import store_error,notify_user
from ..dont_register import cache_operation_helpers,checks,cache_operations,file_output_node_operations,scene_helpers
from ...variables import global_vars

class ThreeDi_OT_resave_file_output_node(bpy.types.Operator):
    bl_idname = "threedi.clear_resave_file_output_node_animation"
    bl_label = "resave selected (All Frames)"
    bl_description = f"resaves the selected file output nodes without having to re-render! (All Frames)."
    bl_options = {"REGISTER"}
    

    @classmethod
    def poll(cls,context):
        return (context.space_data.type == 'NODE_EDITOR' and
                context.space_data.tree_type == 'CompositorNodeTree' and  not global_vars.playing and not global_vars.rendering)
    

    def invoke(self, context, event):
        

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
        


    def modal(self,context,event):

        scene = context.scene
        if event.type not in {'RIGHTMOUSE','ESC'}:
        
            global_vars.reset_all_vars()
            selected = bpy.context.selected_nodes
            
            if checks.comp_is_enabled_in_properties(scene.name):
                try:
                    global_vars.original_render_window_type = context.preferences.view.render_display_type
                    valid_nodes = [n.name for n in selected if n.type == 'OUTPUT_FILE' and not checks.node_has_no_linked_inputs(n.name,scene.name) and n.mute == False]
                    if valid_nodes:
                        if file_output_node_operations.prepare_to_resave_selected_file_output_nodes(scene.name,valid_nodes):
                            original_frame = scene.frame_current
                            scene.frame_current = scene.frame_start
                            global_vars.render_type = ['file_output_node_anim']
                            #anim_length = (scene.frame_end - scene.frame_start) / scene.frame_step
                            bpy.ops.screen.animation_play(sync = False)
                            
                            
                                
                    else:
                        store_error(scene.name,"no file output nodes selected (make sure they're not muted)")
                except Exception as e:                          
                    if bpy.context.screen.is_animation_playing:
                        bpy.ops.screen.animation_cancel()
                    
                    notify_user(scene.name,messages = [str(e)])
                    #print(str(e))
                    return {"CANCELLED"}
            



            #advise user of issues needing manual attention
            if 'custom_error' in scene and len(scene['custom_error']) > 0:
                notify_user(scene.name)

            return {'FINISHED'}
        
        else:
            file_output_node_operations.put_tree_back_to_original_state(scene.name)
            return {'CANCELLED'}


   


    

