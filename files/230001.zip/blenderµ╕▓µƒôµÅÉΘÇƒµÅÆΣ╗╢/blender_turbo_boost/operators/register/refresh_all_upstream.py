import bpy
from ..dont_register import cache_operations,report_custom_error,checks
from ...variables import global_vars

class ThreeDi_OT_test_shit(bpy.types.Operator):
    bl_idname = "threedi.refresh_all_upstream"
    bl_label = "refresh all upstream"
    bl_description = "refreshes all cache nodes upstream of the selected node.  This is to avoid recalculating other cache nodes that aren't affected by this node \n\n" \
        "Only refreshes the current frame.  To refresh all frames select the cache nodes you want to be refreshed, click 'clear cache of selected' (below) and then start playback." \
            "During playback all cache nodes with missing cache or out of date cache will be recalculated"
    bl_options = {"REGISTER", "UNDO"}

    

    @classmethod
    def poll(cls,context):
        return (context.space_data.type == 'NODE_EDITOR' and
                context.space_data.tree_type == 'CompositorNodeTree' and  not global_vars.playing and not global_vars.rendering)
    
    def execute(self,context):
        scene = context.scene
        if not global_vars.playing:
            global_vars.reset_all_vars()
            selected_nodes = bpy.context.selected_nodes
            if selected_nodes:
                scene = context.scene
                if checks.comp_is_enabled_in_properties(scene.name):
                    nodes = scene.node_tree.nodes        
                    
                    try:
                        selected_node_names = [n.name for n in selected_nodes]
                        if checks.selected_can_be_refreshed(scene.name,selected_node_names):            
                            updated_selected_node_names = [n.name for n in bpy.context.selected_nodes]
                            cache_operations.refresh_selected_and_upstream(updated_selected_node_names,scene.name)#,all_cache_nodes_to_refresh, nodes_not_to_mute, cache_nodes)

                    except Exception as e:
                        report_custom_error.store_error(scene.name,str(e))            
                        report_custom_error.notify_user(scene.name)
                        return {"CANCELLED"}        
                
                
            else:
                
                report_custom_error.store_error(bpy.context.scene.name, "You must select either the cache node you wish to refresh or a node which is downstream of the cache nodes you wish to refresh.")
            
        else:
            report_custom_error.store_error(scene.name,'can\'t refresh during playback, stop playback or turn on validate cache to automatically refresh cache during playback')
        #let the user know of any problems after successful completion
        if 'custom_error' in bpy.context.scene and len(bpy.context.scene['custom_error']) > 0:
            report_custom_error.notify_user(bpy.context.scene.name)
        return {'FINISHED'}
   


    

