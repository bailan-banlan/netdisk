import bpy
from ..operators.dont_register import node_helpers,report_custom_error


def on_load_functions():
    pass
    
    


def check_all_render_layer_node_cache_nodes_have_original_variable(scene_name):
    rl_node_names = node_helpers.get_all_render_layer_cache_nodes(scene_name)
    for rl in rl_node_names:
        if 'original' not in bpy.data.scenes[scene_name].node_tree.nodes[rl]:
            if 'original' not in bpy.data.scenes[scene_name].node_tree.nodes[rl].image:
                report_custom_error.store_error(bpy.context.scene.name,'')


def version_checks():
    scene_names = [s.name for s in bpy.data.scenes]
    for scene_name in scene_names:
        check_all_render_layer_node_cache_nodes_have_original_variable(scene_name)



        

    