#from glob import glob
from ..operators.dont_register import publish_operations
# from ..data import get_data
from ..utils import queue_system
from .. operators.dont_register.checks import there_are_cache_nodes
import bpy
#from bpy import context

from bpy.app.handlers import persistent
#from bpy.types import Depsgraph

from .. operators.dont_register import report_custom_error,scene_helpers,checks,render_operations
from ..operators.dont_register import cache_operation_helpers,file_system_helpers,checks,file_output_node_operations
from ..variables import global_vars



import threading
import traceback 


#import cProfile
# import faulthandler
# import sys

#from ..utils.queue_system import execution_queue

# import faulthandler
# import sys
# #faulthandler.disable()
# faulthandler.enable(file=sys.stderr,all_threads=True)
# faulthandler.dump_traceback_later(timeout=1,repeat=False,file=sys.stderr,exit=False)



def cleanup(scene_name):
    scene = bpy.data.scenes[scene_name]
    if 'last_rendered_frame' in scene:
        del scene['last_rendered_frame']
    if 'rendering' in scene:
        del scene['rendering']
    
    if 'frame_change_handler' in scene:
        del scene['frame_change_handler']

    if 'list_of_render_layer_file_output_nodes' in scene:
        del scene['list_of_render_layer_file_output_nodes']

    if  'list_of_cached_node_file_output_nodes' in scene:
        del scene['list_of_cached_node_file_output_nodes']

    # if 'just finished rendering' in scene:
    #     del scene['just finished rendering']

    if 'all_render_layer_nodes' in scene:
        del scene['all_render_layer_nodes']

    if 'all_cached_node_names' in scene:    
        del scene['all_cached_node_names']

    if 'rl_cache_nodes' in scene:    
        del scene['rl_cache_nodes']

    if 'custom_error' in scene:
        del scene['custom_error']

    if 'file_out_keep' in scene:
        del scene['file_out_keep']

    if 'original_last_cached_frame' in scene:
        del scene['original_last_cached_frame']
    

    global_vars.file_out_keep = None
    global_vars.last_rendered_frame = None
    global_vars.comp_area_zoom_list = None
    global_vars.playing = None
    
    global_vars.nodes_muted_at_beginning_of_playback = None

@persistent    
def my_load(*args):
    pass
    #msg_bus.create_subscriptions()
    # maintenance.check_properties()    
    # get_data.link_all()
    #maintenance.on_load_functions()
    
    


@persistent
def update_on_frame_change_pre_calculations(scene,dep):  
    pass

@persistent
def update_on_frame_change(scene,dep):  
    if 'cache_render' in scene:
        return
    
    if scene.use_nodes and (global_vars.not_frame_change_first_visit is None or global_vars.playing is not None):# 
    
        if 'file_output_node_anim' in global_vars.render_type and 'cache_render' not in scene:
            

            if bpy.context.screen:
                if bpy.context.screen.is_animation_playing and not bpy.context.screen.is_scrubbing:
                    scene_helpers.update_node_tree_and_get_latest_cache_exr(scene.name)
                    cache_operation_helpers.do_cache_render(scene.name,False)
                    if scene.frame_current == scene.frame_end:
                        bpy.ops.screen.animation_cancel(restore_frame=True)
                elif bpy.context.screen.is_scrubbing: 
                    pass
                else:
                    #playback just finished, or user moved direclty to a different frame                                                         
                    file_output_node_operations.put_tree_back_to_original_state(scene.name)
        
        #cache_frame_change(scene.name)
        # cProfile.runctx('scene_helpers.update_node_tree_and_get_latest_cache_exr(scene.name)',globals(),locals())

        

        if there_are_cache_nodes(scene.name) or global_vars.playing is not None:

            if scene.Keep_Cache:
                
                if 'cache_render' not in scene and 'publish' not in global_vars.render_type and 'file_output_node_anim' not in global_vars.render_type  and 'file_output_node' not in global_vars.render_type and 'turbo_comp' not in global_vars.render_type: #removed and 'file_output_node' not in global_vars.render_type
                    if 'rendering' not in scene:# """goes above"
                        if scene_helpers.compositor_is_visible(scene.name):
                            if bpy.context.screen:
                                
                                global_vars.not_frame_change_first_visit = True
                                if bpy.context.screen.is_animation_playing and not bpy.context.screen.is_scrubbing:
                                    if global_vars.playing is None:
                                        #it's the first loop
                                        #avoid access violation caused by there being an unmuted render layer node with no cache.  This causes a recursive render of the actual scene.                                        
                                        if checks.there_is_a_unmuted_render_layer_node_with_no_cache(scene.name,create_missing = False):

                                        # if not checks.is_already_cached(rl_node_name):
                                            bpy.ops.screen.animation_cancel(restore_frame=False)
                                            global_vars.not_frame_change_first_visit = None
                                            report_custom_error.notify_user(scene.name,messages=['there are unmuted render layer nodes with no cache, please refresh all or mute uncached render layer nodes before attempting playback'],title='refresh before playback')
                                            cleanup(scene.name)
                                            return
                                            
                                        
                                        #check a viewer node is selected
                                        if not checks.a_viewer_node_is_selected(scene.name):
                                            #try and select one
                                            v = [n.name for n in bpy.data.scenes[scene.name].node_tree.nodes if n.type =='VIEWER']
                                            if not v or len(v) > 1:                                                
                                                bpy.ops.screen.animation_cancel()
                                                global_vars.not_frame_change_first_visit = None
                                                report_custom_error.notify_user(scene.name,messages=['please select a viewer node before pressing play'],title='select a viewer node')
                                                return
                                            else: scene.node_tree.nodes[v[0]].select = True
                                        global_vars.playing = True
                                        global_vars.first_playback_frame = True                                       
                                        
                                        
                                    
                                    try:
                                        if global_vars.nodes_muted_at_beginning_of_playback is None:
                                            scene_helpers.mute_what_can_be_muted_before_playback(scene.name)
                                        
                                        
                                        
                                        
                                        #cProfile.runctx('scene_helpers.update_node_tree_and_get_latest_cache_exr(scene.name)',globals(),locals())
                                        if not scene_helpers.update_node_tree_and_get_latest_cache_exr(scene.name):

                                            #below commented out as the above function no longer checks that the exr has necessary layers, may re-enable at some point.
                                            # bpy.ops.screen.animation_cancel() 
                                            # #report_custom_error.notify_user(scene.name,['playback cancelled as one of outputs on a cached node is no longer there and would result in links being broken leading to an incorrect result. \n if the problem is on a render layer cache node please re-render making sure you have all the passes enabled that are used in the compositor tree'])
                                            # #report_custom_error.print_stack_after_exception(10)
                                            # # set back to None so it can re-enter the handler
                                            # global_vars.not_frame_change_first_visit = None
                                            # global_vars.playing = None
                                            # scene.frame_current = global_vars.playback_start_frame
                                            pass

                                            #update_comp_fps(scene.name)
                                        
                                    except Exception as e:                                
                                        bpy.ops.screen.animation_cancel() 
                                        report_custom_error.notify_user(scene.name)
                                        #report_custom_error.print_stack_after_exception(10)

                                elif bpy.context.screen.is_scrubbing: 
                                    #false alarm, set back to None so it can re-enter the handler
                                    global_vars.not_frame_change_first_visit = None
                                    pass
                                    
                                else:
                                    #playback just finished, or user moved direclty to a different frame                                                         
                                    try:
                                        #print('hit frame change')
                                        if global_vars.playing is None:
                                            # if not checks.all_links_have_valid_from_sockets(scene.name):
                                            #     bpy.ops.screen.animation_cancel(restore_frame=True)
                                            #     global_vars.not_frame_change_first_visit = None
                                            #     report_custom_error.store_error(scene.name,messages=['there is a cache node that doesnt have sufficient outputs to maintain all links, please re-render that cache node for any frames that you rendered or cached with different passes'],title='playback error')
                                            #     cleanup(scene.name)                                                
                                            
                                            if global_vars.nodes_muted_at_beginning_of_playback is None:
                                                    scene_helpers.mute_what_can_be_muted_before_playback(scene.name)
                                            if checks.all_can_be_refreshed(scene.name,create_missing_cache_nodes = False):                                    
                                                #mute what doesnt need to be calculated
                                                
                                                if not scene_helpers.update_node_tree_and_get_latest_cache_exr(scene.name):#this wont work correctly because the exr wont be correct.  need to do a refresh probably or read the exr before updatng the information.
                                                    pass
                                                    # global_vars.not_frame_change_first_visit = None
                                                    # global_vars.playing = None
                                                    # failed = True
                                                    # if global_vars.playback_start_frame is not None:
                                                    #     scene.frame_current = global_vars.playback_start_frame
                                                    # else:
                                                    #     scene.frame_current = scene.frame_current -1
                                                    # print("new exr has incorrect layer names.  links will be broken")

                                        
                                    except Exception as e:
                                        pass
                                        #print(e)
                                    finally:                                                                                
                                        
                                        if global_vars.nodes_muted_at_beginning_of_playback is not None:
                                            scene_helpers.un_mute_playback_muted_cache_nodes(scene.name,True)
                                        
                                        
                                        if 'custom_errors' in scene:# and not failed :
                                            report_custom_error.notify_user(scene.name)
                                        global_vars.not_frame_change_first_visit = None
                                        cleanup(scene.name)
           
        else:
            
            if scene_helpers.compositor_is_visible(scene.name) and 'cache_render' not in scene and not [n for n in scene.node_tree.nodes if n.type == 'R_LAYERS' and n.mute == False]:
                cache_operation_helpers.do_cache_render(scene.name,False)

#lock = threading.Lock()

@persistent #render_init handler
def pre_render_job(scene):    
   
    pass
            
   
#this will happend after the render and the frame will be reported as the frame the ui was on before rendering rather than the last frame of rendering
@persistent
def post_render_job(scene):
    #print('post render handler')
    
    #breakpoint()
    #if 'cache_render' not in scene and 'frame_change_render' not in scene:
    if 'turbo_comp' in global_vars.render_type:
        if not global_vars.was_cancelled:
            #print('in post render handler')
            queue_system.add_function_to_queue([render_operations.render_post,scene.name])
            queue_system.register_timer()        
    
    if 'file_output_node' in global_vars.render_type:
        queue_system.add_function_to_queue([file_output_node_operations.put_tree_back_to_original_state,scene.name])
        queue_system.register_timer()        
        print('file_output_completed courtesy of Turbo Tools')

    if 'publish' in global_vars.render_type:
        
        queue_system.add_function_to_queue([publish_operations.post_publish,scene.name])
        queue_system.register_timer()   
        #print('publish_completed')

    if 'temporal' in global_vars.render_type:
        pass

        
    

@persistent
def render_job_cancelled(scene):
    
    if 'turbo_comp' in global_vars.render_type:
        #breakpoint()
        #print('in cancelled handler')
        if global_vars.last_rendered_frame is not None and not scene.Keep_Cache:
            del_last_frame(scene.name,global_vars.last_rendered_frame)
        queue_system.add_function_to_queue([render_operations.render_job_cancelled,scene.name])
        queue_system.register_timer()
        
        global_vars.was_cancelled = True

        # queue_system.add_function_to_queue([render_operations.render_post,scene.name])
        # queue_system.register_timer()        
    

    if 'file_output_node' in global_vars.render_type:
        queue_system.add_function_to_queue([file_output_node_operations.put_tree_back_to_original_state,scene.name])
        queue_system.register_timer()   
        #print('file output cancelled')

    if 'publish' in global_vars.render_type:
        queue_system.add_function_to_queue([publish_operations.post_publish,scene.name])
        queue_system.register_timer()   
        #print('publish cancelled')

from ..operators.dont_register import temporal

@persistent
def render_pre(scene):
    
    
    
    if 'publish' in global_vars.render_type:# and scene.QuickPublish:
        #breakpoint()
        #cProfile.runctx('scene_helpers.update_exr_during_publish(scene.name)',globals(),locals())
        scene_helpers.update_exr_during_publish(scene.name)

        # temporal_nodes = [n.name for n in bpy.data.scenes[scene.name].node_tree.nodes if 'temporal_parent' in n]
        # for n in temporal_nodes:
            
        #     print(bpy.data.scenes[scene.name].node_tree.nodes[n].label)
        #     print(bpy.data.scenes[scene.name].node_tree.nodes[n].image.filepath)
        #     print(bpy.data.scenes[scene.name].frame_current)
    
#this will report the actual last frame or rendering

def del_last_frame(scene_name,frame_to_delete):
    #breakpoint()
    if global_vars.last_rendered_frame is not None: #we've rendered at least one frame during this animation render
        #if global_vars.original_last_cached_frame != global_vars.last_rendered_frame:
        all_matching_files = []
        filepaths = [n.base_path[:-1] for n in bpy.data.scenes[scene_name].node_tree.nodes if n.type =='OUTPUT_FILE' and n.name not in global_vars.file_out_keep] #this gets all file output nodes created for caching purpsoes in pre render setup
        for f in filepaths:
            all_matching_files.extend(file_system_helpers.get_files(f'{f}*_{str(frame_to_delete).zfill(4)}.exr'))
            
            
        for f in all_matching_files:                        
            if f not in global_vars.cache_exrs_in_use_before_animation_render:
                file_system_helpers.delete_file(f,scene_name)

def del_cache_exrs_in_use_before_animation_render(scene_name):
    pass


@persistent
def render_post(scene):
    #breakpoint()
    if 'cache_render' not in scene:
        
        if 'turbo_comp' in global_vars.render_type:
            global_vars.last_rendered_frame = scene.frame_current            
            #print("global vars = ",global_vars.last_rendered_frame)
            if not scene.Keep_Cache:
                del_last_frame(scene.name,(scene.frame_current -1))
                
            
        #WHAT THE HELL IS THIS FOR?!
        # if 'publish' in global_vars.render_type and scene.QuickPublish:
        #     standard_cache = node_helpers.get_all_standard_cache_nodes(scene.name)
        #     for n in standard_cache:
                
        #         cache_operation_helpers.move_links_to_cache_node(n,scene.name)
                

# @persistent
# def desgraph_post(poop,deps):
    
#     try:
#         scene_name = deps.scene_eval.name
#         #tests.hash_downstream(deps.scene_eval.name)
#         cache_operation_helpers.get_hash_of_the_all_downstream_attributes_combined(scene_name)
#         #tests.get_non_inherited_props(scene_name,bpy.context.active_node.name)
#         # wm = bpy.context.window_manager
#         # last_undo = str(wm.print_undo_steps())
#         # print('last undo is', last_undo)

#         # #deps = bpy.context.evaluated_get()
#         # for u in deps.updates:
#         #     print(u.id.original.name)
#         # # context = bpy.context
#         # # print(bpy.context.active_node)
#         # # print(context.space_data.type)
#         # # print ("Node name:", context.active_node.name)
#     except Exception as e:
#         print(e)
#         print('context is not a node tree')


def register_handler():
    if update_on_frame_change_pre_calculations not in bpy.app.handlers.frame_change_pre:
        bpy.app.handlers.frame_change_pre.append(update_on_frame_change_pre_calculations)
    
    if update_on_frame_change not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(update_on_frame_change)

    if my_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(my_load)

    if pre_render_job not in bpy.app.handlers.render_init:
        bpy.app.handlers.render_init.append(pre_render_job)

    if post_render_job not in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.append(post_render_job)

    if render_job_cancelled not in bpy.app.handlers.render_cancel:
        bpy.app.handlers.render_cancel.append(render_job_cancelled)

    if render_pre not in bpy.app.handlers.render_pre:
        bpy.app.handlers.render_pre.append(render_pre)

    if render_post not in bpy.app.handlers.render_post:
        bpy.app.handlers.render_post.append(render_post)
    
    # if desgraph_post not in bpy.app.handlers.depsgraph_update_post:
    #     bpy.app.handlers.depsgraph_update_post.append(desgraph_post)
    
def unregister_handler():
    if update_on_frame_change_pre_calculations in bpy.app.handlers.frame_change_pre:
        bpy.app.handlers.frame_change_pre.remove(update_on_frame_change_pre_calculations)
    if update_on_frame_change in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(update_on_frame_change)
    if my_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(my_load)

    if pre_render_job in bpy.app.handlers.render_init:
        bpy.app.handlers.render_init.remove(pre_render_job)

    if post_render_job in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.remove(post_render_job)

    if render_job_cancelled in bpy.app.handlers.render_cancel:
        bpy.app.handlers.render_cancel.remove(render_job_cancelled)

    if render_pre in bpy.app.handlers.render_pre:
        bpy.app.handlers.render_pre.remove(render_pre)

    if render_post in bpy.app.handlers.render_post:
        bpy.app.handlers.render_post.remove(render_post)
        
    # if desgraph_post in bpy.app.handlers.depsgraph_update_post:
    #     bpy.app.handlers.depsgraph_update_post.remove(desgraph_post)