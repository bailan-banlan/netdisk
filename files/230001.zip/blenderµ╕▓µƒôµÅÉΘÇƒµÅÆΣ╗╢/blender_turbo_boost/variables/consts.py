alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'

#turbo render
valid_turbo_render_engines = ('CYCLES')
turbo_passes_cycles = (
                
                        
                        ("use_pass_diffuse_direct",('DiffDir',)),
                        ("use_pass_diffuse_indirect",('DiffInd',)),
                        ("use_pass_glossy_direct",('GlossDir',)),
                        ("use_pass_diffuse_color",('DiffCol',)),
                        ('use_pass_glossy_indirect',('GlossInd',)),
                        ('use_pass_glossy_color',('GlossCol',)),
                        ('use_pass_transmission_direct',('TransDir',)),
                        ('use_pass_transmission_indirect',('TransInd',)),
                        ('use_pass_transmission_color',('TransCol',)),
                        ('cycles.use_pass_volume_direct',('VolumeDir',)),
                        ('cycles.use_pass_volume_indirect',('VolumeInd',)),                        
                        ('use_pass_emit',('Emit',)),
                        ('use_pass_environment',('Env',)),                        
                        ('cycles.denoising_store_passes',('Denoising Normal','Denoising Albedo','Denoising Depth',)),

                       )

vector_pass_cycles = ('use_pass_vector',('Vector',))


Cycles_render_presets = {  
                    'Crap':{'Max_Samples':12,'Min_Samples' : 4, 'Noise_Threshold' : 0.5,'Time_Limit' : 0,'Use_Adaptive' : True},
                    'Medium Rare':{'Max_Samples':64,'Min_Samples' : 8, 'Noise_Threshold' : 0.3,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Medium':{'Max_Samples':180,'Min_Samples' : 12, 'Noise_Threshold' : 0.3,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'High':{'Max_Samples':324,'Min_Samples' : 16, 'Noise_Threshold' : 0.1,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Very High':{'Max_Samples':648,'Min_Samples' : 24, 'Noise_Threshold' : 0.08,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Ultra':{'Max_Samples':3600,'Min_Samples' : 36, 'Noise_Threshold' : 0.05,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Insane':{'Max_Samples':14400,'Min_Samples' : 145, 'Noise_Threshold' : 0.01,'Time_Limit' : 0, 'Use_Adaptive' : True},
                 }

Cycles_render_presets_interior = {  
                    'Crap':{'Max_Samples':16,'Min_Samples' : 8, 'Noise_Threshold' : 0.5,'Time_Limit' : 0,'Use_Adaptive' : True},
                    'Medium Rare':{'Max_Samples':64,'Min_Samples' : 16, 'Noise_Threshold' : 0.3,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Medium':{'Max_Samples':180,'Min_Samples' : 64, 'Noise_Threshold' : 0.3,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'High':{'Max_Samples':324,'Min_Samples' : 128, 'Noise_Threshold' : 0.1,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Very High':{'Max_Samples':648,'Min_Samples' : 160, 'Noise_Threshold' : 0.08,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Ultra':{'Max_Samples':3600,'Min_Samples' : 256, 'Noise_Threshold' : 0.05,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Insane':{'Max_Samples':14400,'Min_Samples' : 256, 'Noise_Threshold' : 0.01,'Time_Limit' : 0, 'Use_Adaptive' : True},
                 }

Cycles_render_presets_animation = {  
                    'Crap':{'Max_Samples':600,'Min_Samples' : 8, 'Noise_Threshold' : 0.5,'Time_Limit' : 0,'Use_Adaptive' : True},
                    'Medium Rare':{'Max_Samples':600,'Min_Samples' : 12, 'Noise_Threshold' : 0.3,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Medium':{'Max_Samples':600,'Min_Samples' : 18, 'Noise_Threshold' : 0.1,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'High':{'Max_Samples':600,'Min_Samples' : 28, 'Noise_Threshold' : 0.05,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Very High':{'Max_Samples':1200,'Min_Samples' : 40, 'Noise_Threshold' : 0.01,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Ultra':{'Max_Samples':2500,'Min_Samples' : 80, 'Noise_Threshold' : 0.008,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Insane':{'Max_Samples':14400,'Min_Samples' : 145, 'Noise_Threshold' : 0.005,'Time_Limit' : 0, 'Use_Adaptive' : True},
                 }
Cycles_render_presets_interior_animation = {  
                    'Crap':{'Max_Samples':600,'Min_Samples' : 8, 'Noise_Threshold' : 0.5,'Time_Limit' : 0,'Use_Adaptive' : True},
                    'Medium Rare':{'Max_Samples':600,'Min_Samples' : 16, 'Noise_Threshold' : 0.3,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Medium':{'Max_Samples':600,'Min_Samples' : 40, 'Noise_Threshold' : 0.1,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'High':{'Max_Samples':600,'Min_Samples' : 60, 'Noise_Threshold' : 0.05,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Very High':{'Max_Samples':1200,'Min_Samples' : 80, 'Noise_Threshold' : 0.01,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Ultra':{'Max_Samples':2500,'Min_Samples' : 120, 'Noise_Threshold' : 0.008,'Time_Limit' : 0, 'Use_Adaptive' : True},
                    'Insane':{'Max_Samples':14400,'Min_Samples' : 256, 'Noise_Threshold' : 0.005,'Time_Limit' : 0, 'Use_Adaptive' : True},
                 }

valid_vector_names = {'cycles':('Vector'),}

#the value is the name of the socket on the combine node
vector_format =   {
                     'cycles':{'x_current_to_prev': 'Red', 'y_current_to_prev':'Green', 'x_current_to_next':'Blue', 'y_current_to_next':'Alpha'},
                     'cycles_old':{'x_current_to_prev': 'R', 'y_current_to_prev':'G', 'x_current_to_next':'B', 'y_current_to_next':'A'},
                  }

invalid_temporal_socket_cycles = ('Denoising Normal','Denoising Albedo','Denoising Depth','Vector','CryptoObject00','CryptoObject01',
                           'CryptoObject02','CryptoMaterial00','CryptoMaterial01','CryptoMaterial02','CryptoAsset00',
                           'CryptoAsset01','CryptoAsset02','Debug Sample Count','IndexMA','IndexOB','UV','Normal',
                           'Position','Mist','Depth','EnvPOO','EmitPOO','AO','Shadow','AlphaPOOP','Vector')

compatible_temporal_render_engines = ('cycles','redshift',)

vector_socket_names_by_engine = {'cycles':'Vector',}

displace_x_scale = {'cycles':-1,}
displace_y_scale = {'cycles': 1}
