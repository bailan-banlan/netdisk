
#turbo cache
#don't reset 
last_rendered_frame = None

file_out_keep = None
timeline_position_before_rednering = None
rendering = False
render_cancelled = None
nodes_muted_at_beginning_of_playback = None
first_playback_frame = None
muted_before_render = None
comp_area_zoom_list = None
remove_after_cache = set()
playback_start_frame = None
cache_exrs_in_use_before_animation_render = None
was_cancelled = None


#file_output_node
original_render_window_type = None


#turbo render

turbo_passes_enabled = None
denoise_nodes_to_delete = None
turbo_render_nodes_to_delete = None #this will be list of original_node.scene.name , because the turbo render will be a property of each scene rather than a global variable ..maybe, or maybe it'll just be  globabl variable controlled by the current scene (so all scenes get denoised...)
turbo_render_end_nodes_whose_links_to_move_back_to_their_render_layers_node_image_output = None
scenes_to_reenable_denoise = None
original_rl_node_link_list_before_turbo_render_node_socket_id_node_socket_id = None
all_user_render_settings = None

#general

playing = None
render_type = [] #cache_render, file_output_node_render
not_frame_change_first_visit = None

#temporal
temporal_nodes_to_delete = None
links_before_temporal = None
vector_pass_enabled_for_render = None

#publish
links_before_publish = None

#testing
testing = False
location = None


def reset_all_vars():

    
    
    dont_reset = ['playing','testing','location','dont_reset','reset_all_vars']
    for key,value in globals().items():
        if not key.startswith('__') and key not in dont_reset:
            #print(key)
            if key == 'render_type':                
                globals()[key] = []    
            elif key == 'remove_after_cache':
                globals()[key] = set()
            elif key not in dont_reset:
                globals()[key] = None

    
   