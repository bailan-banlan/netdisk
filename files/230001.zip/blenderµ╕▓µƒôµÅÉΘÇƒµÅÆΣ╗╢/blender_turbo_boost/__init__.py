"""Copyright (C) 2022 3d-illusions All Rights Reserved

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>."""


bl_info = {
    "name" : "Turbo Tools",
    "author" : "3d-illusions.co.uk",
    "description" : "Tools to dramatically speed up rendering and compositing",
    "blender" : (3, 2, 0),
    "version" : (3,0,0),
    "location" : "render properties, compositor panel and menus",
    "warning" : "never eat yellow snow!",
    "doc_url" : "https://3dillusions.gumroad.com/l/turbo_tools",
    "tracker_url" : "mailto:support@3d-illusions.co.uk",
    "category" : "Turbo_Tools"    
}


import bpy
from . utils import RegisterHelpers as rh
from . utils import RegisterKeymap as rk
from . handlers import handlers as rhndl
#from . msg_bus import msg_bus as msgbus
from .menus import add_to_existing_menus
from .properties import properties


all_classes = rh.get_all_classes()


def register():
    for cls in all_classes:
        try:
            bpy.utils.register_class(cls)      
            if cls.__name__ == 'Turbo_Render_Preferences':                
                properties.register()
        except Exception as e:
            pass

    rhndl.register_handler()
    #msgbus.create_subscriptions()
    add_to_existing_menus.register_menus()
    rk.register_keymap()
    
def unregister():
    add_to_existing_menus.unregister_menus()    
    for cls in reversed(all_classes):
        bpy.utils.unregister_class(cls)
    rk.unregister_keymap()
    rhndl.unregister_handler()
    #msgbus.remove_subscriptions()
    properties.unregister()

