from cgitb import text
from os import name
import bpy
from bpy.types import Panel
from ..variables import global_vars
from ..handlers import maintenance

def has_geometry_visibility(ob):
    return ob and ((ob.type in {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META', 'LIGHT'}) or
                    (ob.instance_type == 'COLLECTION' and ob.instance_collection))


class THREEDI_PT_Turbo_Comp_Panel(Panel):
    bl_label = "Turbo Comp Options"
    bl_idname = 'THREEDI_PT_Turbo_Comp_Panel'    
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Turbo"    
  
    @classmethod
    def poll(cls,context):
        return (context.space_data.type == 'NODE_EDITOR' and
                context.space_data.tree_type == 'CompositorNodeTree')

    def draw(self, context):
        layout = self.layout
        layout.separator()

        # box = layout.box()
        # r = box.row()
        # r.label(text='FPS')
        # r.label(text = f'{context.scene.comp_fps:.2f}')

        #for testing only
        
        if global_vars.testing:
            box = layout.box()
            box.label(text='Testing')
            box.operator("threedi.test", text="test", icon="MONKEY")
            

            


        box = layout.box()        
        box.label(text='Cache')
        
        inner_box = box.box()
        inner_box.label(text='Scene cache folder')
        row = inner_box.row()
        
        row.prop(bpy.context.scene,'Turbo_Cache_Folder',text='')
        row = inner_box.row()
        
        row.prop(bpy.context.scene,"Keep_Cache",text="animation",)
        
        row.prop(bpy.context.scene,'Validate_Cache_During_Playback',text='validate cache')
        create_cache_box = box.box()
        create_cache_box.operator("threedi.cache_comp_branch", text="cache/uncache", icon="FILE_CACHE")
        create_cache_box.prop(bpy.context.scene,'Standard_Cache_Resolution',text='new cache resolution')
        box.operator("threedi.refresh_cache_nodes", text="refresh all", icon="FILE_REFRESH")
        box.operator("threedi.refresh_all_upstream", text="refresh selected/upstream", icon="FILE_REFRESH")
        box.operator("threedi.clear_cache_selected", text="clear cache of selected", icon="TRASH")

        box = layout.box()        
        box.label(text='File output node')        
        box = box.box()
        box.operator("threedi.auto_file_output", text="create and wire",icon="FILEBROWSER")
        box.prop(context.scene,'only_linked',text='only wired')
        box.prop(context.scene,'file_out_format',text='Format')
        box.separator()
        box.operator("threedi.clear_resave_file_output_node", text="resave current frame",icon="RESTRICT_RENDER_OFF")
        box.operator("threedi.clear_resave_file_output_node_animation", text="resave all frames",icon="OUTLINER_OB_CAMERA")

        
        snode = context.space_data
        #layout.active =  snode.show_backdrop
        box = layout.box()        
        box.label(text='Performance')        
        #box.operator("threedi.add_quality_node", text="add cache resize node", icon="ALIASED")        
        box.prop(bpy.context.scene,'sync_mode',text='sync mode')
        box.prop(snode,'backdrop_zoom',text='backdrop size')

        box = layout.box()
        box.label(text='Publish')
        box.operator("threedi.compositor_publish_single", text="publish current frame", icon="MOD_ARMATURE")
        box.operator("threedi.compositor_publish_animation", text="publish animation", icon="ARMATURE_DATA")
        box_inner = box.box()
        #box_inner.label(text='Temporal flicker removal options')
        
        box_inner.prop(bpy.context.scene,'Temporal_Publish',text='remove temporal flicker')
        row=box_inner.row()
        if not bpy.context.scene.Temporal_Publish:
            row.active = False
        row.prop(bpy.context.scene,'Temporal_RGBA_Seperately',text='process rgba seperately')

        
        box.prop(bpy.context.scene,'execute_file_output_nodes_during_publish',text='include file output nodes')
        box.prop(bpy.context.scene,'QuickPublish',text='quick publish')
        
        inner = box.box()
        inner.operator('render.view_show',text='View published image',icon='IMAGE_DATA')
        inner.operator('render.play_rendered_anim',text='View published animation',icon='SEQUENCE')

        
        
    
    
    