from cgitb import text
from ctypes import alignment
from os import name
from posixpath import split
import bpy
from bpy.types import Panel



def has_geometry_visibility(ob):
    return ob and ((ob.type in {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META', 'LIGHT'}) or
                    (ob.instance_type == 'COLLECTION' and ob.instance_collection))


class THREEDI_PT_Turbo_Render_Panel(Panel):
    bl_label = "Turbo Render Options"
    bl_parent_id = "RENDER_PT_context"
    # bl_idname = 'THREEDI_Turbo_Render_Panel'    
    # bl_category = "Turbo"  
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "render"
    #bl_options = {'DEFAULT_CLOSED'}
    COMPAT_ENGINES = {'CYCLES'}

    @classmethod
    def poll(cls, context):
        return context.engine in cls.COMPAT_ENGINES  
  
    
    def draw(self, context):
        layout = self.layout
        layout.separator()
        #layout.use_property_split = True
        layout.use_property_decorate = False        


        # motion_blur_scenes = [n.name for n in context.scene.node_tree.nodes if n.type == 'R_LAYERS' and (n.scene.render.use_motion_blur)]
        # if motion_blur_scenes:
        #     row = layout.row()
            
        #     row.prop(bpy.context.scene,'Motion_Blur_Warning',text=' (hover for more info)',icon='ERROR',icon_only=True)
            

        row = layout.row(align=True)#
        
        
        row.scale_y = 3
        #row.alignment='CENTER'
        row.prop(bpy.context.scene,'Turbo_Render',text='Enable',icon='AUTO')
        
        row = layout.row(align=True)
        if not bpy.context.scene.Turbo_Render:
            row.active=False
        
        
        col = row.column()
        #col.alignment ='CENTER'
        inner_box = col.box()
        header_row = inner_box.row()
        header_row.alignment = 'CENTER'        
        header_row.label(text='Turbo Render Options')
        
        
        second_row = inner_box.row()
        row_col = second_row.column()       
        row_col.label(text='Denoising Mode')        
        row_col.label(text='Sample Presets')         

        row_col = second_row.column()       
        row_col.prop(bpy.context.scene,'Turbo_Mode',text='')
        row_col.prop(bpy.context.scene,'Render_Setting_Presets',text='')
        
        inner_row = inner_box.row()        
        col = inner_row.column()
        col.prop(bpy.context.scene,'Turbo_Render_HQ', text='Very Dirty!')
        col.prop(bpy.context.scene,'Interior_Mode', text='Interior/Heavy GI')
        col.prop(bpy.context.scene,'Optimise_For_Anim', text='Animation')

        
        col = inner_row.column()
        col.prop(bpy.context.scene,'Turbo_Render_Enhance_Textures', text='Enhance Textures')
        if bpy.context.scene.Turbo_Mode in ('Medium','High'):
                        
            col.prop(bpy.context.scene,'Turbo_Render_Enhance_Glossy', text='Enhance Glossy')
            col.prop(bpy.context.scene,'Turbo_Render_Enhance_Trans', text='Enhance Transmission')
        
        
        col = row.column()
        #col.scale_y = 2
        #col.alignment = 'CENTER'
        
        inner_box = col.box()
        #inner_box.alignment = 'CENTER'
        header_row = inner_box.row(align=True)
        header_row.alignment = 'CENTER'
        #inner_box.alignment = 'CENTER'
        #header_row.label(text='final render only')
        header_row.label(text='Cycles Speedup')
        header_row = inner_box.row(align=True)
        header_row.alignment = 'CENTER'
        header_row.label(text='(viewport & final render)')
        row = inner_box.row()
        row.alignment ='RIGHT'
        col = row.column()
        col.prop(bpy.context.scene,'Firefly_Removal', text='Prevent Fireflies',emboss=True)
        col.prop(bpy.context.scene,'Optimise_HDRI', text='Optimise HDRI',emboss=True)
        

        
        
        
        
        
        
        # inner_box = layout.box()
        # inner_box.alignment = 'CENTER'
        # row = inner_box.row()
        # row.alignment='CENTER'
        # row.label(text='Viewport & Final Render Settings')
        # row = inner_box.row()
        # row.alignment='CENTER'
             
        
        
        
        
        
        row =layout.row()
        if not bpy.context.scene.Turbo_Render:
            row.active=False
        
        # col = row.column()
        # col = row.column()
        box = layout.box()
        
        row = box.row()
        row.alignment = 'CENTER'
        
        row.label(text='Visible to Camera')
        
        if not bpy.context.scene.Turbo_Render:          
            box.active = False

        
        #Transmission
        item = box.box()#(align=True)
        split = item.split()
        col = split.column(align=True)
        col.prop(bpy.context.scene,'Turbo_Geo',text='Surfaces')        

        col = split.column(align=True)
        if not bpy.context.scene.Turbo_Geo:
            col.active = False
        col.prop(bpy.context.scene,'Turbo_Diff',text='Diffuse')
        col.prop(bpy.context.scene,'Turbo_Gloss',text='Glossy/Metal')
        col.prop(bpy.context.scene,'Turbo_Trans',text='Transmission')
        col.prop(bpy.context.scene,'Turbo_Emit',text='Emission')
        if bpy.context.scene.Turbo_Mode != 'Fast':
            col.prop(bpy.context.scene,'Turbo_SSS',text='SSS')
        # col = split.column(align=True)        
        # col.separator()
        
        
        #world environment
        item = box.box()#(align=True)
        split = item.split()
        col = split.column(align=True)        
        col.prop(bpy.context.scene,'Turbo_Env',text='World Environment')        
        col = split.column(align=True)
        if not bpy.context.scene.Turbo_Env or not bpy.context.scene.Turbo_Trans:
            col.active=False
        col.prop(bpy.context.scene,'Env_Only_Behind_Glass',text='Only behind Transmission')

        
        

        
        

        #dof motion blur
        item = box.box()#(align=True)
        split = item.split()
        col = split.column(align=True)        
        col.prop(bpy.context.scene,'Heavy_DOF',text='Heavy DOF/Motion Blur')

        #volume
        item = box.box()#(align=True)
        split = item.split()
        col = split.column(align=True)        
        col.prop(bpy.context.scene,'Turbo_Volume',text='Volume')    
        

        col = split.column(align=True)
        
        if not bpy.context.scene.Turbo_Volume:
            col.active = False
        col.label(text='occludes')
        
        
        if not bpy.context.scene.Turbo_Mode == 'Fast':
            row=col.row()
            if not bpy.context.scene.Turbo_Diff or not bpy.context.scene.Turbo_Geo:
                row.active=False
            row.prop(bpy.context.scene,'Diff_Behind_Vol',text='diffuse')

            row=col.row()
            if not bpy.context.scene.Turbo_Gloss or not bpy.context.scene.Turbo_Geo:
                row.active=False
            row.prop(bpy.context.scene,'Gloss_Behind_Vol',text='glossy')
            
            row=col.row()
            if not bpy.context.scene.Turbo_Trans or not bpy.context.scene.Turbo_Geo:
                row.active=False
            row.prop(bpy.context.scene,'Trans_Behind_Vol',text='transmission')

        row = col.row()
        if not bpy.context.scene.Turbo_Emit or not bpy.context.scene.Turbo_Geo:
            row.active = False
        row.prop(bpy.context.scene,'Emission_Behind_Vol',text='emission')

        row = col.row()
        if not bpy.context.scene.Turbo_Env or (bpy.context.scene.Turbo_Env and bpy.context.scene.Env_Only_Behind_Glass
                                                and not (bpy.context.scene.render.film_transparent and bpy.context.scene.cycles.film_transparent_glass)):
            row.active=False
        row.prop(bpy.context.scene,'Env_Behind_Vol',text='world Environment')

        box = box.box()
        row = box.row(align=True)
        row.label(text='Scene Cache Folder')        
        row.prop(bpy.context.scene,'Turbo_Cache_Folder',text='')

        
        
        
        
        

        
        
            
        
        if bpy.context.scene.Turbo_Env and not bpy.context.scene.Env_Only_Behind_Glass:
            pass
            
        if bpy.context.scene.Turbo_Emit:
            pass
            #inner = split.column(align=True,heading='')
            


            
        

        
        
    
    
    