import bpy
from bpy.types import NodeTree
from ..variables import global_vars


from ..operators.dont_register import scene_helpers,cache_operations,report_custom_error,checks,cache_operation_helpers

def area_changed():
    print('area changed')
    #print(bpy.context.area.ui_type)
    try:
        scene = bpy.context.scene
        current_frame = scene.frame_current
        if 'last_cached_frame' in scene and current_frame != scene['last_cached_frame']:
            if scene_helpers.compositor_is_visible(scene.name):
                print('compositor visible')
                try:
                    if checks.all_can_be_refreshed(scene.name):
                        cache_operations.refresh_all(scene.name)
                except Exception as e:
                    report_custom_error.notify_user(scene.name,[str(e)])
                finally:
                    if 'custom_error' in scene and len(scene['custom_error']) > 0:
                        report_custom_error.notify_user(scene.name)
                    
    except Exception as e:
        print('something went wrong')
        print(str(e))

def workspace_changed():
    print('workspace changed')
    scene = bpy.context.scene
    current_frame = scene.frame_current
    if 'last_cached_frame' in scene and current_frame != scene['last_cached_frame']:
        if scene_helpers.compositor_is_visible(scene.name):
            print('there is a node tree here')
            try:
                if checks.all_can_be_refreshed(scene.name):
                    cache_operations.refresh_all(scene.name)
            except Exception as e:
                report_custom_error.notify_user(scene.name,[str(e)])
            finally:
                if 'custom_error' in scene and len(scene['custom_error']) > 0:
                    report_custom_error.notify_user(scene.name)


def playback_toggled():
    print('playback started at ',bpy.context.scene.frame_current)

def use_nodes_toggle():
    print('nodes toggles to')
    if bpy.context.scene.use_nodes:
        print('on')
    else:
        print('off')

def frame_changed():
    print('frame has been changed from messagbus')

def is_scrubbing():
    print('is scrubbing')

def comp_node_changed():
    active = bpy.context.active_node
    if type(bpy.context.active_node) == 'CompositorNodeViewer':
        bpy.context.scene['active_viewer'] = active.name
    print('viewer node changed to', active.name)

def res_change(context):
    print('res change hit')
    active = context.scene.node_tree.nodes.active
    scr = context.screen
    nodes = context.scene.node_tree.nodes
    if scene_helpers.compositor_is_visible(context.scene.name) and active.type == "VIEWER" and scr.is_animation_playing and not scr.is_scrubbing:
        if 'scale_node' not in active or ('scale_node' in active and active['scale_node'] not in nodes ):
            cache_operation_helpers.create_quality_node(context.scene.name)
        if global_vars.comp_area_zoom_list is None:
            scene_helpers.store_start_zoom_per_visible_compositor(context.scene.name)
        scene_helpers.update_comp_zoom_areas(context.scene.name)
        



# subscribe_to_new_scene = bpy.types.Scene
# subscribe_to_area = (bpy.types.Area)
# subscribe_to_workspace = object()
# subscribe_to_use_nodes = object()
#subscribe_to_playback = object()
#subscribe_to_frame_change = (bpy.types.Scene)
#subscribe_to_scrubbing = (bpy.types.Screen)
#subscribe_to_node_change = object()
#subscribe_to_render_resolution_change = (bpy.types.RenderSettings)

#def create_subscriptions():   
    
#     subscription_key_area = (bpy.types.Area , 'ui_type')
#     bpy.msgbus.subscribe_rna(key =subscription_key_area,owner =subscribe_to_area,args =(),notify=area_changed,options={'PERSISTENT'})    
#     subscription_key_workspace = (bpy.types.Window,'workspace')
#     bpy.msgbus.subscribe_rna(key =subscription_key_workspace,owner =subscribe_to_workspace,args = (), notify=workspace_changed,options={'PERSISTENT'})    
#     subscription_key_use_nodes = (bpy.types.Scene,'use_nodes')
#     bpy.msgbus.subscribe_rna(key =subscription_key_use_nodes,owner =subscribe_to_use_nodes,args = (), notify=use_nodes_toggle,options={'PERSISTENT'})

#     # subscription_key_resolution = (bpy.types.RenderSettings,'resolution_percentage')
#     # bpy.msgbus.subscribe_rna(key =subscription_key_resolution,owner =subscribe_to_render_resolution_change,args = (bpy.context,), notify=res_change,options={'PERSISTENT'})
    
#     # subscription_key_node_change = bpy.context.scene.node_tree.nodes.path_resolve('active')
#     # bpy.msgbus.subscribe_rna(key =subscription_key_node_change,owner =subscribe_to_node_change,args = (), notify=comp_node_changed,options={'PERSISTENT'})


    
    
# def remove_subscriptions():
#     bpy.msgbus.clear_by_owner(subscribe_to_area)
#     bpy.msgbus.clear_by_owner(subscribe_to_workspace)
#     bpy.msgbus.clear_by_owner(subscribe_to_use_nodes)
    #bpy.msgbus.clear_by_owner(subscribe_to_node_change)
    # bpy.msgbus.clear_by_owner(subscribe_to_frame_change)
    # bpy.msgbus.clear_by_owner(subscribe_to_scrubbing)
   # bpy.msgbus.clear_by_owner(subscribe_to_render_resolution_change)