import bpy


def get_from_socket(socket):
    
    if len(socket.links) > 0:
        for l in socket.links:    
            if l.from_node.type == 'REROUTE':
                #print('reroute hit')                
                return get_from_socket(l.from_node.inputs[0])
            else:
                return l.from_socket.name
    else:
        pass
        #print(socket.name,'has no links')
        

def main(context):
    selected_node = bpy.context.active_node
    if selected_node and selected_node.type == 'GROUP':        
        names = []        
        for index,s in enumerate(selected_node.inputs):            
            name = get_from_socket(s)
            if name is not None:    
                names.append((index, name))

        #change the names where available
        the_node_tree_inputs = selected_node.node_tree.inputs         
        for n in names:
            the_node_tree_inputs[n[0]].name = n[1]
            

    

class ThreeDi_OT_RenameGroupInputs(bpy.types.Operator):
    """renames group inputs to names of sockets feeding them from outside the group"""
    bl_idname = "threedi.rename_group_inputs"
    bl_label = "Rename group inputs from source"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls,context):
        return context.space_data.type == 'NODE_EDITOR' and context.active_node and context.active_node.type == 'GROUP' # and
               # context.space_data.tree_type == 'GeometryNodeTree')

    def execute(self, context):
        main(context)
        return {'FINISHED'}


