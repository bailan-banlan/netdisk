import bpy

class THREEDI_MT_Comp_File_Output(bpy.types.Menu):
    bl_idname = "THREEDI_MT_File_Output_Menu"
    bl_label = 'File Output Node Tools'

    def draw(self,context):
        layout = self.layout        
        layout.operator("threedi.auto_file_output", text="create and wire file output", icon="FILEBROWSER")
        layout.operator("threedi.clear_resave_file_output_node", text="resave current frame",icon="RESTRICT_RENDER_OFF")
        layout.operator("threedi.clear_resave_file_output_node_animation", text="resave all frames",icon="OUTLINER_OB_CAMERA")

class THREEDI_MT_Comp_Performance(bpy.types.Menu):
    bl_idname = "THREEDI_MT_Performance_Menu"
    bl_label = 'Performance Tools'

    def draw(self,context):
        layout = self.layout        
        layout.operator("threedi.add_quality_node", text="insert playback quality node", icon="ALIASED")
        #layout.prop(context.scene, "playback_quality", text="playback quality")
        

class THREEDI_MT_Turbo_Cache(bpy.types.Menu):
    bl_idname = "THREEDI_MT_Cache_Menu"
    bl_label = 'Cache Tools'

    def draw(self,context):
        layout = self.layout        
        
        layout.operator("threedi.cache_comp_branch", text="Cache/Uncache the selected nodes", icon="FILE_CACHE")
        layout.operator("threedi.refresh_cache_nodes", text="refresh all", icon="FILE_REFRESH")
        layout.operator("threedi.refresh_all_upstream", text="refresh selected and upstream", icon="FILE_REFRESH")
        layout.operator("threedi.clear_cache_selected", text="clear cache of selected", icon="TRASH")
        #layout.prop(context.scene, "Standard_Cache_Resolution", text="new_cache_resolution")

        

class THREEDI_MT_Turbo_Groups(bpy.types.Menu):
    bl_idname = "THREEDI_MT_Groups_Menu"
    bl_label = 'Group Tools'

    def draw(self, context):
        self.layout.operator("threedi.rename_group_inputs", icon = 'TIME')  


class THREEDI_MT_Turbo_Publish(bpy.types.Menu):
    bl_idname = "THREEDI_MT_Turbo_Publish_Menu"
    bl_label = 'Publishing'

    def draw(self, context):
        layout = self.layout
        
        #layout.label(text='Publish')
        layout.operator("threedi.compositor_publish_single", text="publish current frame", icon="MOD_ARMATURE")
        layout.operator("threedi.compositor_publish_animation", text="publish animation", icon="ARMATURE_DATA")
        # layout.prop(bpy.context.scene,'Temporal_Publish',text='temporal flicker removal')
        # layout.prop(bpy.context.scene,'execute_file_output_nodes_during_publish',text='include file output nodes')
        # layout.prop(bpy.context.scene,'QuickPublish',text='quick publish')
        
        
        layout.operator('render.view_show',text='View published image',icon='IMAGE_DATA')
        layout.operator('render.play_rendered_anim',text='View published animation',icon='SEQUENCE')
    
        
        
class THREEDI_MT_Turbo_Tools(bpy.types.Menu):
    bl_idname = "THREEDI_MT_Turbo_Tools_Menu"
    bl_label = 'Turbo Tools'

    @classmethod
    def poll(cls,context):
        return context.space_data.type == 'NODE_EDITOR'# and
                #context.space_data.tree_type == 'CompositorNodeTree')

    def draw(self,context):
        layout = self.layout        
        if context.space_data.tree_type == 'CompositorNodeTree':
            layout.menu("THREEDI_MT_Cache_Menu")
            #layout.menu("THREEDI_MT_Performance_Menu")
            layout.menu("THREEDI_MT_File_Output_Menu")
            layout.menu("THREEDI_MT_Turbo_Publish_Menu")
        
        layout.menu("THREEDI_MT_Groups_Menu")
        #layout.operator("threedi.render_check", text="pre-render check (use before rendering)", icon="RESTRICT_RENDER_OFF")        
        
        

class THREEDI_MT_Main_Menu(bpy.types.Menu):
    bl_idname = "THREEDI_MT_Main_Menu"
    bl_label = "Turbo Tools"
    

    def draw(self, context):

        layout = self.layout

        #layout.operator_context = 'INVOKE_DEFAULT'
        

        layout.menu("THREEDI_MT_Turbo_Tools_Menu",)
        
        #layout.operator("threedi.setup_turbo_render", text="setup turbo render", icon="MOD_SOLIDIFY")
        
        #layout.operator("threedi.refresh_selected_cache_nodes", text="refresh selected", icon="FILE_REFRESH")
        
        #layout.operator("threedi.save_file_output", text='resave selected file output nodes', icon= "FILE_TICK")

        # layout.operator("threedi.render_still", text="render still", icon="RESTRICT_RENDER_OFF")
        # layout.operator("threedi.render_animation", text="render animation", icon="VIEW_CAMERA")

        #layout.operator("threedi.test_shit", text="tests shit", icon="MONKEY")
        
        
        # layout.operator("threedi.print_context", text="context info", icon="RENDERLAYERS")
        # layout.operator("threedi.vertex_weight_transfer", text="transfer vertex weights", icon="RENDERLAYERS")
        # layout.operator("threedi.clear_subscriptions", text="clear subscriptions", icon="RENDERLAYERS")


        #layout.operator("threedi.test", text="test", icon="QUESTION")
        #layout.operator("threedi.modal_thread_check", text="modal thread", icon="QUESTION")
        

        

        

        
        
        
        #layout.operator("gem.solidify", text="Solidify", icon="LIGHT")