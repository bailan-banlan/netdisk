import bpy

# class NODE_MT_turbo_comp(bpy.types.Menu):
#     #bl_idname = "NODE_MT_turbo_comp"
#     #bl_space_type = 'NODE_EDITOR'
#     bl_label = "Turbo Comp"
    
def add_turbo_tools_menu(self,context):
    
    #bl_translation_context = i18n_contexts.operator_default
    # snode = context.space_data
    # is_compositor = snode.tree_type == 'CompositorNodeTree'

    # if is_compositor:
    layout = self.layout
    #layout.menu("THREEDI_MT_Turbo_Comp_Menu")
    layout.menu("THREEDI_MT_Turbo_Tools_Menu")


def render_menu(self,context):
    layout = self.layout

    layout.operator("threedi.render_still",icon="RESTRICT_RENDER_OFF")
    layout.operator("threedi.render_animation",icon = "OUTLINER_OB_CAMERA")
    layout.separator()
    layout.operator("sound.mixdown", text="Render Audio...")
    layout.separator()
    layout.operator("render.view_show", text="View Render")
    layout.operator("render.play_rendered_anim", text="View Animation")
    layout.separator()
    layout.prop(bpy.context.scene.render, "use_lock_interface", text="Lock Interface") 


def original_render_menu(self,context):
    layout = self.layout

    layout.operator("render.render", text="Render Image",
                        icon='RENDER_STILL').use_viewport = True
    props = layout.operator(
        "render.render", text="Render Animation", icon='RENDER_ANIMATION')
    props.animation = True
    props.use_viewport = True
    layout.separator()
    layout.operator("sound.mixdown", text="Render Audio...")
    layout.separator()
    layout.operator("render.view_show", text="View Render")
    layout.operator("render.play_rendered_anim", text="View Animation")
    layout.separator()
    layout.prop(bpy.context.scene.render, "use_lock_interface", text="Lock Interface") 



    

def register_menus():
    bpy.types.NODE_MT_editor_menus.append(add_turbo_tools_menu)
    lmda = lambda s,c:s.layout.separator()
    bpy.types.TOPBAR_MT_render.draw = lmda
    bpy.types.TOPBAR_MT_render.prepend(render_menu)
  

def unregister_menus():
    bpy.types.NODE_MT_editor_menus.remove(add_turbo_tools_menu)
    bpy.types.TOPBAR_MT_render.remove(render_menu)
    bpy.types.TOPBAR_MT_render.prepend(original_render_menu)
    
    
