from .all_mods import *
import sys
import inspect
import os
import pathlib





def get_all_modules_defined_in_directory(directory,all_mods):
    '''gets all modules defined in a directory and adds them to the list you pass in.
    \narguments:
    \n Directory from the root of the addon.  ie addon_root/operators/register/)
    \n current list of modules(strings))
    '''
    folder_contents = os.listdir(os.path.join(str(pathlib.Path(__file__).parent.parent.parent.absolute()) , directory))
    #test = os.path.sep
    start_of_mod_path = directory.replace(os.path.sep,'.')#swaps the file path to a module path
    full_module_path = ''
    for file_name in folder_contents:
        if file_name == '__init__.py' or not file_name.endswith('.py'):
            #its init file or a directory
            pass
        else:
            module_name = file_name[:-3]
            full_module_path = start_of_mod_path + module_name
            all_mods.append(full_module_path)
    return all_mods




top_level = __name__.split('.')[0] # this is the name of the root folder, __name__ get the path from the root, so we just grab the bit before the first '.'
# register_directories = [top_level +'\\properties\\',top_level + '\\operators\\register\\',top_level +'\\panels\\',top_level +'\\menus\\']
register_directories = [
                        os.path.join(top_level,'properties',''),
                        os.path.join(top_level,'operators','register',''),
                        os.path.join(top_level,'panels',''),
                        os.path.join(top_level,'menus',''),
                        os.path.join(top_level,'generic_node_operators','')
                        ]




all_mods = []#we'll store all the full module paths in here


#get the modules from all directories we've added to the register_directories list
for directory in register_directories:
    all_mods = get_all_modules_defined_in_directory(directory,all_mods)#get the folder contents for the current directory looping over and overwrite all_mods (list of all modules)

all_classes = []

def get_all_classes():
    for mod in all_mods:
        for key,cls in inspect.getmembers(sys.modules[mod], inspect.isclass):
            if cls.__module__ in all_mods:
                if cls not in all_classes:
                    all_classes.append(cls)


    return all_classes





