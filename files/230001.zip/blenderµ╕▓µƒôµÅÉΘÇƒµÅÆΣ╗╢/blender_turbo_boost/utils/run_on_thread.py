import bpy
from ..operators.dont_register import render_layer_operations,cache_operations
import threading
import queue

execution_queue = queue.Queue()
function = None
args = None
first = True

def execute_functions_on_main_thread():
    global first
    global function
    global args

    if first:
        func = function
        func(*args)
        #print('RUN ON THREAD.  Thread = ',threading.currentThread().ident)    
        function = None
        args = None
        first = False
        return None
    return 0.000000000000000000000001

def run(infunction,arguments = None):    
    global args
    global function
    global first

    #breakpoint()
    if arguments is None:
        arguments = []
    args = arguments
    function = infunction
    first = True
    bpy.app.timers.register(execute_functions_on_main_thread)

def test():
    pass
    #print("hello! Thread =" ,threading.currentThread().ident)



