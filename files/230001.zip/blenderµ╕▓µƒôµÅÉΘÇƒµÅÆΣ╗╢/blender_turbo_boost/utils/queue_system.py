import bpy
import queue
from ..operators.dont_register import render_layer_operations
import threading

execution_queue = queue.Queue()


# This function can savely be called in another thread.
# The function will be executed when the timer runs the next time.
def add_function_to_queue(function_and_args):
    """pass in a list containing [function,arg,arg,arg,etc]"""
    execution_queue.put(function_and_args)

def execute_queued_functions():
    while not execution_queue.empty():
        items = execution_queue.get()
        func = items[0]
        args = items[1:]
        func(*args)
        
        
        #print('QUEUE EXECTUTION.  Thread = ',threading.currentThread().ident)        
        if execution_queue.empty():
            return None
    
    return 0.00000000000000000000000000000001

def register_timer():    
    bpy.app.timers.register(execute_queued_functions)


def unregister_timer():
    bpy.app.timers.unregister(execute_queued_functions)

