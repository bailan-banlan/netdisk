import bpy

#a list of dictinaries.  Each dictionary contains the necessary information to create a keymap
keymaps_to_register = (
    {'operator':'wm.call_menu','name':'Window', 'space_type' : 'EMPTY', 'prop_map' : 'THREEDI_MT_Main_Menu', 'key' :'F', 'action' : "PRESS", 'ctrl' : True, 'shift' : True, 'alt' : False},
    {'operator':'threedi.render_still','name':'Screen', 'space_type' : 'EMPTY', 'prop_map' : '', 'key' :'F12', 'action' : "PRESS", 'ctrl' : False, 'shift' : False, 'alt' : False},
    {'operator':'threedi.render_animation','name':'Screen', 'space_type' : 'EMPTY', 'prop_map' : '', 'key' :'F12', 'action' : "PRESS", 'ctrl' : True, 'shift' : False, 'alt' : False},
    {'operator':'threedi.auto_file_output','name':'Screen', 'space_type' : 'EMPTY', 'prop_map' : '', 'key' :'F12', 'action' : "PRESS", 'ctrl' : True, 'shift' : True, 'alt' : True},
    
    )
keys = []


def create_keys(maps,kc):
    '''
    registers a new keymap\n
    pass in a dictionary of values and a keyconfig'''
    
    km = kc.keymaps.new(name = maps['name'], space_type = maps['space_type'])
    kmi = km.keymap_items.new(maps['operator'], maps['key'], maps['action'], ctrl= maps['ctrl'], shift=maps['shift'],alt = maps['alt'])
    if maps['prop_map'] != "":
        kmi.properties.name = maps['prop_map']
    
    keys.append((km, kmi))
    
def register_keymap():
    
    wm = bpy.context.window_manager
    addon_keyconfig = wm.keyconfigs.addon
    
    kc = addon_keyconfig

    for maps in keymaps_to_register:
        create_keys(maps,kc)
    
    

    edit_shortcut('Screen','render.render',alt = True)

def unregister_keymap():

    for km, kmi in keys:
        km.keymap_items.remove(kmi)

    keys.clear()
   

    edit_shortcut('Screen','render.render',alt = False)

def edit_shortcut(category,operator_bl_idname,main_key = None,alt = None,ctrl = None, shift = None):
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.default
    for kmi in kc.keymaps[category].keymap_items:
        if kmi.idname == operator_bl_idname:
            if main_key is not None:
                kmi.type = main_key
            if alt is not None:
                kmi.alt = alt
            if ctrl is not None:
                kmi.ctrl = ctrl
            if shift is not None:
                kmi.shift = shift
            

    